# Config Export: config/strategies/earnings_post_momentum.yaml

| Field | Value |
|-------|-------|
| **Original Path** | `config/strategies/earnings_post_momentum.yaml` |
| **Git Commit** | `915876ff12f0988acccf1553f44dd50b0a75dd54` |
| **SHA256** | `e7bac42efd28d4c7f7d27c0532f6761ee7a3c763ad3660304868e8e44240e760` |
| **File Size** | 5858 bytes |

## Full Source

```yaml
strategy_id: earnings_post_momentum
display_name: Earnings Post-Momentum
version: 1.0.0
status: UNVALIDATED
purpose: Enter 1-2 days after earnings on confirmed beats with gap-and-hold price action. Beat must be >10% on EPS or revenue. Gap must hold above gap_low for 30+ minutes.
eligible_accounts:
  - taxable
  - rollover_ira
  - roth_ira
forbidden_accounts: []
timeframe: swing_1_to_10d
timeframe_class: SHORT_SWING
universe:
  price:
    min: 5.0
    max: 500.0
  float_m:
    max: 500
  rvol:
    min: 2.0
primary_data_sources:
  - finviz_screener
  - earnings_calendar
  - news_articles
  - indicator_engine
entry_criteria:
  - id: POST_EARNINGS_WINDOW
    description: Within 1-2 trading days after earnings announcement
    metric: days_since_earnings
    operator: between
    value:
      - 1
      - 2
  - id: BEAT_MAGNITUDE
    description: EPS or revenue beat by at least 10%
    metric: beat_pct
    operator: gte
    value: 10
  - id: GAP_UP_CONFIRMED
    description: Gap up at least 5% from prior close
    metric: gap_pct
    operator: gte
    value: 5.0
  - id: GAP_HOLD_30MIN
    description: Price held above gap_low for first 30 minutes of trading
    metric: gap_hold_30min
    operator: eq
    value: true
  - id: GUIDANCE_NOT_NEGATIVE
    description: Forward guidance reiterated, raised, or neutral (not cut)
    metric: guidance_direction
    operator: in
    value:
      - raised
      - reiterated
      - neutral
auto_disqualifiers:
  - id: GUIDANCE_CUT
    description: Forward guidance cut despite earnings beat
  - id: GAP_FILL
    description: Price filled the earnings gap (closed below gap_low)
  - id: BEAT_TOO_SMALL
    description: "Beat magnitude below 10% — insufficient momentum signal"
  - id: WINDOW_CLOSED
    description: "More than 2 trading days since earnings — entry window closed"
  - id: ACCOUNTING_CONCERNS
    description: Beat driven by one-time items, restated financials, or non-GAAP gymnastics
  - id: HEAVY_INSIDER_SELLING_POST
    description: Insiders selling into the post-earnings strength
exit_rules:
  stop_method: level_based
  stop_at: gap_low
  target_method: trailing
  trail_method: ema_21
  partial_exit_at_2r: true
risk:
  risk_per_trade_pct: 0.005
  max_position_size: 5000
  max_daily_trades: 3
  target_rr: 2.5
scoring:
  min_score_go: 42
  min_score_wait: 30
scoring_weights:
  beat_magnitude: 25
  gap_hold_quality: 20
  guidance_direction: 20
  technical_setup: 15
  sector_alignment: 10
  volume_confirmation: 10
grade_thresholds:
  aplus: 50
  a: 42
  b: 35
  c: 28
lifecycle:
  proposal_expiry_hours: 24
  overnight_allowed: true
  max_hold_days: 10
execution:
  paper_allowed: true
  live_allowed: false
agent_responsibilities:
  maria: Verify the beat is fundamental (revenue and EPS, not just EPS via buybacks). Confirm guidance direction. Check for accounting red flags.
  risk: Validate gap_low stop placement. Confirm position size. Verify R/R meets 2.5 minimum.
  steph: Confirm account placement and that this fits within swing trading allocation.
co_enables:
  promotes_to:
    - swing_breakout
  strengthens:
    - swing_trade
    - speculative_growth
  notes: Post-earnings momentum often sets up multi-week breakout patterns 2-3 weeks later.
vix_rules:
  max_vix_for_entry: 35
  elevated_vix_band:
    - 25
    - 35
  elevated_vix_changes:
    position_size_multiplier: 0.75
    require_beat_15pct_plus: true
  extreme_vix_threshold: 35
  extreme_vix_action: pause_new_entries
  exit_holdings_at_vix:
  notes: Post-earnings momentum is more durable than pre-earnings positioning but require larger beats in high VIX.
technical_indicators_required:
  gates:
    - id: GAP_UP_5PCT
      condition: gap > 5% post-earnings
      metric: gap_pct
      operator: gte
      value: 5.0
    - id: HOLD_30MIN_ABOVE_GAP_LOW
      condition: price holds above gap_low for 30 min
      metric: gap_hold_30min
      operator: eq
      value: true
    - id: VOLUME_EXPANSION
      condition: first hour volume >= 3x avg
      metric: first_hour_rvol
      operator: gte
      value: 3.0
  preferred:
    - ema_21
    - vwap
    - atr_14_pct
    - sector_relative_strength
  irrelevant:
    - fib_618_distance
    - bollinger_squeeze
minimum_evidence:
  required:
    - earnings_date
    - beat_data
    - guidance_data
    - gap_data
    - price_data
    - volume_data
    - trade_plan
  preferred:
    - analyst_post_earnings_revisions
    - sector_data
    - revenue_breakdown
performance_context:
  last_updated: '2026-05-26T06:30:01+00:00'
  closed_paper_trades: 0
  win_rate:
  avg_r_realized:
  profit_factor:
  max_drawdown_pct:
  expectancy_per_trade:
  best_trade_r:
  worst_trade_r:
  current_streak:
  ready_for_review: false
  review_thresholds:
    min_trades: 30
    min_months: 6
    min_profit_factor: 1.25
    min_win_rate: 0.5
  notes: Populated nightly by scripts/paper_performance_governance.py.
validation_gate:
  min_closed_paper_trades: 30
  min_win_rate: 0.55
  min_profit_factor: 1.3
  min_calendar_months: 6
  human_approval_required: true
prompt_context:
  summary: Post-earnings momentum trade. Enter 1-2 days after confirmed beat with gap-and-hold price action. Beat must be >10% with neutral-or-better guidance. Stop at gap_low, trail with EMA(21).
  key_questions:
    - Is the beat fundamental (revenue + EPS) or just EPS via buybacks?
    - Did the gap hold above gap_low for the critical first 30 minutes?
    - Did guidance get raised, reiterated, or cut?
screen_filters:
  min_price: 5.0
  max_price: 300.0
  min_rvol: 2.0
  earnings_within_days_after: 2
  min_gap_pct: 5.0
  min_score: 35
outcome_learning_fields:
  - beat_pct
  - guidance_direction
  - gap_magnitude
  - gap_hold_quality
  - entry_timing_post_earnings
  - hold_duration
  - r_realized
freshness:
  bucket: MULTI_DAY
  ttl_days: 5
  eval_cadence: daily
  watchpool: true
```
