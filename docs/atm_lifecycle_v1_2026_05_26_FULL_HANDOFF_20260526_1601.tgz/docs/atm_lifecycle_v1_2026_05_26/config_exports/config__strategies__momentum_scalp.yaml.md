# Config Export: config/strategies/momentum_scalp.yaml

| Field | Value |
|-------|-------|
| **Original Path** | `config/strategies/momentum_scalp.yaml` |
| **Git Commit** | `915876ff12f0988acccf1553f44dd50b0a75dd54` |
| **SHA256** | `c736c5101ac5a80a529101e135769a8634547d98b34ac0cea1e6ff5fc6bf4649` |
| **File Size** | 6732 bytes |

## Full Source

```yaml
strategy_id: momentum_scalp
display_name: Momentum Scalp
version: 1.0.0
status: TESTING
purpose: "Micro-cap momentum — RVOL surge + verified catalyst. Intraday hold, exit same day."
eligible_accounts:
  - taxable
forbidden_accounts:
  - rollover_ira
  - roth_ira
  - fidelity_401k
timeframe: intraday
timeframe_class: INTRADAY
universe: micro_cap_momentum
primary_data_sources:
  - finviz_screener
  - trade_ai_scans
  - social_posts
  - news_articles
  - sec_form4
screen_filters:
  min_price: 1.0
  max_price: 25.0
  preferred_max_price: 10.0
  min_rvol: 5.0
  premium_rvol: 8.0
  max_float_m: 100
  preferred_max_float_m: 20
  min_gap_pct: 5.0
  min_score: 40
  aplus_score: 48
setup_qualification:
  catalyst_present: required
  catalyst_verified_for_aplus: true
  catalyst_verified_for_live: true
  social_only_max_grade: WATCH
  price_data_max_age_minutes: 15
  rvol_data_required: true
  float_data_required: true
auto_disqualifiers:
  - id: PRICE_OVER_25
    condition: price > 25
  - id: FLOAT_OVER_100M
    condition: float_m > 100
  - id: STOP_OVER_15_PCT
    condition: stop_pct > 0.15
  - id: POSITION_OVER_2000
    condition: dollar_size > 2000
  - id: SAME_SECTOR_OPEN
    condition: open_position_in_same_sector
  - id: AFTER_130PM
    condition: current_time > 13:30 ET
  - id: REVERSE_SPLIT_RECENT
    condition: reverse_split_within_90d
  - id: TRADING_HALTED
    condition: trading_halt_active
  - id: WIDE_SPREAD
    condition: spread_pct > 5
  - id: DILUTION_RISK
    condition: recent_offering_or_shelf
scoring_weights:
  catalyst: 15
  rvol: 12
  price_action: 10
  float: 8
  price_range: 5
  sector_momentum: 5
grade_thresholds:
  aplus: 48
  a: 42
  b: 35
  c: 28
minimum_evidence:
  required:
    - price_data
    - rvol_data
    - float_data
    - trade_plan
    - stop_defined
  preferred:
    - catalyst_verified
    - intel_readiness_score
    - sector_data
recommendation_rules:
  social_only_catalyst: WATCH
  unverified_catalyst_max: WAIT
  verified_catalyst_high_rvol: GO
  all_evidence_present_aplus: APPROVAL_REQUIRED
agent_responsibilities:
  maria: Verify catalyst source and relevance. Check for contrary news.
  risk: Verify entry zone, stop placement, R:R ratio. Check for technical traps.
  steph: Verify position sizing and account fit. Confirm no wash sale risk.
paper_trade_rules:
  use_same_plan_as_live: true
  log_entry_slippage: true
  log_max_adverse_excursion: true
  auto_exit_at_close: true
live_trade_rules:
  max_position_size: 2000
  max_dollar_risk: 200
  no_overnight_hold: true
  require_risk_gate_approved: true
outcome_learning_fields:
  - entry_slippage
  - stop_hit_before_target
  - target_hit_time
  - max_adverse_excursion
  - catalyst_type
  - rvol_at_entry
  - float_at_entry
  - time_of_entry
  - sector
  - vix_at_entry
sub_strategies:
  high_rvol_verified:
    description: RVOL >8x + verified catalyst
    expected_win_rate: 0.65
    filters:
      min_rvol: 8.0
      catalyst_verified: true
  moderate_rvol_verified:
    description: RVOL 5-8x + verified catalyst
    expected_win_rate: 0.55
    filters:
      min_rvol: 5.0
      max_rvol: 8.0
      catalyst_verified: true
  high_rvol_unverified:
    description: RVOL >8x + unverified catalyst
    expected_win_rate: 0.45
    filters:
      min_rvol: 8.0
      catalyst_verified: false
  social_confirmed:
    description: Social surge + Finviz confirmation
    expected_win_rate: 0.5
    filters:
      source: social_confirmed
entry_criteria:
  - id: CATALYST_VERIFIED
    description: "Verified catalyst (news, SEC filing, or institutional event) — not social-only"
    metric: catalyst_verified
    operator: eq
    value: true
  - id: RVOL_SURGE
    description: Relative volume at least 5x 20-day average
    metric: rvol
    operator: gte
    value: 5.0
  - id: PRICE_RANGE
    description: Price between $1 and $25 (preferred under $10)
    metric: price
    operator: between
    value:
      - 1.0
      - 25.0
  - id: FLOAT_LOW
    description: Float under 100M shares (preferred under 20M)
    metric: float_m
    operator: lte
    value: 100
  - id: ENTRY_WINDOW
    description: Current time before 13:30 ET
    metric: current_time_et
    operator: lte
    value: 810
exit_rules:
  stop_method: fixed_pct
  stop_max_pct: 0.15
  target_method: trailing
  intraday_exit_required: true
  no_overnight_hold: true
lifecycle:
  proposal_expiry_hours: 4
  overnight_allowed: false
  max_hold_days: 0
risk:
  risk_per_trade_pct: 0.002
  max_position_size: 2000
  max_daily_trades: 3
  target_rr: 2.0
co_enables:
  promotes_to:
    - swing_breakout
  strengthens:
    - gap_and_go
  notes: Successful intraday momentum runners can incubate into multi-day swing setups.
validation_gate:
  min_closed_paper_trades: 30
  min_win_rate: 0.5
  min_profit_factor: 1.3
  min_calendar_months: 6
  human_approval_required: true
prompt_context:
  summary: Intraday momentum scalp on micro-cap names with verified catalyst and RVOL surge. Strict same-day exit, taxable account only.
  key_questions:
    - Is the catalyst verified or social-only?
    - Is RVOL holding above 5x or fading?
    - Are we within the entry window (before 13:30 ET)?
vix_rules:
  max_vix_for_entry: 25
  elevated_vix_band:
    - 22
    - 35
  elevated_vix_changes:
    position_size_multiplier: 0.5
    require_aplus_grade: true
    require_catalyst_verified: true
  extreme_vix_threshold: 35
  extreme_vix_action: pause_new_entries
  exit_holdings_at_vix: 40
  notes: "Micro-cap momentum is most vulnerable to VIX expansion — pause aggressively."
technical_indicators_required:
  gates:
    - id: VWAP_RECLAIM
      condition: price > vwap (intraday)
      metric: price_vs_vwap
      operator: gt
      value: 0
    - id: EMA_9_ABOVE_EMA_21
      condition: EMA(9) > EMA(21) on 5-min
      metric: ema_9_minus_ema_21
      operator: gt
      value: 0
    - id: OPENING_RANGE_BREAK
      condition: price > opening 15-min high
      metric: price_vs_or_high
      operator: gt
      value: 0
  preferred:
    - rvol_5min
    - rsi_5
    - atr_pct
    - premarket_high_distance
  irrelevant:
    - ema_200
    - fib_618_distance
    - bollinger_squeeze
performance_context:
  last_updated: '2026-05-26T06:30:01+00:00'
  closed_paper_trades: 0
  win_rate:
  avg_r_realized:
  profit_factor:
  max_drawdown_pct:
  expectancy_per_trade:
  best_trade_r:
  worst_trade_r:
  current_streak:
  ready_for_review: false
  review_thresholds:
    min_trades: 30
    min_months: 6
    min_profit_factor: 1.25
    min_win_rate: 0.5
  notes: Populated nightly by scripts/paper_performance_governance.py. Used by LLM prompts to evaluate proposal context.
freshness:
  bucket: SAME_DAY
  ttl_hours: 4
  eval_cadence: none
  watchpool: false
```
