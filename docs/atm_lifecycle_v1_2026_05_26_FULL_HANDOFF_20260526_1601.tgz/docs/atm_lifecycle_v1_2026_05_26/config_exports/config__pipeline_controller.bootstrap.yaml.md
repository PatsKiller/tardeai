# Config Export: config/pipeline_controller.bootstrap.yaml

| Field | Value |
|-------|-------|
| **Original Path** | `config/pipeline_controller.bootstrap.yaml` |
| **Git Commit** | `915876ff12f0988acccf1553f44dd50b0a75dd54` |
| **SHA256** | `618c1cc9786cd6da9cce609bb0b7ff6dcbf4f4341788e8a9fb1cfa683f5b2bb1` |
| **File Size** | 7421 bytes |

## Full Source

```yaml
# Pipeline Controller Bootstrap Registry
# This is the seed file. Authoritative copy lives in DB after seeding.
# Run: python scripts/seed_pipeline_controller.py --apply

pipelines:
  daily:
    name: Daily Trading Pipeline
    description: "31-stage pipeline: data collection through overnight"

stages:
  # GROUP 1: DATA COLLECTION (5:45-7:00 AM)
  - stage_key: indicator_cache_refresh
    group_key: data_collection
    name: Indicator Cache Refresh
    command: ".venv/bin/python scripts/indicator_cache_refresh.py"
    timeout_seconds: 900
    sla_seconds: 600
    sort_order: 100
    can_degrade: true

  - stage_key: finviz_screener_runner
    group_key: data_collection
    name: Finviz Screener Runner
    command: ".venv/bin/python scripts/finviz_screener_runner.py"
    timeout_seconds: 600
    sla_seconds: 300
    sort_order: 110
    can_degrade: true
    degradation_policy: "Use fallback discovery sources if Finviz fails"

  - stage_key: news_ingestion
    group_key: data_collection
    name: News Ingestion
    command: ".venv/bin/python scripts/news_ingestion.py --priority"
    timeout_seconds: 600
    sla_seconds: 300
    sort_order: 120
    can_degrade: true

  - stage_key: topic_ingestion
    group_key: data_collection
    name: Topic Ingestion
    command: ".venv/bin/python scripts/topic_ingestion.py --gaps-only --no-llm"
    timeout_seconds: 900
    sla_seconds: 600
    sort_order: 125
    can_degrade: true

  - stage_key: sec_data_ingest
    group_key: data_collection
    name: SEC Data Ingest
    command: ".venv/bin/python scripts/sec_data_ingest.py"
    timeout_seconds: 600
    sort_order: 130
    can_degrade: true
    active: true

  - stage_key: fred_data_ingest
    group_key: data_collection
    name: FRED Economic Data
    command: ".venv/bin/python scripts/fred_data_ingest.py"
    timeout_seconds: 300
    sort_order: 140
    can_degrade: true
    active: true

  # GROUP 2: ENRICHMENT (7:00-8:00 AM)
  - stage_key: finviz_enrichment
    group_key: enrichment
    name: Finviz 5-View Enrichment
    command: ".venv/bin/python scripts/finviz_enrichment.py"
    timeout_seconds: 1800
    sla_seconds: 900
    sort_order: 200
    can_degrade: true

  - stage_key: catalyst_enrichment
    group_key: enrichment
    name: Catalyst Enrichment (7 sources)
    command: ".venv/bin/python scripts/catalyst_enrichment.py"
    timeout_seconds: 900
    sla_seconds: 600
    sort_order: 210
    can_degrade: true

  - stage_key: price_db_sync
    group_key: enrichment
    name: Price DB Sync
    command: ".venv/bin/python scripts/price_db_sync.py"
    timeout_seconds: 600
    sort_order: 220

  - stage_key: rag_indexer
    group_key: enrichment
    name: RAG Indexer
    command: ".venv/bin/python scripts/rag_indexer.py"
    timeout_seconds: 600
    sort_order: 230
    can_degrade: true

  # GROUP 3: SCORING (8:00-9:00 AM)
  - stage_key: trade_ai_orchestrator
    group_key: scoring
    name: Trade AI Orchestrator (55-point scoring)
    command: ".venv/bin/python scripts/trade_ai_orchestrator.py --run-label pipeline"
    timeout_seconds: 1200
    sla_seconds: 600
    sort_order: 300

  - stage_key: multi_strategy_classifier
    group_key: scoring
    name: Multi-Strategy Classifier
    command: ".venv/bin/python scripts/multi_strategy_classifier.py --batch --limit 30"
    timeout_seconds: 1800
    sla_seconds: 900
    sort_order: 310
    can_degrade: true

  # GROUP 4: INTELLIGENCE (continuous)
  - stage_key: cio_decision_engine
    group_key: intelligence
    name: CIO Decision Engine
    command: ".venv/bin/python scripts/cio_decision_engine.py --run"
    timeout_seconds: 600
    sort_order: 400

  - stage_key: agent_context_refresh
    group_key: intelligence
    name: Agent Context Refresh
    command: ".venv/bin/python scripts/agent_context_refresh.py --full"
    timeout_seconds: 600
    sort_order: 410
    can_degrade: true

  - stage_key: topic_curator
    group_key: intelligence
    name: Topic Curator (rate + extract + improve)
    command: ".venv/bin/python scripts/topic_curator.py --improve-queries"
    timeout_seconds: 1800
    sla_seconds: 900
    sort_order: 420
    can_degrade: true

  - stage_key: pipeline_watchdog
    group_key: intelligence
    name: Pipeline Watchdog
    command: ".venv/bin/python scripts/pipeline_watchdog.py"
    timeout_seconds: 300
    sort_order: 430
    can_degrade: true

  # GROUP 5: PROPOSALS
  - stage_key: daily_incubator_refresh
    group_key: proposals
    name: Daily Incubator Refresh
    command: ".venv/bin/python scripts/daily_incubator_refresh.py"
    timeout_seconds: 600
    sort_order: 500

  - stage_key: incubator_proposal_promoter
    group_key: proposals
    name: Incubator Proposal Promoter
    command: ".venv/bin/python scripts/incubator_proposal_promoter.py --run --limit 10"
    timeout_seconds: 600
    sort_order: 510

  - stage_key: proposal_enrichment_loop
    group_key: proposals
    name: Proposal Enrichment Loop
    command: ".venv/bin/python scripts/proposal_enrichment_loop.py"
    timeout_seconds: 900
    sort_order: 520
    can_degrade: true

  # GROUP 6: EXECUTION (market hours)
  - stage_key: risk_gate
    group_key: execution
    name: Risk Gate
    command: ".venv/bin/python scripts/risk_gate.py"
    timeout_seconds: 300
    sort_order: 600

  - stage_key: live_trading_gate
    group_key: execution
    name: Live Trading Gate (assert paper mode)
    command: ".venv/bin/python scripts/live_trading_gate.py --assert-safe"
    timeout_seconds: 30
    sort_order: 605

  - stage_key: execution_quality
    group_key: execution
    name: Execution Quality Analyzer
    command: ".venv/bin/python scripts/execution_quality_analyzer.py"
    timeout_seconds: 300
    sort_order: 620
    can_degrade: true

  # GROUP 7: OVERNIGHT (8 PM+)
  - stage_key: overnight_batch
    group_key: overnight
    name: Overnight Batch
    command: ".venv/bin/python scripts/overnight_batch.py"
    timeout_seconds: 1800
    sort_order: 700

  - stage_key: agent_outcome_scorer
    group_key: overnight
    name: Agent Outcome Scorer
    command: ".venv/bin/python scripts/agent_outcome_scorer.py"
    timeout_seconds: 600
    sort_order: 710
    can_degrade: true

  - stage_key: system_facts
    group_key: overnight
    name: Generate System Facts
    command: ".venv/bin/python scripts/generate_system_facts.py"
    timeout_seconds: 120
    sort_order: 720
    can_degrade: true

dependencies:
  # Group 2 depends on Group 1
  - stage_key: finviz_enrichment
    depends_on: finviz_screener_runner
  - stage_key: catalyst_enrichment
    depends_on: news_ingestion
  # Group 3 depends on Group 2
  - stage_key: trade_ai_orchestrator
    depends_on: finviz_enrichment
  - stage_key: multi_strategy_classifier
    depends_on: trade_ai_orchestrator
  # Group 4 depends on Group 3
  - stage_key: cio_decision_engine
    depends_on: trade_ai_orchestrator
  - stage_key: topic_curator
    depends_on: topic_ingestion
  # Group 5 depends on Group 3-4
  - stage_key: daily_incubator_refresh
    depends_on: multi_strategy_classifier
  - stage_key: incubator_proposal_promoter
    depends_on: daily_incubator_refresh
  - stage_key: proposal_enrichment_loop
    depends_on: incubator_proposal_promoter
  # Group 6 depends on Group 5
  - stage_key: risk_gate
    depends_on: proposal_enrichment_loop
  - stage_key: live_trading_gate
    depends_on: risk_gate
  # Group 7 independent (overnight)
```
