# Config Export: config/strategies/income_add.yaml

| Field | Value |
|-------|-------|
| **Original Path** | `config/strategies/income_add.yaml` |
| **Git Commit** | `915876ff12f0988acccf1553f44dd50b0a75dd54` |
| **SHA256** | `2683defdc232a95419573988765f15dbe216611fbffd02cadc0aa7e7f8e9da67` |
| **File Size** | 5832 bytes |

## Full Source

```yaml
strategy_id: income_add
display_name: Income Position Add
version: 1.0.0
status: TESTING
purpose: Adding to or initiating income positions. Triggered by pullbacks to support, ex-div opportunities, or rebalancing.
eligible_accounts:
  - rollover_ira
  - roth_ira
  - taxable
forbidden_accounts: []
timeframe: position_long
timeframe_class: POSITION
universe: income_candidates
primary_data_sources:
  - portfolio_holdings
  - finviz_enrichment
  - alex_retirement_advisor
  - fred_data
screen_filters:
  min_yield: 3.0
  max_payout_ratio: 0.85
  min_dividend_growth_years: 3
  entry_rsi_max: 50
  entry_below_sma_50: true
setup_qualification:
  ssdi_check_required: true
  irmaa_check_required: true
  golden_window_impact_check: true
  alex_analysis_required: true
  steph_analysis_required: true
auto_disqualifiers:
  - id: DIVIDEND_CUT
    condition: dividend_cut_within_12m
  - id: PAYOUT_UNSUSTAINABLE
    condition: payout_ratio > 0.85
  - id: SSDI_NOT_CHECKED
    condition: ssdi_check not completed
  - id: IRMAA_BREACH_RISK
    condition: projected MAGI exceeds IRMAA threshold
  - id: BDC_IN_TAXABLE
    condition: asset_type == BDC and account == taxable
  - id: REIT_IN_TAXABLE_UNAPPROVED
    condition: asset_type == REIT and account == taxable and not specifically_approved
scoring_weights:
  dividend_safety: 30
  yield_quality: 25
  technical_entry: 20
  income_gap_impact: 15
  ssdi_impact: 10
grade_thresholds:
  aplus: 50
  a: 42
  b: 35
  c: 28
minimum_evidence:
  required:
    - dividend_data
    - ssdi_impact_assessment
    - irmaa_projection
    - portfolio_income_impact
    - alex_analysis
    - steph_analysis
  preferred:
    - golden_window_impact
    - tax_lot_optimization
recommendation_outputs:
  - ADD
  - WATCH
  - HOLD
  - DO_NOT_ADD
agent_responsibilities:
  alex: Full retirement-aware analysis. SSDI/IRMAA/MAGI check. Golden Window impact.
  steph: Portfolio fit, income gap impact, allocation limits.
  tax: Tax lot optimization. Wash sale check. Account placement.
  maria: Verify dividend sustainability, earnings quality, and sector outlook. Flag any payout-ratio deterioration.
  risk: Assess yield trap risk, sector concentration, and rate sensitivity. Confirm position-size fit with income allocation bucket.
paper_trade_rules:
  track_income_yield_on_cost: true
  benchmark_comparison_12m: true
live_trade_rules:
  dollar_risk: 500
  preferred_accounts:
    - rollover_ira
    - roth_ira
outcome_learning_fields:
  - yield_on_cost
  - income_contribution
  - ssdi_impact
  - irmaa_impact
  - hold_duration
  - benchmark_relative_performance
entry_criteria:
  - id: YIELD_THRESHOLD
    description: Current dividend yield at least 3%
    metric: dividend_yield
    operator: gte
    value: 0.03
  - id: PAYOUT_SUSTAINABLE
    description: Payout ratio under 85%
    metric: payout_ratio
    operator: lte
    value: 0.85
  - id: DIVIDEND_GROWTH_HISTORY
    description: At least 3 consecutive years of dividend increases
    metric: div_increase_streak_years
    operator: gte
    value: 3
  - id: PULLBACK_ENTRY
    description: RSI(14) at or below 50 (not euphoric)
    metric: rsi_14
    operator: lte
    value: 50
  - id: IRMAA_HEADROOM
    description: Projected MAGI stays below IRMAA threshold ($103K)
    metric: projected_magi_under_irmaa
    operator: eq
    value: true
exit_rules:
  stop_method: fundamental
  exit_trigger: dividend_cut_or_thesis_break
  target_method: none
lifecycle:
  proposal_expiry_hours: 720
  overnight_allowed: true
  max_hold_days:
risk:
  risk_per_trade_pct: 0.005
  max_position_size: 15000
  max_daily_trades:
  target_rr: 2.0
co_enables:
  promotes_to:
    - covered_call_income
  strengthens:
    - dividend_growth_compounder
    - reit_income
    - high_yield_income_bdc
  notes: Once a position is established and stable, covered call income can layer additional yield.
validation_gate:
  min_closed_paper_trades: 30
  min_win_rate: 0.55
  min_profit_factor: 1.3
  min_calendar_months: 6
  human_approval_required: true
prompt_context:
  summary: Income position add for retirement income generation. SSDI-aware, IRMAA-aware, MFS-aware. Pullback entries on quality dividend payers.
  key_questions:
    - What is the IRMAA and SSDI income impact of adding this position?
    - Is the dividend coverage sustainable through a recession?
    - Should this go in taxable (qualified div) or IRA (ordinary)?
vix_rules:
  max_vix_for_entry: 50
  elevated_vix_band:
    - 30
    - 50
  elevated_vix_changes:
    position_size_multiplier: 1.0
    prefer_quality_pullbacks: true
    accelerate_screening: true
  extreme_vix_threshold: 50
  extreme_vix_action: accelerate_new_entries
  exit_holdings_at_vix:
  notes: High VIX creates pullback entry opportunities in quality income names.
technical_indicators_required:
  gates:
    - id: PULLBACK_TO_SUPPORT
      condition: price at EMA(50) or 61.8% retracement
      metric: pullback_to_support
      operator: eq
      value: true
    - id: RSI_NOT_OVERBOUGHT
      condition: RSI(14) <= 50 (cooled, not euphoric)
      metric: rsi_14
      operator: lte
      value: 50
  preferred:
    - dividend_ex_date_proximity
    - fib_618_distance
    - ema_200
  irrelevant:
    - vwap
    - opening_range
    - bollinger_squeeze
performance_context:
  last_updated: '2026-05-26T06:30:01+00:00'
  closed_paper_trades: 0
  win_rate:
  avg_r_realized:
  profit_factor:
  max_drawdown_pct:
  expectancy_per_trade:
  best_trade_r:
  worst_trade_r:
  current_streak:
  ready_for_review: false
  review_thresholds:
    min_trades: 30
    min_months: 6
    min_profit_factor: 1.25
    min_win_rate: 0.5
  notes: Populated nightly by scripts/paper_performance_governance.py. Used by LLM prompts to evaluate proposal context.
freshness:
  bucket: LONG_CYCLE
  ttl_days: 60
  eval_cadence: weekly
  watchpool: true
```
