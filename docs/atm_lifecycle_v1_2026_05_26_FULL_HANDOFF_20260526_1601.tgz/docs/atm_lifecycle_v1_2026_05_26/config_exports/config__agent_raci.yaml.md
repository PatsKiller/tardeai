# Config Export: config/agent_raci.yaml

| Field | Value |
|-------|-------|
| **Original Path** | `config/agent_raci.yaml` |
| **Git Commit** | `915876ff12f0988acccf1553f44dd50b0a75dd54` |
| **SHA256** | `ec8a664ed1f0aa8334bbdac22215edf37b8e153de69258fc894f737f65a229c0` |
| **File Size** | 1401 bytes |

## Full Source

```yaml
processes:
- id: daily_batch
  name: Daily Watchlist Batch
  trigger: 6:25 AM cron
  frequency: Daily M-F
  raci:
    steph: R
    maria: R
    risk_agent: R
    tax_agent: C
- id: overnight_surveillance
  name: Overnight Surveillance
  trigger: 8 PM cron
  frequency: Nightly M-F
  raci:
    aegis: R
    steph: C
    risk_agent: C
- id: morning_brief
  name: Morning Brief Delivery
  trigger: 8:05 AM cron
  frequency: Daily M-F
  raci:
    aegis: R
    alex: I
- id: alex_daily
  name: Alex Daily Portfolio Scan
  trigger: 5 AM cron
  frequency: Daily M-F
  raci:
    alex: R/A
- id: alex_weekly
  name: Alex Weekly Report
  trigger: 8 AM Sun cron
  frequency: Weekly Sun
  raci:
    alex: R/A
    steph: I
    tax_agent: I
- id: iris_hygiene
  name: Iris Library Hygiene
  trigger: 7:55 AM cron
  frequency: Daily M-F
  raci:
    iris: R/A
- id: scalp_scan
  name: Pre-Market Scalp Scan
  trigger: 4 AM cron
  frequency: Daily M-F
  raci:
    social_scalp: R
    scalp_critic: A
- id: event_routing
  name: Event Detection & Routing
  trigger: '*/15 cron'
  frequency: Every 15min M-F
  raci:
    risk_agent: R
    steph: C
    alex: A
- id: stop_surveillance
  name: Stop Surveillance
  trigger: '*/3 cron'
  frequency: Every 3min market hours
  raci:
    risk_agent: R/A
_generated_at: '2026-05-24'
_note: Generated from agent_runtime.json + agents.json + crontab. Edit manually for
  accuracy.
```
