# Config Export: config/strategies/swing_trade.yaml

| Field | Value |
|-------|-------|
| **Original Path** | `config/strategies/swing_trade.yaml` |
| **Git Commit** | `915876ff12f0988acccf1553f44dd50b0a75dd54` |
| **SHA256** | `64883f1f2bf7da60d362328578aed04a9d0a6708582c3be4f2bb1ec3baedf31f` |
| **File Size** | 4414 bytes |

## Full Source

```yaml
strategy_id: swing_trade
display_name: Swing Trade
version: 1.0.0
status: UNVALIDATED
purpose: Breakout continuation trades in confirmed uptrends. Any market cap, multi-day hold with trend-following exits.
eligible_accounts:
  - taxable
  - rollover_ira
  - roth_ira
timeframe: swing_3_to_21d
timeframe_class: SHORT_SWING
universe:
  price:
    min: 5.0
    max: 500.0
  float_m:
    max:
  rvol:
    min: 1.2
entry_criteria:
  - id: TREND_CONFIRMED
    description: Price above 20-day and 50-day SMA with rising slope
    metric: trend_confirmation
    operator: eq
    value: true
  - id: BREAKOUT_LEVEL
    description: Price breaking above prior swing high or consolidation resistance
    metric: breakout_vs_resistance
    operator: gte
    value: 1.0
  - id: VOLUME_EXPANSION
    description: Breakout day volume at least 1.2x 20-day average
    metric: rvol
    operator: gte
    value: 1.2
  - id: SECTOR_SUPPORT
    description: Sector relative strength positive vs SPY over 5 days
    metric: sector_rs_5d
    operator: gte
    value: 0.0
auto_disqualifiers:
  - id: DOWNTREND
    description: Price below 50-day SMA
  - id: EARNINGS_WITHIN_5D
    description: Earnings announcement within 5 trading days
  - id: EXTENDED_ENTRY
    description: Price more than 5% above breakout level
  - id: NO_STOP_DEFINED
    description: Trade plan lacks a defined stop loss
exit_rules:
  stop_method: atr_based
  target_method: trailing
risk:
  risk_per_trade_pct: 0.005
  max_position_size: 5000
  max_daily_trades: 3
  target_rr: 2.5
scoring:
  min_score_go: 42
  min_score_wait: 28
lifecycle:
  proposal_expiry_hours: 168
  overnight_allowed: true
  max_hold_days: 21
execution:
  paper_allowed: true
  live_allowed: false
agent_responsibilities:
  maria: Verify trend strength, catalyst presence, and sector alignment.
  risk: Validate stop placement relative to ATR and breakout structure.
  steph: Confirm position sizing, account eligibility, and portfolio concentration.
co_enables:
  promotes_to:
    - swing_breakout
  strengthens:
    - speculative_growth
    - sector_rotation
validation_gate:
  min_closed_paper_trades: 30
  min_win_rate: 0.55
  min_profit_factor: 1.3
  min_calendar_months: 6
  human_approval_required: true
prompt_context:
  summary: Swing trade strategy targeting breakout continuation in confirmed uptrends. Holds 3-21 days with ATR-based stops and trailing targets. Suitable for any market cap with volume confirmation.
  key_questions:
    - Is the trend confirmed on daily and weekly timeframes?
    - Does volume support the breakout or is it suspect?
    - Are there any earnings or macro events that could disrupt the hold period?
screen_filters:
  min_price: 5.0
  max_price: 200.0
  min_rvol: 1.5
  max_float_m: 500
  min_score: 35
vix_rules:
  max_vix_for_entry: 32
  elevated_vix_band:
    - 25
    - 35
  elevated_vix_changes:
    position_size_multiplier: 0.75
    require_aplus_grade: true
  extreme_vix_threshold: 35
  extreme_vix_action: pause_new_entries
  exit_holdings_at_vix:
  notes: "Trend-following degrades in regime shifts — tighten quality bar."
technical_indicators_required:
  gates:
    - id: PRICE_ABOVE_EMA_50
      condition: price > EMA(50)
      metric: price_vs_ema_50
      operator: gt
      value: 0
    - id: EMA_50_ABOVE_EMA_200
      condition: EMA(50) > EMA(200)
      metric: ema_50_vs_ema_200
      operator: gt
      value: 0
    - id: RSI_BAND
      condition: RSI(14) between 50 and 72
      metric: rsi_14
      operator: between
      value:
        - 50
        - 72
    - id: ATR_STOP_REASONABLE
      condition: ATR(14)-based stop <= 2x ATR
      metric: stop_vs_atr_multiplier
      operator: lte
      value: 2.0
  preferred:
    - fib_618_distance
    - volume_trend
    - sector_rs
  irrelevant:
    - vwap
    - opening_range
    - bollinger_squeeze
performance_context:
  last_updated: '2026-05-26T06:30:01+00:00'
  closed_paper_trades: 0
  win_rate:
  avg_r_realized:
  profit_factor:
  max_drawdown_pct:
  expectancy_per_trade:
  best_trade_r:
  worst_trade_r:
  current_streak:
  ready_for_review: false
  review_thresholds:
    min_trades: 30
    min_months: 6
    min_profit_factor: 1.25
    min_win_rate: 0.5
  notes: Populated nightly by scripts/paper_performance_governance.py. Used by LLM prompts to evaluate proposal context.
freshness:
  bucket: MULTI_DAY
  ttl_days: 10
  eval_cadence: daily
  watchpool: true
```
