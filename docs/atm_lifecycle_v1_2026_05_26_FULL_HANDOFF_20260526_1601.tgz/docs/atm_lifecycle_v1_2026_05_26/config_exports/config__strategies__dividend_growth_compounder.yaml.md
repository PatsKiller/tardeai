# Config Export: config/strategies/dividend_growth_compounder.yaml

| Field | Value |
|-------|-------|
| **Original Path** | `config/strategies/dividend_growth_compounder.yaml` |
| **Git Commit** | `915876ff12f0988acccf1553f44dd50b0a75dd54` |
| **SHA256** | `7413fcec96c095cf178a9c27c9eb540e50be689865a628b2530cf379a457e6b5` |
| **File Size** | 4188 bytes |

## Full Source

```yaml
strategy_id: dividend_growth_compounder
display_name: Dividend Growth Compounder
version: 1.0.0
status: UNVALIDATED
purpose: Dividend aristocrats and kings for reliable income growth. Focus on companies with 10+ years of consecutive dividend increases and sustainable payout ratios.
eligible_accounts:
  - taxable
  - rollover_ira
  - roth_ira
timeframe: position_long
timeframe_class: POSITION
universe:
  price:
    min: 15.0
    max:
  float_m:
    max:
  rvol:
    min:
entry_criteria:
  - id: DIVIDEND_STREAK
    description: At least 10 consecutive years of dividend increases
    metric: div_increase_streak_years
    operator: gte
    value: 10
  - id: PAYOUT_RATIO
    description: Payout ratio below 75% for sustainability
    metric: payout_ratio
    operator: lte
    value: 0.75
  - id: DIVIDEND_GROWTH_RATE
    description: 5-year dividend CAGR of at least 5%
    metric: div_cagr_5y
    operator: gte
    value: 0.05
  - id: YIELD_MINIMUM
    description: Current yield at least 1.5%
    metric: dividend_yield
    operator: gte
    value: 0.015
auto_disqualifiers:
  - id: DIVIDEND_CUT
    description: Dividend cut or freeze within the last 12 months
  - id: PAYOUT_UNSUSTAINABLE
    description: Payout ratio exceeds 85% with declining earnings
  - id: DEBT_DETERIORATION
    description: Debt/equity rising with declining interest coverage
  - id: IRMAA_BREACH_RISK
    description: Dividend income would push MAGI past IRMAA threshold
exit_rules:
  stop_method: fundamental
  target_method: trailing
risk:
  risk_per_trade_pct: 0.005
  max_position_size: 15000
  max_daily_trades:
  target_rr: 2.0
scoring:
  min_score_go: 42
  min_score_wait: 28
lifecycle:
  proposal_expiry_hours: 720
  overnight_allowed: true
  max_hold_days:
execution:
  paper_allowed: true
  live_allowed: false
agent_responsibilities:
  maria: Verify dividend safety, payout sustainability, and earnings quality.
  risk: Assess yield trap risk, sector concentration, and rate sensitivity.
  steph: Confirm account placement for tax efficiency and IRMAA/SSDI income impact.
co_enables:
  promotes_to: []
  strengthens:
    - covered_call_income
    - high_yield_income_bdc
    - reit_income
validation_gate:
  min_closed_paper_trades: 30
  min_win_rate: 0.55
  min_profit_factor: 1.3
  min_calendar_months: 6
  human_approval_required: true
prompt_context:
  summary: Dividend growth compounder targeting aristocrats and kings with 10+ year increase streaks. Focuses on sustainable payout ratios and growing dividends for long-term income compounding. IRMAA-aware for retirement accounts.
  key_questions:
    - Is the dividend growth rate accelerating or decelerating?
    - Can the company sustain the dividend through a recession scenario?
    - What is the IRMAA and SSDI income impact of adding this position?
screen_filters:
  min_price: 10.0
  max_price: 500.0
  min_div_yield_pct: 1.0
  max_div_yield_pct: 6.0
  min_market_cap_b: 5.0
  max_beta: 1.2
  min_dividend_growth_years: 5
  min_score: 0
vix_rules:
  max_vix_for_entry: 50
  elevated_vix_band:
    - 30
    - 50
  elevated_vix_changes:
    position_size_multiplier: 1.0
    accelerate_screening: true
  extreme_vix_threshold: 50
  extreme_vix_action: accelerate_new_entries
  exit_holdings_at_vix:
  notes: Aristocrat pullbacks in volatility are textbook entry zones.
technical_indicators_required:
  gates: []
  preferred:
    - ema_200_support
    - rsi_14_below_50
    - pullback_to_ema_50
  irrelevant:
    - vwap
    - opening_range
    - rsi_5
    - bollinger_squeeze
  note: "Fundamental entry — technicals only inform timing, not eligibility."
performance_context:
  last_updated: '2026-05-26T06:30:01+00:00'
  closed_paper_trades: 0
  win_rate:
  avg_r_realized:
  profit_factor:
  max_drawdown_pct:
  expectancy_per_trade:
  best_trade_r:
  worst_trade_r:
  current_streak:
  ready_for_review: false
  review_thresholds:
    min_trades: 30
    min_months: 6
    min_profit_factor: 1.25
    min_win_rate: 0.5
  notes: Populated nightly by scripts/paper_performance_governance.py. Used by LLM prompts to evaluate proposal context.
freshness:
  bucket: LONG_CYCLE
  ttl_days: 60
  eval_cadence: weekly
  watchpool: true
```
