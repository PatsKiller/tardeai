# Config Export: config/strategies/reit_income.yaml

| Field | Value |
|-------|-------|
| **Original Path** | `config/strategies/reit_income.yaml` |
| **Git Commit** | `915876ff12f0988acccf1553f44dd50b0a75dd54` |
| **SHA256** | `34cad510da195488feef4e2e5160c4a9c49f149fd435fca4a0b6df8fa524a1a1` |
| **File Size** | 4237 bytes |

## Full Source

```yaml
strategy_id: reit_income
display_name: REIT Income
version: 1.0.0
status: UNVALIDATED
purpose: REIT positions for income generation and real estate portfolio exposure. Focus on well-managed REITs with sustainable FFO payout ratios.
eligible_accounts:
  - taxable
  - rollover_ira
  - roth_ira
timeframe: position_long
timeframe_class: POSITION
universe:
  price:
    min: 10.0
    max:
  float_m:
    max:
  rvol:
    min:
entry_criteria:
  - id: REIT_CLASSIFICATION
    description: Company is a qualifying REIT with 90%+ income distribution requirement
    metric: asset_type
    operator: eq
    value: REIT
  - id: FFO_PAYOUT
    description: AFFO payout ratio below 85% for distribution sustainability
    metric: affo_payout_ratio
    operator: lte
    value: 0.85
  - id: OCCUPANCY_RATE
    description: Portfolio occupancy rate above 90%
    metric: occupancy_rate
    operator: gte
    value: 0.9
  - id: YIELD_ATTRACTIVE
    description: Current yield at least 3.5% or above sector median
    metric: dividend_yield
    operator: gte
    value: 0.035
auto_disqualifiers:
  - id: DISTRIBUTION_CUT
    description: Distribution cut within the last 12 months
  - id: LEVERAGE_EXCESSIVE
    description: Net debt to EBITDA exceeds 7x
  - id: REIT_IN_TAXABLE_UNAPPROVED
    description: REIT placement in taxable without explicit approval (non-qualified dividends)
  - id: OCCUPANCY_DECLINING
    description: Occupancy rate declining for 3+ consecutive quarters
exit_rules:
  stop_method: fundamental
  target_method: level_based
risk:
  risk_per_trade_pct: 0.005
  max_position_size: 12000
  max_daily_trades:
  target_rr: 2.0
scoring:
  min_score_go: 40
  min_score_wait: 25
lifecycle:
  proposal_expiry_hours: 720
  overnight_allowed: true
  max_hold_days:
execution:
  paper_allowed: true
  live_allowed: false
agent_responsibilities:
  maria: Verify FFO quality, occupancy trends, lease duration, and property type outlook.
  risk: Assess interest rate sensitivity, leverage, and correlation with existing real estate exposure.
  steph: Confirm IRA placement preference for tax efficiency and IRMAA income impact.
co_enables:
  promotes_to: []
  strengthens:
    - dividend_growth_compounder
    - high_yield_income_bdc
    - covered_call_income
validation_gate:
  min_closed_paper_trades: 30
  min_win_rate: 0.55
  min_profit_factor: 1.3
  min_calendar_months: 6
  human_approval_required: true
prompt_context:
  summary: REIT income strategy for real estate exposure and income generation. Targets well-managed REITs with sustainable AFFO payout ratios and high occupancy. Strongly prefers IRA placement due to non-qualified dividend taxation.
  key_questions:
    - Is the REIT's property type sector facing headwinds or tailwinds?
    - Is the distribution covered by AFFO or is there return-of-capital risk?
    - Should this be placed in IRA to avoid unfavorable tax treatment?
screen_filters:
  min_price: 5.0
  max_price: 200.0
  min_div_yield_pct: 3.5
  max_div_yield_pct: 15.0
  sector_include:
    - Real Estate
  sector_filter:
    - reit
    - real_estate
  min_score: 0
vix_rules:
  max_vix_for_entry: 40
  elevated_vix_band:
    - 30
    - 40
  elevated_vix_changes:
    position_size_multiplier: 0.5
    prefer_industrial_residential: true
    avoid_office_retail: true
  extreme_vix_threshold: 40
  extreme_vix_action: pause_new_entries
  exit_holdings_at_vix:
  notes: "Rate-sensitive — pause until 10y stabilizes."
technical_indicators_required:
  gates: []
  preferred:
    - ema_200_support
    - rate_sensitivity_check
  irrelevant:
    - vwap
    - opening_range
    - rsi_5
  note: FFO/AFFO and rate environment drive entry.
performance_context:
  last_updated: '2026-05-26T06:30:01+00:00'
  closed_paper_trades: 0
  win_rate:
  avg_r_realized:
  profit_factor:
  max_drawdown_pct:
  expectancy_per_trade:
  best_trade_r:
  worst_trade_r:
  current_streak:
  ready_for_review: false
  review_thresholds:
    min_trades: 30
    min_months: 6
    min_profit_factor: 1.25
    min_win_rate: 0.5
  notes: Populated nightly by scripts/paper_performance_governance.py. Used by LLM prompts to evaluate proposal context.
freshness:
  bucket: LONG_CYCLE
  ttl_days: 60
  eval_cadence: weekly
  watchpool: true
```
