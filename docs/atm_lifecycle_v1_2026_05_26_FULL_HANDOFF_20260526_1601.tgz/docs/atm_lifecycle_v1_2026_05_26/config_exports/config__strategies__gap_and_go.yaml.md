# Config Export: config/strategies/gap_and_go.yaml

| Field | Value |
|-------|-------|
| **Original Path** | `config/strategies/gap_and_go.yaml` |
| **Git Commit** | `915876ff12f0988acccf1553f44dd50b0a75dd54` |
| **SHA256** | `642f5aa630cb54eb5b85e033a32afd6bc7b3a4676af4ff2bee2bfc2bf22a0928` |
| **File Size** | 5184 bytes |

## Full Source

```yaml
strategy_id: gap_and_go
display_name: Gap & Go
version: 1.0.0
status: TESTING
purpose: Pre-market gap >5% with volume confirmation at open. Enter on first candle close above gap high.
eligible_accounts:
  - taxable
forbidden_accounts:
  - rollover_ira
  - roth_ira
  - fidelity_401k
timeframe: intraday
timeframe_class: INTRADAY
universe: gap_candidates
primary_data_sources:
  - premarket_watcher
  - finviz_screener
  - news_articles
  - sec_edgar
screen_filters:
  min_price: 2.0
  max_price: 50.0
  min_gap_pct: 5.0
  elevated_vix_min_gap_pct: 10.0
  max_gap_pct: 100.0
  min_rvol: 3.0
  max_float_m: 100
  min_score: 38
setup_qualification:
  catalyst_required: true
  social_only_max_grade: WATCH
  entry_window_start: 09:30
  entry_window_end: 09:50
  first_candle_confirmation: required
  no_chase_entry: true
  premarket_rvol_confirmation: true
auto_disqualifiers:
  - id: NO_CATALYST
    condition: catalyst is null or empty
  - id: ENTRY_AFTER_950AM
    condition: current_time > 09:50 ET
  - id: GAP_FILL_ALREADY
    condition: price below previous close
  - id: CHASE_ENTRY
    condition: price > gap_high * 1.05
scoring_weights:
  gap: 20
  rvol: 15
  catalyst: 12
  float: 8
  price_action: 10
  price_range: 5
grade_thresholds:
  aplus: 48
  a: 40
  b: 35
  c: 28
minimum_evidence:
  required:
    - price_data
    - gap_pct_data
    - rvol_data
    - catalyst_text
    - trade_plan
  preferred:
    - premarket_volume
    - catalyst_verified
agent_responsibilities:
  maria: Verify gap catalyst. Check if gap is news-driven vs technical.
  risk: Verify gap levels, entry timing, stop below gap low.
paper_trade_rules:
  use_same_plan_as_live: true
  confirm_in_tos_premarket: true
live_trade_rules:
  max_position_size: 2000
  max_dollar_risk: 200
  max_entry_delay_minutes: 30
  no_overnight_hold: true
outcome_learning_fields:
  - gap_magnitude
  - catalyst_type
  - first_candle_direction
  - entry_vs_gap_high
  - fill_time
entry_criteria:
  - id: GAP_SIZE
    description: Pre-market gap of at least 5% (10% if VIX > 25)
    metric: gap_pct
    operator: gte
    value: 5.0
  - id: CATALYST_REQUIRED
    description: Verified catalyst driving the gap
    metric: catalyst_verified
    operator: eq
    value: true
  - id: FIRST_CANDLE_CONFIRMATION
    description: First 5-min candle closes above gap_high
    metric: first_5min_close_above_gap_high
    operator: eq
    value: true
  - id: RVOL_CONFIRMATION
    description: Pre-market and opening RVOL at least 3x average
    metric: rvol
    operator: gte
    value: 3.0
  - id: ENTRY_WINDOW
    description: Entry between 09:30 and 09:50 ET
    metric: current_time_et
    operator: between
    value:
      - 09:30
      - 09:50
exit_rules:
  stop_method: level_based
  stop_at: gap_low
  target_method: trailing
  no_overnight_hold: true
lifecycle:
  proposal_expiry_hours: 2
  overnight_allowed: false
  max_hold_days: 0
risk:
  risk_per_trade_pct: 0.002
  max_position_size: 2000
  max_daily_trades: 3
  target_rr: 2.0
co_enables:
  promotes_to:
    - swing_breakout
    - earnings_post_momentum
  strengthens:
    - momentum_scalp
  notes: Successful gap-and-go setups frequently form the base for post-earnings or breakout swings.
validation_gate:
  min_closed_paper_trades: 30
  min_win_rate: 0.5
  min_profit_factor: 1.3
  min_calendar_months: 6
  human_approval_required: true
prompt_context:
  summary: Intraday gap-and-go setup. Pre-market gap > 5%, verified catalyst, first-candle confirmation. Strict same-day exit, taxable only.
  key_questions:
    - Is the gap news-driven or technical?
    - Did the first 5-min candle close above gap_high?
    - Is VWAP holding above gap_low?
vix_rules:
  max_vix_for_entry: 28
  elevated_vix_band:
    - 25
    - 35
  elevated_vix_changes:
    position_size_multiplier: 0.5
    min_gap_pct_override: 10.0
    require_catalyst_verified: true
  extreme_vix_threshold: 35
  extreme_vix_action: pause_new_entries
  exit_holdings_at_vix:
  notes: "Gap quality degrades in high VIX — require larger gaps and verified catalyst."
technical_indicators_required:
  gates:
    - id: GAP_PCT
      condition: gap_pct > 5
      metric: gap_pct
      operator: gt
      value: 5.0
    - id: FIRST_5MIN_CLOSE_ABOVE_GAP_HIGH
      condition: close[1] > gap_high
      metric: first_5min_close_vs_gap_high
      operator: gt
      value: 0
    - id: VWAP_ABOVE_GAP_LOW
      condition: vwap > gap_low
      metric: vwap_vs_gap_low
      operator: gt
      value: 0
  preferred:
    - rvol
    - premarket_high
    - ema_9
    - atr_pct
  irrelevant:
    - ema_200
    - fib_618_distance
    - macd
performance_context:
  last_updated: '2026-05-26T06:30:01+00:00'
  closed_paper_trades: 0
  win_rate:
  avg_r_realized:
  profit_factor:
  max_drawdown_pct:
  expectancy_per_trade:
  best_trade_r:
  worst_trade_r:
  current_streak:
  ready_for_review: false
  review_thresholds:
    min_trades: 30
    min_months: 6
    min_profit_factor: 1.25
    min_win_rate: 0.5
  notes: Populated nightly by scripts/paper_performance_governance.py. Used by LLM prompts to evaluate proposal context.
freshness:
  bucket: SAME_DAY
  ttl_hours: 4
  eval_cadence: none
  watchpool: false
```
