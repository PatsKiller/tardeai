# Config Export: config/strategies/swing_breakout.yaml

| Field | Value |
|-------|-------|
| **Original Path** | `config/strategies/swing_breakout.yaml` |
| **Git Commit** | `915876ff12f0988acccf1553f44dd50b0a75dd54` |
| **SHA256** | `61afa562ddcbb5c999d2b33702e56992d5f7b5cc09e599e4d16de191a60b5bfe` |
| **File Size** | 5608 bytes |

## Full Source

```yaml
strategy_id: swing_breakout
display_name: Swing Breakout
version: 1.0.0
status: TESTING
purpose: Technical breakout from multi-week consolidation base. 20+ day base, volume dry-up, then expansion.
eligible_accounts:
  - taxable
  - rollover_ira
  - roth_ira
forbidden_accounts:
  - fidelity_401k
timeframe: swing_3_to_21d
timeframe_class: SHORT_SWING
universe: breakout_candidates
primary_data_sources:
  - finviz_screener
  - indicator_engine
  - news_articles
screen_filters:
  min_price: 5.0
  max_price: 150.0
  max_float_m: 500
  min_rvol: 1.5
  min_score: 35
setup_qualification:
  min_base_days: 15
  max_base_days: 90
  volume_dry_up_days: 3
  volume_dry_up_threshold: 0.7
  breakout_volume_ratio: 1.5
  sector_rank_max: 3
  entry_within_breakout_pct: 3.0
  stop_below_base_low: true
  manual_chart_review_during_testing: true
  no_entry_if_earnings_within_days: 7
auto_disqualifiers:
  - id: BASE_TOO_SHORT
    condition: base_days < 15
  - id: NO_VOLUME_CONFIRMATION
    condition: breakout_volume_ratio < 1.5
  - id: EXTENDED_FROM_BREAKOUT
    condition: price > breakout_level * 1.03
  - id: EARNINGS_WITHIN_7D
    condition: earnings_date within 7 days
scoring_weights:
  technical_setup: 25
  volume_pattern: 20
  sector_momentum: 15
  fundamental_quality: 15
  catalyst: 10
  price_range: 15
grade_thresholds:
  aplus: 50
  a: 42
  b: 35
  c: 28
minimum_evidence:
  required:
    - price_data
    - base_duration
    - volume_pattern
    - breakout_level
    - stop_below_base
    - trade_plan
  preferred:
    - sector_rank
    - institutional_activity
    - options_activity
agent_responsibilities:
  maria: Verify fundamental quality and news flow.
  risk: Verify base structure, breakout level, stop placement.
  steph: Verify account fit and position sizing for multi-day hold.
paper_trade_rules:
  chart_review_required: true
  max_hold_days: 21
  auto_exit_at_max_hold: true
live_trade_rules:
  max_dollar_risk: 200
  max_hold_days: 21
  ira_max_risk: 500
outcome_learning_fields:
  - base_duration
  - base_tightness
  - breakout_volume_ratio
  - sector_rank
  - hold_duration
  - max_favorable_excursion
entry_criteria:
  - id: BASE_LENGTH
    description: Consolidation base of at least 15 days (max 90)
    metric: base_days
    operator: between
    value:
      - 15
      - 90
  - id: VOLUME_DRY_UP
    description: Volume during base contracts to 70% of 20-day average
    metric: base_volume_ratio
    operator: lte
    value: 0.7
  - id: BREAKOUT_VOLUME
    description: Breakout day volume at least 1.5x 20-day average
    metric: breakout_volume_ratio
    operator: gte
    value: 1.5
  - id: ENTRY_PROXIMITY
    description: Price within 3% of breakout level (no chasing)
    metric: distance_from_breakout_pct
    operator: lte
    value: 0.03
  - id: SECTOR_LEADERSHIP
    description: Sector ranks in top 3 by relative strength
    metric: sector_rs_rank
    operator: lte
    value: 3
exit_rules:
  stop_method: level_based
  stop_at: base_low
  target_method: trailing
  trail_method: ema_21
lifecycle:
  proposal_expiry_hours: 48
  overnight_allowed: true
  max_hold_days: 21
risk:
  risk_per_trade_pct: 0.005
  max_position_size: 5000
  max_daily_trades: 3
  target_rr: 2.5
co_enables:
  promotes_to:
    - core_growth_compounder
  strengthens:
    - swing_trade
    - speculative_growth
  notes: Successful breakouts that hold their gains can graduate into core compounders.
validation_gate:
  min_closed_paper_trades: 30
  min_win_rate: 0.55
  min_profit_factor: 1.3
  min_calendar_months: 6
  human_approval_required: true
prompt_context:
  summary: Technical breakout from multi-week consolidation. Volume dry-up during base, expansion on breakout. 3-21 day swing hold with trailing stops.
  key_questions:
    - Is the base structure clean and tradeable?
    - Did volume confirm the breakout?
    - Is the sector showing leadership?
vix_rules:
  max_vix_for_entry: 32
  elevated_vix_band:
    - 25
    - 35
  elevated_vix_changes:
    position_size_multiplier: 0.75
    require_aplus_grade: true
    require_sector_top_3: true
  extreme_vix_threshold: 35
  extreme_vix_action: pause_new_entries
  exit_holdings_at_vix:
  notes: "Breakouts in high VIX often fail — require best-of-breed setups only."
technical_indicators_required:
  gates:
    - id: EMA_50_RISING
      condition: EMA(50) slope > 0 over 5 days
      metric: ema_50_slope_5d
      operator: gt
      value: 0
    - id: BASE_LENGTH
      condition: consolidation base >= 15 days
      metric: base_days
      operator: gte
      value: 15
    - id: BREAKOUT_VOLUME
      condition: breakout day volume >= 1.5x 20-day avg
      metric: breakout_volume_ratio
      operator: gte
      value: 1.5
    - id: RSI_NOT_OVERBOUGHT
      condition: RSI(14) between 50 and 72
      metric: rsi_14
      operator: between
      value:
        - 50
        - 72
  preferred:
    - fib_618_as_stop
    - ema_200
    - atr_14_pct
    - sector_relative_strength
  irrelevant:
    - vwap
    - opening_range
performance_context:
  last_updated: '2026-05-26T06:30:01+00:00'
  closed_paper_trades: 0
  win_rate:
  avg_r_realized:
  profit_factor:
  max_drawdown_pct:
  expectancy_per_trade:
  best_trade_r:
  worst_trade_r:
  current_streak:
  ready_for_review: false
  review_thresholds:
    min_trades: 30
    min_months: 6
    min_profit_factor: 1.25
    min_win_rate: 0.5
  notes: Populated nightly by scripts/paper_performance_governance.py. Used by LLM prompts to evaluate proposal context.
freshness:
  bucket: MULTI_DAY
  ttl_days: 10
  eval_cadence: daily
  watchpool: true
  rollback_to_legacy: false
```
