# Config Export: config/strategies/core_growth_compounder.yaml

| Field | Value |
|-------|-------|
| **Original Path** | `config/strategies/core_growth_compounder.yaml` |
| **Git Commit** | `915876ff12f0988acccf1553f44dd50b0a75dd54` |
| **SHA256** | `aa65dba099d6b0ff9a6ddd21e894db0edafd80ad998d3d1638f6be9327d6427b` |
| **File Size** | 4180 bytes |

## Full Source

```yaml
strategy_id: core_growth_compounder
display_name: Core Growth Compounder
version: 1.0.0
status: UNVALIDATED
purpose: Blue-chip growth positions for long-term compounding. Core holdings like MSFT, AAPL, NVDA with dip-buying entry discipline.
eligible_accounts:
  - taxable
  - rollover_ira
  - roth_ira
timeframe: position_long
timeframe_class: POSITION
universe:
  price:
    min: 50.0
    max:
  float_m:
    max:
  rvol:
    min:
entry_criteria:
  - id: QUALITY_SCORE
    description: ROE >15%, debt/equity <1.5, consistent earnings growth
    metric: quality_composite
    operator: gte
    value: 80
  - id: PULLBACK_ENTRY
    description: Price within 10% of 52-week high or at key support level
    metric: pct_from_52w_high
    operator: gte
    value: -0.1
  - id: EARNINGS_GROWTH
    description: Forward EPS growth estimate >10%
    metric: fwd_eps_growth
    operator: gte
    value: 0.1
  - id: MOAT_RATING
    description: Wide or narrow economic moat with durable competitive advantage
    metric: moat_rating
    operator: in
    value:
      - wide
      - narrow
auto_disqualifiers:
  - id: EARNINGS_DECLINE
    description: Two consecutive quarters of declining earnings
  - id: DEBT_CRISIS
    description: Debt/equity ratio exceeds 2.0 with declining coverage
  - id: REGULATORY_RISK_ACUTE
    description: Active antitrust or major regulatory action pending
  - id: VALUATION_EXTREME
    description: Forward P/E exceeds 2x sector median without justification
exit_rules:
  stop_method: fundamental
  target_method: trailing
risk:
  risk_per_trade_pct: 0.01
  max_position_size: 25000
  max_daily_trades:
  target_rr: 3.0
scoring:
  min_score_go: 45
  min_score_wait: 30
lifecycle:
  proposal_expiry_hours: 720
  overnight_allowed: true
  max_hold_days:
execution:
  paper_allowed: true
  live_allowed: false
agent_responsibilities:
  maria: Verify fundamental quality, earnings trajectory, and competitive moat durability.
  risk: Assess valuation risk, concentration limits, and correlation with existing holdings.
  steph: Confirm account placement optimization and total portfolio allocation fit.
co_enables:
  promotes_to: []
  strengthens:
    - covered_call_income
    - dividend_growth_compounder
validation_gate:
  min_closed_paper_trades: 30
  min_win_rate: 0.55
  min_profit_factor: 1.3
  min_calendar_months: 6
  human_approval_required: true
prompt_context:
  summary: Core growth compounder for blue-chip names with durable competitive advantages. Long-term hold with fundamental stop criteria. Targets MSFT, AAPL, NVDA-class companies with pullback entry discipline.
  key_questions:
    - Is the competitive moat widening or narrowing?
    - Does the current valuation offer acceptable long-term return potential?
    - How does this position fit within overall portfolio growth allocation?
screen_filters:
  min_price: 50.0
  max_price: 5000.0
  min_market_cap_b: 50
  min_score: 0
  quality_focus: true
vix_rules:
  max_vix_for_entry: 45
  elevated_vix_band:
    - 25
    - 40
  elevated_vix_changes:
    position_size_multiplier: 1.0
    require_pullback_to_ema_50: true
  extreme_vix_threshold: 45
  extreme_vix_action: accelerate_new_entries
  exit_holdings_at_vix:
  notes: "Quality compounders pull back hardest in volatility — best entry zone."
technical_indicators_required:
  gates:
    - id: EMA_200_SUPPORT
      condition: price within 5% of EMA(200) on pullback
      metric: distance_from_ema_200
      operator: lte
      value: 0.05
  preferred:
    - rsi_14_below_50
    - fib_618_distance
  irrelevant:
    - vwap
    - opening_range
    - rsi_5
performance_context:
  last_updated: '2026-05-26T06:30:01+00:00'
  closed_paper_trades: 0
  win_rate:
  avg_r_realized:
  profit_factor:
  max_drawdown_pct:
  expectancy_per_trade:
  best_trade_r:
  worst_trade_r:
  current_streak:
  ready_for_review: false
  review_thresholds:
    min_trades: 30
    min_months: 6
    min_profit_factor: 1.25
    min_win_rate: 0.5
  notes: Populated nightly by scripts/paper_performance_governance.py. Used by LLM prompts to evaluate proposal context.
freshness:
  bucket: LONG_CYCLE
  ttl_days: 90
  eval_cadence: monthly
  watchpool: true
```
