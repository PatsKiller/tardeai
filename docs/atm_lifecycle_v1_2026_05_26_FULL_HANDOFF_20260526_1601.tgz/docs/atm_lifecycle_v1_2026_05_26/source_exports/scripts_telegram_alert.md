# Source Export: scripts/telegram_alert.py

| Field | Value |
|-------|-------|
| **Original Path** | `scripts/telegram_alert.py` |
| **Git Branch** | `main` |
| **Git Commit** | `915876f` |
| **Export Timestamp** | `2026-05-26T19:48:00Z` |
| **SHA256** | `3a422014f6bc378f2bd9984127c3deaa613da93d2278b154b84bbd0794c01307` |
| **File Size** | 12253 bytes |

## Full Source

```py
"""telegram_alert.py — Telegram bot alerts for Trade AI v12.

Setup (one time, 2 minutes):
  1. Open Telegram, search @BotFather
  2. Send /newbot — follow prompts, copy the bot token
  3. Add TELEGRAM_BOT_TOKEN=<token> to .env
  4. Message your new bot once (so it has a chat_id)
  5. Visit: https://api.telegram.org/bot<token>/getUpdates
     Copy the "chat" -> "id" value
  6. Add TELEGRAM_CHAT_ID=<id> to .env

Telegram supports Markdown formatting (bold *text*, italic _text_).
Messages limited to 4096 chars — long messages split automatically.
No cost. No Twilio account needed.
"""
from __future__ import annotations
import os
from typing import Any, Dict, List, Optional
import requests

TELEGRAM_API = "https://api.telegram.org/bot{token}/sendMessage"
MAX_MSG_LEN  = 4000    # leave headroom below 4096 hard limit


def _env(k: str, default: str = "") -> str:
    return os.getenv(k, default).strip()

def _enabled() -> bool:
    return _env("ENABLE_TELEGRAM", "true").lower() == "true"

def _token() -> str:
    return _env("TELEGRAM_BOT_TOKEN")

def _chat_ids() -> list:
    """Support comma-separated chat IDs for multiple recipients."""
    raw = _env("TELEGRAM_CHAT_ID")
    return [c.strip() for c in raw.split(",") if c.strip()]


def _smart_split(text: str, limit: int) -> list[str]:
    """Split text at newline boundaries, falling back to sentence then hard cut."""
    if len(text) <= limit:
        return [text]
    chunks = []
    while text:
        if len(text) <= limit:
            chunks.append(text)
            break
        # Try to split at last newline within limit
        cut = text.rfind("\n", 0, limit)
        if cut < limit // 2:
            # Try sentence boundary (. or !) within limit
            for sep in (". ", "! ", "? "):
                pos = text.rfind(sep, 0, limit)
                if pos > limit // 2:
                    cut = pos + len(sep)
                    break
        if cut < limit // 2:
            cut = limit  # hard cut as last resort
        chunks.append(text[:cut])
        text = text[cut:].lstrip("\n")
    return chunks


def _raw_send_telegram(message: str, chat_ids: list = None) -> bool:
    """Low-level Telegram send. No routing — called after router approval."""
    token = _token()
    targets = chat_ids or _chat_ids()
    if not token or not targets:
        return False
    try:
        chunks = _smart_split(message, MAX_MSG_LEN)
        for cid in targets:
            for chunk in chunks:
                resp = requests.post(
                    TELEGRAM_API.format(token=token),
                    json={"chat_id": cid, "text": chunk, "parse_mode": "Markdown"},
                    timeout=10,
                )
                if not resp.ok:
                    resp2 = requests.post(
                        TELEGRAM_API.format(token=token),
                        json={"chat_id": cid, "text": chunk},
                        timeout=10,
                    )
                    if not resp2.ok:
                        print(f"[telegram] Error to {cid}: {resp2.status_code}")
        return True
    except Exception as e:
        print(f"[telegram] Error: {e}")
        return False


def send_telegram(message: str, bypass_router: bool = False) -> bool:
    """Send a message via Telegram bot. Routes through operator alert policy.

    Args:
        message: The message to send.
        bypass_router: If True, skip the alert router (for P0 system alerts).
    """
    if not _enabled():
        return False
    if not _token() or not _chat_ids():
        print("[telegram] Skipped — TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID not set")
        return False

    # Route through central alert router unless bypassed
    if not bypass_router:
        try:
            from telegram_alert_router import should_send_telegram, mark_sent, classify_alert
            if not should_send_telegram(message):
                level = classify_alert(message)
                print(f"[telegram] Suppressed ({level}): {message[:60]}...")
                return False
            mark_sent(message)
        except ImportError:
            pass  # Router not available — send normally

    return _raw_send_telegram(message)


def build_telegram_message(
    scored_tickers: List[Dict[str, Any]],
    delta: Dict[str, Any],
    run_label: str,
    date_str: str,
    market_snapshot: Optional[Dict] = None,
    options_summary: Optional[Dict] = None,
    halt_data: Optional[Dict] = None,
    trade_plans: Optional[Dict] = None,
    short_summary: Optional[Dict] = None,
) -> str:
    """Build the full Telegram message. Mirrors WhatsApp format but adds v12 extras."""
    # Iris-aware categorization
    blocked     = [t for t in scored_tickers if t.get("disqualified")]
    downgraded  = [t for t in scored_tickers if t.get("decision_changed") and not t.get("disqualified")
                   and t.get("original_decision") == "GO"]
    go_tickers  = [t for t in scored_tickers if t.get("decision") == "GO" and not t.get("disqualified")]
    events      = delta.get("events", [])
    new_count   = len(delta.get("new_tickers", []))
    fade_count  = len(delta.get("faded", []))
    grade_up    = sum(1 for e in events if e.get("event") == "GRADE_UP")

    lines = [f"⚡ *Trade AI v12.1d [{run_label}]* | {date_str}", ""]

    # Market context
    if market_snapshot:
        indices = market_snapshot.get("indices", {})
        vix     = market_snapshot.get("vix", {})
        sectors = market_snapshot.get("sectors", [])
        breadth = market_snapshot.get("breadth_label", "Neutral")
        b_e = {"Bullish": "🟢", "Neutral": "🟡", "Bearish": "🔴"}.get(breadth, "🟡")

        # SPY / QQQ / IWM with green/red indicator per sign
        def _idx(sym):
            d = indices.get(sym, {})
            pct = d.get("change_percent", 0) or 0
            px  = d.get("price", 0) or 0
            col = "🟢" if pct > 0 else ("🔴" if pct < 0 else "⚪")
            sign = "+" if pct >= 0 else ""
            px_str = f" ${px:.2f}" if px else ""
            return f"{col} *{sym}* {sign}{pct:.2f}%{px_str}"

        vix_val = vix.get("price", 0) or 0
        vix_pct = vix.get("change_percent", 0) or 0
        vix_dir = vix.get("direction", "flat")
        v_e = "🔺" if "ris" in vix_dir or "spik" in vix_dir else ("🔻" if "fall" in vix_dir or "col" in vix_dir else "➡️")
        vix_sign = "+" if vix_pct >= 0 else ""

        # Top 3 leaders / bottom 3 laggards
        sorted_sectors = sorted(sectors, key=lambda s: s.get("change_percent", 0) or 0, reverse=True)
        leaders  = [f"{s['symbol']} {(s.get('change_percent',0) or 0):+.1f}%" for s in sorted_sectors[:3]]
        laggards = [f"{s['symbol']} {(s.get('change_percent',0) or 0):+.1f}%" for s in sorted_sectors[-3:]]

        lines += [
            "*📊 Market:*",
            f"  {_idx('SPY')}",
            f"  {_idx('QQQ')}",
            f"  {_idx('IWM')}",
            f"  {v_e} *VIX* {vix_val:.1f} ({vix_sign}{vix_pct:.1f}%) {vix_dir}",
            f"  {b_e} {breadth}",
            f"  ▲ {' · '.join(leaders)}",
            f"  ▼ {' · '.join(laggards)}",
            "",
        ]

    # Halt alerts (v12)
    if halt_data:
        halted  = halt_data.get("halted_tickers", [])
        resumed = halt_data.get("resumed_tickers", [])
        if halted:
            syms = ", ".join(h["symbol"] for h in halted[:5])
            lines.append(f"🚨 *HALTED:* {syms}")
        if resumed:
            syms = ", ".join(r["symbol"] for r in resumed[:5])
            lines.append(f"✅ *RESUMED:* {syms}")
        if halted or resumed:
            lines.append("")

    # Squeeze summary (v12)
    if short_summary and short_summary.get("any_squeeze"):
        top_sq = short_summary.get("top_squeezers", [])[:3]
        sq_str = "  ".join(f"{s['symbol']} {s['short_pct']:.0f}%" for s in top_sq)
        lines.append(f"🔥 *Short squeeze fuel:* {sq_str}")
        lines.append("")

    # Iris: blocked tickers (most critical — always first)
    if blocked:
        lines.append("🚫 *BLOCKED BY IRIS:*")
        for t in blocked:
            reason = (t.get("disqualification_reason") or t.get("critic_reasoning") or "flagged")[:90]
            orig = t.get("original_decision", "GO")
            lines.append(f"  ❌ *{t['symbol']}* (was {orig})")
            lines.append(f"     _{reason}_")
        lines.append("")

    # Iris: downgraded tickers
    if downgraded:
        lines.append("⬇ *DOWNGRADED BY IRIS:*")
        for t in downgraded:
            reason = (t.get("critic_reasoning") or "risk flag")[:80]
            lines.append(f"  ↓ *{t['symbol']}*: {t.get('original_decision','GO')} → {t['decision']}")
            lines.append(f"     _{reason}_")
        lines.append("")

    # GO-tier picks
    if go_tickers:
        lines.append("*🎯 GO-Tier Picks:*")
        for t in go_tickers[:5]:
            sym    = t["symbol"]
            score  = t["score"]
            rvol   = t.get("relative_volume", 0)
            s_arr  = t.get("score_arrow", "→")
            r_arr  = t.get("rvol_arrow", "→")
            sq_e   = t.get("squeeze_emoji", "")
            days   = t.get("consecutive_go_days", 1)
            top    = t.get("top_catalyst") or {}
            cat    = (top.get("title") or "No catalyst")[:55]
            emoji  = {"high_impact": "🔥", "medium_impact": "⚡", "low_impact": "📰"}.get(
                t.get("catalyst_tier", ""), "•")
            days_str = f"  📅 {days}d" if days > 1 else ""
            halt_str = "  🚨HALT" if t.get("is_halted") else ("  ✅RESUMED" if t.get("is_resumed") else "")
            plan = (trade_plans or {}).get(sym, {})
            plan_str = ""
            if plan:
                plan_str = (f"\n    💰 Entry: {plan.get('entry_zone','?')}  "
                            f"Stop: {plan.get('stop_loss','?')}  "
                            f"R1: {plan.get('target_r1','?')}  "
                            f"R:R {plan.get('risk_reward','?')}")
            # Add Ollama AI context if available from Stage 6 (free — already computed)
            ollama_line = ""
            ollama_flag = t.get("ollama_flag", "")
            ollama_sum = t.get("ollama_summary", "")
            ollama_risk = t.get("ollama_risk", "")
            if ollama_flag and ollama_flag not in ("NEUTRAL", ""):
                flag_emoji = {"GO":"🟢","WATCH":"👀","DILUTION":"⚠️","TRAP":"🚨","AVOID":"❌"}.get(ollama_flag, "•")
                ai_text = ollama_sum or ollama_risk or ""
                if ai_text:
                    ollama_line = f"\n  {flag_emoji} _{ollama_flag}: {ai_text[:60]}_"
            lines.append(
                f"  {emoji}{sq_e} *{sym}* ({score} {s_arr}) "
                f"RVOL {rvol:.1f}x {r_arr}{days_str}{halt_str}"
                f"\n  _{cat}_{plan_str}{ollama_line}"
            )
        lines.append("")
    else:
        lines.append("_No GO-tier setups this run._")
        lines.append("")

    # Options flow
    if options_summary and options_summary.get("total_sweeps", 0) > 0:
        lines.append(f"⚡ *Options:* {options_summary.get('sweep_summary_text','')}")
        lines.append("")

    # Delta summary
    parts = []
    if new_count:  parts.append(f"🆕 {new_count} new")
    if grade_up:   parts.append(f"📈 {grade_up} ↑")
    if fade_count: parts.append(f"👻 {fade_count} faded")
    if parts:
        lines += ["─" * 18, "  ".join(parts)]

    # Iris footer — only if critique ran
    critiqued = [t for t in scored_tickers if t.get("critic_verdict")]
    if critiqued:
        confirmed = sum(1 for t in critiqued if t.get("critic_verdict") == "CONFIRM")
        cat_replaced = sum(1 for t in scored_tickers if t.get("catalyst_verified") is False)
        iris_parts = [f"🔍 Iris: {len(critiqued)}/{len(scored_tickers)} reviewed"]
        iris_parts.append(f"{confirmed} confirmed")
        if blocked: iris_parts.append(f"{len(blocked)} blocked")
        if downgraded: iris_parts.append(f"{len(downgraded)} downgraded")
        if cat_replaced: iris_parts.append(f"{cat_replaced} catalyst replaced")
        lines.append("─" * 18)
        lines.append(" · ".join(iris_parts))

    return "\n".join(lines)
```
