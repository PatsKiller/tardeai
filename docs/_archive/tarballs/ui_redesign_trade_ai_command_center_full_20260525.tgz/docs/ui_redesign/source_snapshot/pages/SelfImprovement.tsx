import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import PageHeader from '../components/PageHeader'
import Card from '../components/Card'
import { useApi } from '../hooks/useApi'

const SC: Record<string, string> = {
  healthy:'#0ecb81', warning:'#f0b90b', degraded:'#f6465d',
  failed:'#f6465d', unknown:'#848e9c',
  urgent:'#f6465d', important:'#f0b90b', normal:'#4a90f4', info:'#848e9c',
}
const dot = (s: string) => <span style={{ display:'inline-block', width:8, height:8, borderRadius:4, background:SC[s]||'#848e9c', marginRight:6 }}/>
const btn: React.CSSProperties = { fontSize:10, padding:'4px 10px', border:'1px solid var(--border)', borderRadius:4, background:'var(--bg1)', color:'var(--text1)', cursor:'pointer' }

export default function SelfImprovement() {
  const navigate = useNavigate()
  const [rk, setRk] = useState(0)
  const { data: status } = useApi<any>(`/api/v2/self-improvement/status?_r=${rk}`)
  const { data: queue } = useApi<any>(`/api/v2/self-improvement/review-queue?_r=${rk}`)
  const { data: health } = useApi<any>(`/api/v2/self-improvement/component-health?_r=${rk}`)

  const s = status || {}
  const safety = s.safety || {}
  const paper = s.paper_trading || {}
  const learning = s.learning || {}
  const agents = s.agent_calibration || {}
  const bt = s.backtesting || {}
  const pipe = s.pipeline || {}
  const warnings = s.warnings || []
  const actions = s.recommended_actions || []
  const queueItems = (Array.isArray(queue) ? queue : queue?.items || queue?.data || []) as any[]
  const components = (Array.isArray(health) ? health : health?.components || health?.data || []) as any[]

  const link = (route: string, label: string) => (
    <button onClick={() => navigate(route)} style={{ ...btn, fontSize:9, padding:'2px 8px' }}>{label} →</button>
  )

  return (
    <div style={{ padding:'16px 24px', maxWidth:1200 }}>
      <PageHeader title="Self-Improvement Command Center" subtitle="Unified operator view — read-only aggregation across all intelligence layers" actions={
        <button onClick={() => setRk(k=>k+1)} style={btn}>Refresh</button>
      }/>

      {/* Safety Banner */}
      <div style={{ padding:'10px 16px', marginBottom:14, borderRadius:6,
        background: safety.allowed ? 'rgba(246,70,93,.15)' : 'rgba(14,203,129,.08)',
        border: `1px solid ${safety.allowed ? '#f6465d' : '#0ecb81'}`,
        display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div>
          <span style={{ fontSize:14, fontWeight:700, color: safety.allowed ? '#f6465d' : '#0ecb81' }}>
            {safety.allowed ? 'LIVE TRADING ALLOWED — DANGER' : 'PAPER MODE ACTIVE — BLOCKED'}
          </span>
          <span style={{ fontSize:11, color:'var(--text2)', marginLeft:12 }}>
            Holdings: ${(safety.holdings_value||0).toLocaleString()} | Guard: {safety.holdings_guard ? 'PASS' : 'FAIL'}
          </span>
        </div>
        <span style={{ fontSize:10, color:'var(--text3)' }}>{(safety.blocked_reasons||[]).length} block reasons</span>
      </div>

      {/* Overview Cards — clickable */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(160px,1fr))', gap:8, marginBottom:14 }}>
        {([['Paper Closed', paper.closed, paper.low_sample ? 'LOW SAMPLE' : '', '/paper-journal'],
          ['Paper Open', paper.open, '', '/paper-status'],
          ['Pending Proposals', paper.pending_proposals, '', '/paper-proposals'],
          ['Learning Recs', learning.recommendations_pending, learning.recommendations_pending > 0 ? 'REVIEW' : '', '/governance?tab=learning'],
          ['Config Proposals', learning.config_proposals_pending, learning.config_proposals_pending > 0 ? 'APPROVAL' : '', '/governance?tab=learning'],
          ['Agent Recs', agents.recommendations, '', '/agent-calibration'],
          ['Backtest Runs', bt.runs, '', '/backtesting'],
          ['Pipeline Fails', pipe.failures, pipe.failures > 0 ? 'CHECK' : '', '/pipeline'],
          ['Warnings', warnings.length, '', ''],
        ] as [string, any, string, string][]).map(([label, val, badge, route]) => (
          <div key={label} onClick={route ? () => navigate(route) : undefined}
            style={{ padding:'8px 12px', border:'1px solid var(--border)', borderRadius:6,
            background: badge ? 'rgba(240,185,11,.05)' : 'transparent',
            cursor: route ? 'pointer' : 'default', transition: 'background 120ms' }}
            onMouseEnter={route ? (e) => { e.currentTarget.style.background = 'var(--bg3)' } : undefined}
            onMouseLeave={route ? (e) => { e.currentTarget.style.background = badge ? 'rgba(240,185,11,.05)' : 'transparent' } : undefined}>
            <div style={{ fontSize:10, color:'#848e9c' }}>{label}</div>
            <div style={{ fontSize:20, fontWeight:700 }}>{val ?? 0}</div>
            {badge && <div style={{ fontSize:9, color:'#f0b90b', fontWeight:600 }}>{badge}</div>}
            {route && <div style={{ fontSize:8, color:'var(--accent)', marginTop:2 }}>View →</div>}
          </div>
        ))}
      </div>

      {/* Operator Review Queue */}
      {queueItems.length > 0 && (
        <Card title={`Operator Review Queue (${queueItems.length})`} style={{ marginBottom:14 }}>
          {queueItems.map((q: any) => (
            <div key={q.review_item_id} style={{ padding:'6px 0', borderBottom:'1px solid var(--border)',
              display:'flex', justifyContent:'space-between', alignItems:'center' }}>
              <div>
                {dot(q.severity)}
                <span style={{ fontSize:11 }}>{q.title}</span>
                {q.requires_action && <span style={{ fontSize:9, color:'#f0b90b', marginLeft:6 }}>ACTION</span>}
              </div>
              {q.linked_dashboard_route && link(q.linked_dashboard_route, q.source_domain)}
            </div>
          ))}
        </Card>
      )}

      {/* Component Health */}
      <Card title="Component Health" style={{ marginBottom:14 }}>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(200px,1fr))', gap:6 }}>
          {components.map((c: any) => {
            const routes: Record<string, string> = {
              'agent-calibration': '/agent-calibration', 'backtesting': '/backtesting',
              'execution-revalidation': '/paper-status', 'ingestion-sources': '/intelligence',
              'learning-governance': '/governance?tab=learning', 'paper-trading': '/paper-journal',
              'pipeline-controller': '/pipeline', 'safety-gate': '/risk', 'weekly-digest': '/weekly-learning',
            }
            const route = routes[c.component_key] || ''
            return (
              <div key={c.component_key} onClick={route ? () => navigate(route) : undefined}
                style={{ padding:'6px 10px', border:'1px solid var(--border)', borderRadius:4,
                fontSize:11, display:'flex', justifyContent:'space-between', cursor: route ? 'pointer' : 'default' }}
                onMouseEnter={route ? (e) => { e.currentTarget.style.background = 'var(--bg3)' } : undefined}
                onMouseLeave={route ? (e) => { e.currentTarget.style.background = '' } : undefined}>
                <span>{dot(c.status)}{c.component_name}</span>
                <span style={{ color: route ? 'var(--accent)' : 'var(--text3)', fontSize:10 }}>{c.status} {route ? '→' : ''}</span>
              </div>
            )
          })}
          {components.length === 0 && <div style={{ color:'#848e9c', fontSize:11, padding:8 }}>Run snapshot first to populate health</div>}
        </div>
      </Card>

      {/* Quick Links */}
      <Card title="Subsystem Dashboards" style={{ marginBottom:14 }}>
        <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
          {[
            ['/governance?tab=learning', 'Learning Governance'],
            ['/agent-calibration', 'Agent Calibration'],
            ['/weekly-learning', 'Weekly Learning'],
            ['/backtesting', 'Backtesting'],
            ['/paper-journal', 'Paper Trade Intelligence'],
            ['/pipeline', 'Pipeline Controller'],
            ['/paper-proposals', 'Trade Proposals'],
            ['/risk', 'Risk Management'],
          ].map(([route, label]) => (
            <button key={route} onClick={() => navigate(route)} style={{ ...btn, fontWeight:600 }}>{label} →</button>
          ))}
        </div>
      </Card>

      {/* Warnings */}
      {warnings.length > 0 && (
        <Card title={`Warnings (${warnings.length})`}>
          {warnings.map((w: any, i: number) => {
            const msg = w.msg || ''
            const route = msg.includes('closed trades') ? '/paper-journal'
              : msg.includes('recommendation') ? '/governance?tab=learning'
              : msg.includes('material change') || msg.includes('reapproval') ? '/paper-proposals'
              : msg.includes('pipeline') ? '/pipeline'
              : msg.includes('stop') ? '/risk'
              : ''
            return (
              <div key={i} onClick={route ? () => navigate(route) : undefined}
                style={{ fontSize:11, padding:'6px 0', borderBottom:'1px solid var(--border)',
                cursor: route ? 'pointer' : 'default', display:'flex', justifyContent:'space-between', alignItems:'center' }}
                onMouseEnter={route ? (e) => { e.currentTarget.style.background = 'var(--bg3)' } : undefined}
                onMouseLeave={route ? (e) => { e.currentTarget.style.background = '' } : undefined}>
                <span>{dot(w.type === 'low_sample' ? 'info' : 'warning')}{msg}</span>
                {route && <span style={{ fontSize:9, color:'var(--accent)' }}>View →</span>}
              </div>
            )
          })}
        </Card>
      )}
    </div>
  )
}
