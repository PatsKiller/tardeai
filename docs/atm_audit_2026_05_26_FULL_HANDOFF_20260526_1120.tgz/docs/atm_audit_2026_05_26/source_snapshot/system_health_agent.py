#!/usr/bin/env python3
"""system_health_agent.py — Execution Integrity Agent.

Continuously monitors every cron job, process, and execution path.
Detects silent failures, lock contention, stale output, abnormal runtimes.
Self-heals with retries. Escalates via central alert router.

Schedule: */5 * * * 1-5 (every 5 min weekdays), */15 * * * 0,6 (every 15 min weekends)

NO bypass_router. NO direct Telegram. ALL alerts through central router.
"""
import argparse, json, logging, os, subprocess, sys, time
from datetime import datetime, timezone, timedelta
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT / "scripts"))

from dotenv import load_dotenv
load_dotenv(PROJECT_ROOT / ".env")

logging.basicConfig(level=logging.INFO, format="%(asctime)s [health-agent] %(message)s")
log = logging.getLogger("system_health_agent")

# ── Configuration: Every monitored component ─────────────────────────────────
# schedule: cron-style human readable, for display
# log_file: path relative to PROJECT_ROOT/logs
# max_age_min: max minutes since last log output before flagged stale
# max_runtime_sec: max expected runtime before flagged slow
# critical: if True, failure triggers P0 escalation
# retry_cmd: command to retry on failure (relative to PROJECT_ROOT)
# downstream: what breaks if this fails
MONITORED_COMPONENTS = [
    # ── Pipeline Core ──
    {"component": "trade_ai_orchestrator", "display": "Trade AI Orchestrator",
     "schedule": "0 9,10,12,14,16 * * 1-5", "log_file": "screener_pm.log",
     "max_age_min": 180, "max_runtime_sec": 600, "critical": True,
     "retry_cmd": ".venv/bin/python scripts/trade_ai_orchestrator.py --run-label 0900 --no-llm --no-alerts --allow-underfilled",
     "downstream": "strategy_signals, proposals, ATM execution",
     "lock_file": "/tmp/screener_pm.lock"},
    {"component": "auto_proposal_generator", "display": "Auto Proposal Generator",
     "schedule": "*/30 9-16 * * 1-5", "log_file": "auto_proposal.log",
     "max_age_min": 60, "max_runtime_sec": 300, "critical": True,
     "retry_cmd": ".venv/bin/python scripts/auto_proposal_generator.py --today --apply",
     "downstream": "proposals, ATM execution"},
    {"component": "incubator_proposal_promoter", "display": "Incubator Promoter",
     "schedule": "0 7-17 * * 1-5", "log_file": "incubator_promoter.log",
     "max_age_min": 180, "max_runtime_sec": 300, "critical": True,
     "retry_cmd": ".venv/bin/python scripts/incubator_proposal_promoter.py --run",
     "downstream": "proposals from incubator",
     "lock_file": "/tmp/incubator_promoter.lock"},
    {"component": "finviz_screener_runner", "display": "Finviz Screener",
     "schedule": "0 8 * * 1-5", "log_file": "finviz_screener.log",
     "max_age_min": 1500, "max_runtime_sec": 600, "critical": True,
     "retry_cmd": ".venv/bin/python scripts/finviz_screener_runner.py --apply",
     "downstream": "scanner input data"},
    {"component": "news_ingestion", "display": "News Ingestion",
     "schedule": "0 6,12,18 * * *", "log_file": "news_ingestion.log",
     "max_age_min": 480, "max_runtime_sec": 600, "critical": True,
     "downstream": "catalyst detection, news alerts"},

    # ── Trade Monitoring ──
    {"component": "unified_stop_supervisor", "display": "Stop Supervisor",
     "schedule": "*/3 9-16 * * 1-5", "log_file": "unified_stop_supervisor.log",
     "max_age_min": 10, "max_runtime_sec": 120, "critical": True,
     "retry_cmd": ".venv/bin/python scripts/unified_stop_supervisor.py --apply",
     "downstream": "trailing stops, target exits, stop monitoring"},
    # paper_trade_monitor replaced by unified_stop_supervisor (STOP-V2.2)
    {"component": "alpaca_reconciler", "display": "Alpaca Reconciler",
     "schedule": "5 16 * * 1-5", "log_file": "alpaca_reconciler.log",
     "max_age_min": 1500, "max_runtime_sec": 60, "critical": False,
     "downstream": "DB-broker sync"},

    # ── Data Pipeline ──
    {"component": "finviz_enrichment", "display": "Finviz Enrichment",
     "schedule": "10 7 * * 1-5", "log_file": "finviz_enrichment.log",
     "max_age_min": 1500, "max_runtime_sec": 600, "critical": False,
     "downstream": "enriched scanner data"},
    {"component": "price_db_sync", "display": "Price DB Sync",
     "schedule": "20 7 * * 1-5", "log_file": "price_db_sync.log",
     "max_age_min": 1500, "max_runtime_sec": 600, "critical": False,
     "downstream": "price data freshness"},
    {"component": "rag_indexer", "display": "RAG Indexer",
     "schedule": "0 */4 * * *", "log_file": "rag_indexer.log",
     "max_age_min": 300, "max_runtime_sec": 600, "critical": False,
     "downstream": "agent context, RAG search"},
    {"component": "indicator_engine", "display": "Indicator Engine",
     "schedule": "0 8 * * 1-5", "log_file": "indicator_engine.log",
     "max_age_min": 1500, "max_runtime_sec": 900, "critical": False,
     "downstream": "technical indicators"},

    # ── Agents ──
    {"component": "aegis_morning_brief", "display": "Aegis Morning Brief",
     "schedule": "5 8 * * 1-5", "log_file": "aegis_brief.log",
     "max_age_min": 1500, "max_runtime_sec": 300, "critical": False,
     "downstream": "daily brief delivery"},
    {"component": "telegram_command_handler", "display": "Telegram Bot Daemon",
     "schedule": "*/2 * * * *", "log_file": "telegram_commands.log",
     "max_age_min": 5, "max_runtime_sec": 60, "critical": True,
     "downstream": "operator commands, approval buttons"},

    # ── Cleanup & Governance ──
    {"component": "cleanup_stale_proposals", "display": "Stale Proposal Cleanup",
     "schedule": "0 10,15 * * 1-5", "log_file": "cleanup_stale_proposals.log",
     "max_age_min": 1500, "max_runtime_sec": 60, "critical": False,
     "downstream": "proposal hygiene"},
    {"component": "pipeline_watchdog", "display": "Pipeline Watchdog",
     "schedule": "0 */2 * * *", "log_file": "pipeline_watchdog.log",
     "max_age_min": 150, "max_runtime_sec": 300, "critical": True,
     "downstream": "pipeline self-healing"},

    # ── TCA ──
    {"component": "tca_analyzer", "display": "TCA Execution Quality",
     "schedule": "30 16 * * 1-5", "log_file": "tca_analyzer.log",
     "max_age_min": 1500, "max_runtime_sec": 60, "critical": False,
     "downstream": "execution quality page"},

    # ── Quote Refresh ──
    {"component": "proactive_quote_refresh", "display": "Quote Refresh",
     "schedule": "*/5 9-15 * * 1-5", "log_file": "proactive_quote_refresh_cron.log",
     "max_age_min": 15, "max_runtime_sec": 120, "critical": False,
     "downstream": "proposal price freshness"},
]

MAX_RETRIES = 2


def _get_conn():
    try:
        from db_adapter import _get_conn as _gc
        return _gc()
    except Exception:
        return None


def _log_event(conn, component, event_type, severity, message, action=None, success=None):
    try:
        cur = conn.cursor()
        cur.execute("""INSERT INTO system_health_events
            (component, event_type, severity, message, action_taken, success)
            VALUES (%s, %s, %s, %s, %s, %s)""",
            [component, event_type, severity, message[:500] if message else None,
             action[:200] if action else None, success])
        conn.commit()
    except Exception as e:
        log.warning(f"Failed to log event: {e}")


def _send_alert(message, urgent=False):
    """Send alert through central router. NEVER bypass."""
    try:
        from telegram_alert import send_telegram
        send_telegram(message)
    except Exception as e:
        log.error(f"Alert send failed: {e}")


def _check_log_freshness(log_file, max_age_min):
    """Check if log file has recent output."""
    log_path = PROJECT_ROOT / "logs" / log_file
    if not log_path.exists():
        return {"status": "MISSING", "age_min": None, "last_line": None}
    try:
        mtime = datetime.fromtimestamp(log_path.stat().st_mtime, tz=timezone.utc)
        age_min = (datetime.now(timezone.utc) - mtime).total_seconds() / 60
        last_line = ""
        with open(log_path, 'rb') as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - 500))
            last_line = f.read().decode('utf-8', errors='replace').strip().split('\n')[-1][:200]
        if age_min > max_age_min:
            return {"status": "STALE", "age_min": round(age_min, 1), "last_line": last_line}
        return {"status": "OK", "age_min": round(age_min, 1), "last_line": last_line}
    except Exception as e:
        return {"status": "ERROR", "age_min": None, "last_line": str(e)[:100]}


def _check_lock_contention(lock_file):
    """Check if a lock file exists and if the holding process is alive."""
    if not lock_file:
        return {"status": "NO_LOCK", "pid": None, "alive": None}
    pid_file = f"{lock_file}.pid"
    if not os.path.exists(pid_file):
        return {"status": "FREE", "pid": None, "alive": None}
    try:
        pid = int(open(pid_file).read().strip())
        alive = os.path.exists(f"/proc/{pid}")
        if alive:
            # Check how long it's been running
            try:
                stat = os.stat(f"/proc/{pid}")
                start_time = datetime.fromtimestamp(stat.st_ctime, tz=timezone.utc)
                runtime = (datetime.now(timezone.utc) - start_time).total_seconds()
                return {"status": "LOCKED", "pid": pid, "alive": True, "runtime_sec": round(runtime)}
            except Exception:
                return {"status": "LOCKED", "pid": pid, "alive": True}
        else:
            return {"status": "STALE_LOCK", "pid": pid, "alive": False}
    except Exception:
        return {"status": "UNKNOWN", "pid": None, "alive": None}


def _check_output_validity(component, log_file):
    """Check if the last run produced meaningful output (not just errors)."""
    log_path = PROJECT_ROOT / "logs" / log_file
    if not log_path.exists():
        return {"valid": False, "reason": "log_missing"}
    try:
        with open(log_path, 'rb') as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - 2000))
            tail = f.read().decode('utf-8', errors='replace')
        # Check for common failure patterns
        if "Usage:" in tail and "error:" in tail.lower():
            return {"valid": False, "reason": "usage_error_likely_misconfigured"}
        if "Traceback" in tail and "Error" in tail:
            return {"valid": False, "reason": "python_exception"}
        if tail.count("ERROR") > 5:
            return {"valid": False, "reason": "excessive_errors"}
        return {"valid": True, "reason": "ok"}
    except Exception:
        return {"valid": False, "reason": "read_error"}


def _attempt_retry(comp, conn):
    """Attempt automatic retry of a failed component. Max 2 retries per day."""
    cmd = comp.get("retry_cmd")
    if not cmd:
        return False
    component = comp["component"]

    # Check retry count today
    try:
        cur = conn.cursor()
        cur.execute("""SELECT COUNT(*) FROM system_health_events
            WHERE component=%s AND event_type='RETRY' AND created_at > NOW() - INTERVAL '24 hours'""",
            [component])
        retries_today = cur.fetchone()[0] or 0
        if retries_today >= MAX_RETRIES:
            _log_event(conn, component, "RETRY_EXHAUSTED", "CRITICAL",
                       f"Max retries ({MAX_RETRIES}) exhausted today", success=False)
            return False
    except Exception:
        pass

    # Clear stale lock if present
    lock_file = comp.get("lock_file")
    if lock_file:
        lock_info = _check_lock_contention(lock_file)
        if lock_info["status"] == "STALE_LOCK":
            try:
                os.remove(f"{lock_file}.pid")
                _log_event(conn, component, "LOCK_CLEARED", "WARN",
                           f"Cleared stale lock {lock_file} (dead PID {lock_info['pid']})",
                           action="rm stale .pid", success=True)
            except Exception:
                pass

    log.info(f"[retry] {component} — attempt {retries_today + 1}/{MAX_RETRIES}")
    try:
        result = subprocess.run(
            cmd, shell=True, timeout=comp.get("max_runtime_sec", 300),
            capture_output=True, text=True, cwd=str(PROJECT_ROOT))
        success = result.returncode == 0
        _log_event(conn, component, "RETRY", "INFO" if success else "WARN",
                   f"exit={result.returncode} stdout={result.stdout[-200:]}" if success
                   else f"exit={result.returncode} stderr={result.stderr[-200:]}",
                   action=cmd[:100], success=success)
        return success
    except subprocess.TimeoutExpired:
        _log_event(conn, component, "RETRY_TIMEOUT", "WARN",
                   f"Retry timed out after {comp.get('max_runtime_sec', 300)}s",
                   action=cmd[:100], success=False)
        return False
    except Exception as e:
        _log_event(conn, component, "RETRY_ERROR", "WARN", str(e)[:200],
                   action=cmd[:100], success=False)
        return False


def _escalate(comp, check_result, conn):
    """Escalate a failure to operator via central alert router. Dedup: max 1 per component per 2 hours."""
    component = comp["component"]
    severity = "CRITICAL" if comp.get("critical") else "WARN"

    # Dedup: don't spam same escalation within 2 hours
    try:
        cur = conn.cursor()
        cur.execute("""SELECT COUNT(*) FROM system_health_events
            WHERE component=%s AND event_type='ESCALATION'
            AND created_at > NOW() - INTERVAL '2 hours'""", [component])
        if (cur.fetchone()[0] or 0) > 0:
            _log_event(conn, component, "ESCALATION_DEDUPED", severity,
                       f"Suppressed duplicate escalation (2h window)", success=True)
            return
    except Exception:
        pass

    msg_lines = [
        f"{'🚨' if severity == 'CRITICAL' else '⚠️'} SYSTEM HEALTH: {comp['display']} — {check_result['status']}",
        "",
        f"Component: {component}",
        f"Expected: {comp.get('schedule', 'unknown')}",
        f"Last output: {check_result.get('age_min', '?')} min ago",
        f"Status: {check_result['status']}",
    ]
    if check_result.get("last_error"):
        msg_lines.append(f"Error: {check_result['last_error'][:150]}")
    if comp.get("downstream"):
        msg_lines.append(f"Impact: {comp['downstream']}")
    if check_result.get("action_taken"):
        msg_lines.append(f"Action: {check_result['action_taken']}")
    # Add actionable fix instruction
    if comp.get("retry_cmd"):
        msg_lines.append(f"Fix: {comp['retry_cmd'][:100]}")
    else:
        msg_lines.append("Fix: Check logs and restart manually")

    msg = "\n".join(msg_lines)
    _send_alert(msg)
    _log_event(conn, component, "ESCALATION", severity, msg[:500],
               action="telegram_alert", success=True)


def run_health_check(dry_run=True, verbose=False):
    """Run all health checks. Returns full report."""
    conn = _get_conn()
    if not conn:
        log.error("No DB connection")
        return {"error": "no_db"}

    now = datetime.now(timezone.utc)
    report = {
        "timestamp": now.isoformat(),
        "mode": "dry_run" if dry_run else "active",
        "checks": [],
        "summary": {"ok": 0, "stale": 0, "missing": 0, "failed": 0,
                     "locked": 0, "retried": 0, "escalated": 0},
    }

    for comp in MONITORED_COMPONENTS:
        component = comp["component"]
        log_file = comp.get("log_file", "")

        # 1. Check log freshness
        freshness = _check_log_freshness(log_file, comp.get("max_age_min", 60))

        # 2. Check lock contention
        lock_info = _check_lock_contention(comp.get("lock_file"))

        # 3. Check output validity
        output_check = _check_output_validity(component, log_file)

        # Build check result
        check = {
            "component": component,
            "display": comp.get("display", component),
            "critical": comp.get("critical", False),
            "schedule": comp.get("schedule", ""),
            "status": freshness["status"],
            "age_min": freshness.get("age_min"),
            "last_line": (freshness.get("last_line") or "")[:100],
            "lock": lock_info["status"],
            "lock_pid": lock_info.get("pid"),
            "lock_runtime": lock_info.get("runtime_sec"),
            "output_valid": output_check.get("valid", True),
            "output_reason": output_check.get("reason", ""),
            "downstream": comp.get("downstream", ""),
            "action_taken": None,
            "last_error": None,
        }

        # 4. Determine action
        needs_action = False
        if freshness["status"] in ("STALE", "MISSING"):
            needs_action = True
            report["summary"]["stale" if freshness["status"] == "STALE" else "missing"] += 1
        elif not output_check.get("valid", True):
            needs_action = True
            check["status"] = "OUTPUT_INVALID"
            check["last_error"] = output_check.get("reason", "unknown")
            report["summary"]["failed"] += 1
        elif lock_info["status"] == "STALE_LOCK":
            needs_action = True
            check["status"] = "STALE_LOCK"
            report["summary"]["locked"] += 1
        elif lock_info["status"] == "LOCKED" and lock_info.get("runtime_sec", 0) > comp.get("max_runtime_sec", 600):
            needs_action = True
            check["status"] = "LOCK_TIMEOUT"
            check["last_error"] = f"Process {lock_info['pid']} running {lock_info['runtime_sec']}s (max {comp.get('max_runtime_sec')}s)"
            report["summary"]["locked"] += 1
        else:
            report["summary"]["ok"] += 1

        # 5. Self-heal
        if needs_action and not dry_run:
            # Try retry first
            if comp.get("retry_cmd"):
                success = _attempt_retry(comp, conn)
                check["action_taken"] = "retry_success" if success else "retry_failed"
                report["summary"]["retried"] += 1
                if success:
                    check["status"] = "RECOVERED"
                    _log_event(conn, component, "RECOVERED", "INFO",
                               f"Self-healed via retry", action=comp["retry_cmd"][:100], success=True)
                else:
                    # Escalate
                    if comp.get("critical"):
                        _escalate(comp, check, conn)
                        check["action_taken"] = "retry_failed_escalated"
                        report["summary"]["escalated"] += 1
            elif comp.get("critical"):
                # No retry cmd but critical — escalate immediately
                _escalate(comp, check, conn)
                check["action_taken"] = "escalated_no_retry"
                report["summary"]["escalated"] += 1

        # 6. Persist check result
        try:
            cur = conn.cursor()
            cur.execute("""INSERT INTO system_health_checks
                (check_type, component, status, expected_schedule, last_success_at,
                 last_failure_at, last_run_duration_sec, expected_max_duration_sec,
                 failure_count, retry_count, last_error, last_action, downstream_impact, severity)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                ["cron_health", component, check["status"], comp.get("schedule"),
                 now if check["status"] == "OK" else None,
                 now if check["status"] not in ("OK", "RECOVERED") else None,
                 None, comp.get("max_runtime_sec"),
                 1 if check["status"] not in ("OK", "RECOVERED") else 0,
                 1 if (check.get("action_taken") or "").startswith("retry") else 0,
                 check.get("last_error"), check.get("action_taken"),
                 comp.get("downstream"),
                 "CRITICAL" if comp.get("critical") and needs_action else "INFO"])
            conn.commit()
        except Exception as e:
            log.warning(f"Failed to persist check for {component}: {e}")

        if verbose:
            icon = "✅" if check["status"] == "OK" else "🔄" if check["status"] == "RECOVERED" else "❌"
            log.info(f"  {icon} {comp['display']:30s} status={check['status']:15s} age={check.get('age_min', '?')}min lock={check['lock']}")

        report["checks"].append(check)

    conn.close()
    return report


def main():
    p = argparse.ArgumentParser(description="System Health Execution Integrity Agent")
    p.add_argument("--dry-run", action="store_true", default=True)
    p.add_argument("--apply", action="store_true")
    p.add_argument("--verbose", action="store_true")
    p.add_argument("--output-json", type=str)
    args = p.parse_args()
    if args.apply:
        args.dry_run = False

    report = run_health_check(dry_run=args.dry_run, verbose=args.verbose)

    s = report.get("summary", {})
    mode = "DRY RUN" if args.dry_run else "ACTIVE"
    total = sum(s.values())
    log.info(f"[{mode}] Health check complete: {s['ok']}/{total} OK, "
             f"{s['stale']} stale, {s['missing']} missing, {s['failed']} failed, "
             f"{s['locked']} locked, {s['retried']} retried, {s['escalated']} escalated")

    if args.output_json:
        Path(args.output_json).parent.mkdir(parents=True, exist_ok=True)
        Path(args.output_json).write_text(json.dumps(report, indent=2, default=str))

    # Return non-zero if any critical component is down
    critical_down = [c for c in report.get("checks", [])
                     if c.get("critical") and c.get("status") not in ("OK", "RECOVERED")]
    if critical_down and not args.dry_run:
        sys.exit(1)


if __name__ == "__main__":
    main()
