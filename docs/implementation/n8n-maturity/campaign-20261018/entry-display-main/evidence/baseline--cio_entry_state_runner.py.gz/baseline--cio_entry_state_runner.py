#!/usr/bin/env python3
"""CIO entry state runner — evaluate tracked names, record the CIO's call, alert the operator and the CIO.

Operator decisions 2026-09-15: the CIO owns the entry / BUY state; the operator is alerted and the CIO
is alerted; small caps are in scope and labeled. Deterministic, no model calls, advisory only — it
never sizes, orders, sets stops or touches a broker.

Tracked names = active watchlist items ∪ re-entry desk rows ∪ pending proposals. For each name the
freshest plan wins: re-entry desk row (live price, zone, stop, target, wash window) → latest
watchlist_entry_plans row within 7 days → strategy card levels.

Default is a dry run (prints the would-be states and messages). --apply:
  * appends a cio_entry_states row whenever a symbol's state changes;
  * writes a cio_decisions row (action BUY_READY / ENTRY_NEAR, action_class 'entry') on entry into
    an actionable state, at most once per symbol, state and day;
  * sends the operator alert (routes IMMEDIATE as cio_entry_state) and the CIO desk message, and
    emits watch.new_signal on the CIO event bus so the CIO wakes on it;
  * writes data/runtime/cio_entry_state_last_run.json.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT))

from lib import cio_entry_state as ces  # noqa: E402
from lib.market_cap_label import cap_label  # noqa: E402

STATE_DIR = PROJECT_ROOT / "data" / "portfolios" / "state"
DESK_PATH = PROJECT_ROOT / "data" / "runtime" / "reentry_decision_desk_latest.json"
RECEIPT = PROJECT_ROOT / "data" / "runtime" / "cio_entry_state_last_run.json"
MAX_ALERTS_PER_RUN = 8
PACKET_DIR = PROJECT_ROOT / "data" / "runtime" / "buy_ready_packets"
REVIEW_PENDING = PROJECT_ROOT / "data" / "runtime" / "cio_entry_review_pending.jsonl"

DDL = """CREATE TABLE IF NOT EXISTS cio_entry_states (
    id bigserial PRIMARY KEY,
    symbol text NOT NULL,
    state text NOT NULL,
    prior_state text,
    evaluated_at timestamptz NOT NULL DEFAULT now(),
    alerted boolean NOT NULL DEFAULT false,
    details jsonb NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS idx_cio_entry_states_symbol_time ON cio_entry_states (symbol, evaluated_at DESC);"""


def _conn():
    from db_adapter import _get_conn
    return _get_conn()


def _load_json(path: Path, default):
    try:
        return json.loads(path.read_text())
    except Exception:
        return default


def _age_h(ts) -> float | None:
    if ts is None or not hasattr(ts, "timestamp"):
        return None
    from datetime import datetime, timezone
    return (datetime.now(timezone.utc).timestamp() - ts.timestamp()) / 3600.0


def _after_open(ts) -> bool:
    """True when the plan was made after today's 09:30 ET open (a re-plan after any move)."""
    if ts is None or not hasattr(ts, "astimezone"):
        return False
    from datetime import datetime
    from zoneinfo import ZoneInfo
    et = ZoneInfo("America/New_York")
    now = datetime.now(et)
    return ts.astimezone(et) >= now.replace(hour=9, minute=30, second=0, microsecond=0)


def gather(cur) -> dict[str, dict]:
    """symbol → evidence dict for cio_entry_state.evaluate."""
    ev: dict[str, dict] = {}
    desk = _load_json(DESK_PATH, {})
    for r in desk.get("rows") or []:
        sym = str(r.get("symbol") or "").upper()
        if not sym:
            continue
        ev[sym] = {"symbol": sym, "price": r.get("price"), "quote_age_h": r.get("price_age_h"),
                   "entry_low": r.get("entry_low"), "entry_high": r.get("entry_high"), "stop": r.get("stop"),
                   "target": r.get("target"), "atr": r.get("atr"), "wash_blocked": r.get("wash_blocked"),
                   "held": r.get("held"), "earnings_date": r.get("earnings_date"), "rsi": r.get("rsi"),
                   "catalyst": (r.get("catalyst") or {}).get("headline") if isinstance(r.get("catalyst"), dict) else None,
                   "plan_source": "reentry_desk"}
    cur.execute("""SELECT upper(symbol) s FROM watchlist_items WHERE status='active'
                   UNION SELECT upper(symbol) FROM paper_trade_proposals WHERE status='PENDING'""")
    tracked = {row[0] for row in cur.fetchall()} | set(ev)
    # Swing entry alerts have ONE sender (operator 2026-10-19): watchlist_entry_planner persists its
    # alert-eligible near-entry/ready plans and this runner pages them (lib.entry_alert_context).
    from lib.entry_alert_context import planner_plan_symbols, single_sender_enabled
    if single_sender_enabled():
        tracked |= planner_plan_symbols(cur)
    syms = sorted(tracked)
    cur.execute("""SELECT DISTINCT ON (upper(symbol)) upper(symbol), entry_zone_low, entry_zone_high, stop_price,
                          target_price, created_at
                     FROM watchlist_entry_plans
                    WHERE upper(symbol) = ANY(%s) AND created_at > now() - interval '7 days'
                    ORDER BY upper(symbol), created_at DESC""", (syms,))
    plans = {row[0]: row[1:] for row in cur.fetchall()}
    # Prices come from the Command Center data broker (market_quotes, refreshed by the broker's
    # own writer) — operator 2026-10-05: no alert reads its own price source. watchlist_items.price
    # is an enrichment copy that lagged a day (NVDA 26 h) while the broker had it at 16:00.
    from lib.alert_quotes import broker_quotes
    quotes = {s: (q["price"], q["age_h"], q.get("chg_pct")) for s, q in broker_quotes(cur, syms).items()}
    cur.execute("""SELECT DISTINCT ON (upper(symbol)) upper(symbol), ideal_entry, add_zone_low, add_zone_high,
                          stop_loss, target_price, catalyst_summary,
                          EXTRACT(EPOCH FROM (now() - updated_at)) / 3600.0
                     FROM watchlist_strategy_cards WHERE upper(symbol) = ANY(%s)
                    ORDER BY upper(symbol), updated_at DESC NULLS LAST""", (syms,))
    cards = {row[0]: row[1:] for row in cur.fetchall()}
    # Latest independent CIO decision and identity: shared with watchlist_entry_planner (lib.entry_alert_context).
    from lib.entry_alert_context import cio_review_fields, latest_cio_decisions, symbol_profiles
    cio_rows = latest_cio_decisions(cur, syms)
    cio = {sym: row["action"] for sym, row in cio_rows.items()}
    # Identity. The alert used to name a bare ticker and a market-cap pill, so the
    # operator was asked to act on "ESE" with no idea it is Esco Technologies, a
    # Technology / Scientific & Technical Instruments name. symbol_profiles already
    # carries all three and was simply never read here.
    profiles = symbol_profiles(cur, syms)
    cur.execute("""SELECT upper(symbol), packet FROM decision_packets
                    WHERE superseded_by IS NULL AND upper(symbol) = ANY(%s)""", (syms,))
    packets = {row[0]: row[1] or {} for row in cur.fetchall()}
    enrichment = _load_json(STATE_DIR / "ticker_enrichment_cache.json", {})
    holdings = _load_json(STATE_DIR / "holdings.json", {})
    held = {str(h.get("symbol") or "").upper() for h in holdings.get("holdings") or [] if not h.get("is_cash")}
    try:
        import watch_packet_quality as pq
    except Exception:
        pq = None
    from lib.finviz_csv import enrichment_market_cap_billions

    for sym in syms:
        e = ev.setdefault(sym, {"symbol": sym, "plan_source": None})
        if e.get("plan_source") is None:
            if sym in plans and (plans[sym][0] is not None or plans[sym][1] is not None):
                lo, hi, st, tg, created = plans[sym]
                e.update(entry_low=lo, entry_high=hi, stop=st, target=tg, plan_source="entry_plan",
                         plan_age_h=_age_h(created), plan_after_move=_after_open(created))
            elif sym in cards and cards[sym][0] is not None:
                ideal, zl, zh, st, tg, _, card_age_h = cards[sym]
                # A strategy card is rewritten by its own job; it is never a re-plan after a move.
                e.update(entry_low=zl or ideal, entry_high=zh or ideal, stop=st, target=tg, plan_source="strategy_card",
                         plan_age_h=card_age_h, plan_after_move=False)
        if sym in quotes:
            px, age_h, chg = quotes[sym]
            if e.get("price") is None:
                e["price"], e["quote_age_h"] = px, age_h
            e["change_pct"] = chg
        if not e.get("catalyst") and sym in cards:
            e["catalyst"] = cards[sym][5]
        e["cio_action"] = cio.get(sym)
        # The card's "Review:" line: the latest CIO decision, named (an entry_review row is a review; any
        # other decision is the CIO's stance on record). The runner's own fresh review overrides it.
        for k, v in cio_review_fields(cio_rows.get(sym)).items():
            e.setdefault(k, v)
        e["held"] = bool(e.get("held")) or sym in held
        if sym in profiles:
            # Conditional on purpose: symbol_profiles covers ~3,136 symbols, fewer than
            # the tracked set, and a blank identity line under a BUY READY call is worse
            # than no line at all.
            desc, sector, industry = profiles[sym]
            e["company"], e["sector"], e["industry"] = desc, sector, industry
        pk = packets.get(sym)
        if pk is not None and pq is not None:
            e["quality_state"] = pq.packet_gate(pk).get("quality")
            e.setdefault("earnings_date", ((pk.get("event_state") or {}).get("earnings") or {}).get("date"))
        e["market_cap_label"] = cap_label(
            None if (b := enrichment_market_cap_billions(enrichment.get(sym) or {})) is None else b * 1000.0)
        # P8 thesis/structure inputs from house enrichment (never invent).
        enr = enrichment.get(sym) or {}
        if isinstance(enr, dict):
            if e.get("pe") is None and enr.get("pe") is not None:
                e["pe"] = enr.get("pe")
            if e.get("forward_pe") is None and enr.get("forward_pe") is not None:
                e["forward_pe"] = enr.get("forward_pe")
            if e.get("peg") is None and enr.get("peg") is not None:
                e["peg"] = enr.get("peg")
            if e.get("atr") is None and enr.get("atr") is not None:
                e["atr"] = enr.get("atr")
            if not e.get("sector") and enr.get("sector"):
                e["sector"] = enr.get("sector")
            if not e.get("industry") and enr.get("industry"):
                e["industry"] = enr.get("industry")
    return ev


def last_states(cur) -> dict[str, str]:
    cur.execute("""SELECT DISTINCT ON (symbol) symbol, state FROM cio_entry_states ORDER BY symbol, evaluated_at DESC""")
    return {row[0]: row[1] for row in cur.fetchall()}


def alerted_today(cur, keys: list[str]) -> set[str]:
    cur.execute("""SELECT details->>'transition_key' FROM cio_entry_states
                    WHERE alerted AND evaluated_at::date = CURRENT_DATE AND details->>'transition_key' = ANY(%s)""", (keys,))
    return {row[0] for row in cur.fetchall()}


def operator_send(text: str | dict, *, primary_symbols: list[str] | None = None) -> dict:
    """The one operator send path (alert and digest). Routes IMMEDIATE as cio_entry_state.

    ``primary_symbols`` scopes Communications Editor footer chrome to the active
    symbol(s) so residual tickers (e.g. MAA GUID bleed on an AXTI alert) never
    appear in Finviz/Yahoo/CC links.
    """
    token = None
    reset_primary_symbols = None
    try:
        if primary_symbols:
            try:
                from scripts.lib.comms_editor import set_primary_symbols, reset_primary_symbols as _reset
            except ImportError:
                from lib.comms_editor import set_primary_symbols, reset_primary_symbols as _reset  # type: ignore
            reset_primary_symbols = _reset
            token = set_primary_symbols(primary_symbols)
        from telegram_alert import send_telegram
        payload = text if isinstance(text, dict) else {"text": text}
        kwargs = {k: payload[k] for k in ("reply_markup", "link_preview_options") if payload.get(k)}
        return {"operator": bool(send_telegram(payload.get("text", ""), message_class="operator_alert", **kwargs))}
    except Exception as exc:
        return {"operator": False, "operator_error": f"{type(exc).__name__}: {str(exc)[:120]}"}
    finally:
        if token is not None and reset_primary_symbols is not None:
            try:
                reset_primary_symbols(token)
            except Exception:
                pass


def starred_symbols(cur) -> set[str]:
    """Symbols the operator starred on the watchlist. Same idiom as
    watch_decision_scheduler.py:67 rather than a ninth bespoke variant.

    Fails CLOSED to the empty set: if the store cannot be read we page on
    BUY_READY only, which is quieter, never noisier.
    """
    try:
        cur.execute("SELECT upper(symbol) FROM operator_starred_symbols")
        return {row[0] for row in cur.fetchall() if row and row[0]}
    except Exception:
        return set()


def alert_worthy(actionable: list[dict], prior: dict, done: set,
                 starred: set[str] | None = None) -> list[dict]:
    """Page only on a move TOWARD a buy, once per symbol, state and day.

    On 2026-09-15 at 12:40, RTX and BZFD fell from BUY_READY back to ENTRY_NEAR, a price step out of
    the zone, and the operator got a second "getting close" for names already paged BUY READY at
    12:30. A downgrade is not news, and ENTRY_NEAR after a same-day BUY_READY alert is not either.

    Operator decision 2026-09-21: "Only alert when time to purchase unless starred on watchlist."
    ENTRY_NEAR is not a time to purchase -- it is a heads-up -- so it pages ONLY for a starred
    symbol. On 2026-09-21 at 15:10 the operator was paged "getting close" for GNL (+1.1%) and LOMA
    (+2.9%), neither starred and neither actionable. BUY_READY is unaffected and always pages.
    The suppression is of PAGING only: the cio_decisions row is still written for every state
    change, so the CIO keeps tracking names it no longer wakes the operator for.
    """
    starred = starred or set()
    out = []
    for r in actionable:
        if ces.transition_key(r) in done:
            continue
        if r["state"] == "ENTRY_NEAR" and (prior.get(r["symbol"]) == "BUY_READY"
                                           or ces.transition_key({**r, "state": "BUY_READY"}) in done):
            continue
        if r["state"] == "ENTRY_NEAR" and str(r.get("symbol") or "").upper() not in starred:
            continue
        out.append(r)
    return out


def stamp_cio_stance(text: str, symbols: list[str], only_conflicts: bool = False) -> str:
    """CIO stance footer, never a hold (M5 audit 2026-09-23, Module 4d).

    This page IS a CIO decision: the runner writes its own ``cio-entry-*`` row to
    cio_decisions just before paging, so gating it on the latest cio_decisions
    row would read that row back and always allow -- circular. Instead the
    footer shows the CIO's independent stance (the daily decision, excluding
    ``cio-entry-*`` rows) and flags an AVOID/SELL conflict.
    """
    try:
        from lib.publisher_stance_gate import stamp_symbols
    except ImportError:
        from scripts.lib.publisher_stance_gate import stamp_symbols  # type: ignore
    try:
        return stamp_symbols(text, symbols, exclude_decision_prefix="cio-entry-",
                             note="entry page is CIO-authored, not gated", only_conflicts=only_conflicts)
    except Exception:  # noqa: BLE001 -- a footer must never cost the page
        return text


def _review_wait_minutes() -> float:
    import os
    try:
        return float(os.environ.get("CIO_ENTRY_REVIEW_WAIT_MIN") or 30)
    except ValueError:
        return 30.0


def prepare_packet_inputs(result: dict, ev: dict, *, apply: bool) -> dict:
    """M5 09-24: attach chain-ranked options alternatives, portfolio facts and the CIO
    review to ``ev`` before rendering. Read-only broker chain; never sizes; a dry run
    (no --apply) never calls the model. Returns the review result."""
    from lib.buy_ready_options_alternatives import live_alternatives
    from lib.buy_ready_portfolio_facts import build_portfolio_facts
    from lib.buy_ready_cio_review import review_packet
    from lib.cio_options_fluency import build_buy_ready_packet
    sym = str(result.get("symbol") or "").upper()
    try:
        ev["portfolio_facts"] = build_portfolio_facts(sym)
    except Exception as exc:  # noqa: BLE001
        ev["portfolio_facts"] = {"status": "UNAVAILABLE", "error": type(exc).__name__, "flags": []}
    plan = {k: result.get(k) for k in ("symbol", "price", "entry_low", "entry_high", "stop", "target")}
    try:
        ev["options_alternatives"] = live_alternatives(plan, held=bool(result.get("held")),
                                                       proxy_iv_rank=(ev or {}).get("iv_rank"))
    except Exception as exc:  # noqa: BLE001
        ev["options_alternatives"] = {"status": "NO_CHAIN", "alternatives": [], "notes": [type(exc).__name__]}
    packet = build_buy_ready_packet(result, {**ev, "held": result.get("held"), "plan_source": result.get("plan_source")})
    review = review_packet(packet, review_mode=None if apply else "dry")
    ev["cio_review"] = review
    return review


def save_packet(result: dict, ev: dict) -> None:
    """Latest packet per symbol for the Command Center (read-only consumer: api_v2)."""
    try:
        from lib.cio_options_fluency import build_buy_ready_packet
        packet = build_buy_ready_packet(result, {**ev, "held": result.get("held"), "plan_source": result.get("plan_source")})
        packet["saved_at"] = datetime.now(timezone.utc).isoformat()
        PACKET_DIR.mkdir(parents=True, exist_ok=True)
        (PACKET_DIR / f"{str(result.get('symbol')).upper()}.json").write_text(json.dumps(packet, default=str, indent=1))
    except Exception:  # noqa: BLE001 — the page must never fail on the cache
        pass


def record_review(cur, review: dict, result: dict) -> None:
    """Store an OK review as a cio_decisions row (action_class='entry_review'); queue a
    pending/failed live review for follow-up within CIO_ENTRY_REVIEW_WAIT_MIN."""
    from lib.buy_ready_cio_review import INSERT_SQL, decision_row
    row = decision_row(review)
    if row:
        cur.execute(INSERT_SQL, row)
        return
    if review.get("mode") == "live" and review.get("status") in ("PENDING", "LLM_ERROR", "INVALID"):
        REVIEW_PENDING.parent.mkdir(parents=True, exist_ok=True)
        with REVIEW_PENDING.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps({"symbol": result.get("symbol"), "state": result.get("state"),
                                 "queued_at": datetime.now(timezone.utc).isoformat(),
                                 "result": result, "status": review.get("status")}, default=str) + "\n")


def follow_up_pending_reviews(cur, evidence: dict) -> list[dict]:
    """Retry queued live reviews inside the wait window; page a follow-up when one lands."""
    if not REVIEW_PENDING.exists():
        return []
    try:
        rows = [json.loads(x) for x in REVIEW_PENDING.read_text(encoding="utf-8").splitlines() if x.strip()]
    except (OSError, ValueError):
        return []
    now = datetime.now(timezone.utc)
    keep, out = [], []
    latest: dict[str, dict] = {}
    for r in rows:
        latest[str(r.get("symbol")).upper()] = r
    for sym, r in latest.items():
        try:
            age_min = (now - datetime.fromisoformat(str(r["queued_at"]))).total_seconds() / 60.0
        except (KeyError, ValueError):
            continue
        if age_min > _review_wait_minutes():
            out.append({"symbol": sym, "follow_up": "expired"})
            continue
        ev = dict(evidence.get(sym) or {})
        review = prepare_packet_inputs(r["result"], ev, apply=True)
        if review.get("status") == "OK":
            from lib.buy_ready_cio_review import INSERT_SQL, decision_row
            row = decision_row(review)
            if row:
                cur.execute(INSERT_SQL, row)
            payload = cio_card_payload(r["result"], ev, review=review)
            out.append({"symbol": sym, "follow_up": "sent", **operator_send(payload, primary_symbols=[sym])})
            save_packet(r["result"], ev)
        else:
            keep.append(r)
            out.append({"symbol": sym, "follow_up": review.get("status")})
    REVIEW_PENDING.write_text("".join(json.dumps(x, default=str) + "\n" for x in keep), encoding="utf-8")
    return out


class _HeldForDigest(Exception):
    """Control flow: the CIO-bot copy is held for the advice digest (not an error)."""


def send_alerts(result: dict, evidence: dict) -> dict:
    out = {"cio_desk": False, "cio_bus": False}
    sym = str(result.get("symbol") or "").upper()
    operator_payload = cio_card_payload(result, evidence)
    operator_payload["text"] = stamp_cio_stance(operator_payload["text"], [result["symbol"]])
    out.update(operator_send(operator_payload, primary_symbols=[sym] if sym else None))
    try:
        # 2026-10-08 operator: all entry alerts go to the advice digests. The operator_send copy above is routed
        # (policy_v2 → DIGEST, recorded in Communications); this direct CIO-bot copy would page, so it is held.
        # Rollback: config/advice_digest.yaml holds.cio_entry_bot_copy.
        try:
            from scripts.lib.advice_digest import hold as _advice_hold
        except ImportError:  # pragma: no cover
            from lib.advice_digest import hold as _advice_hold  # type: ignore
        if _advice_hold("cio_entry_bot_copy"):
            out["cio_desk"] = False
            out["cio_desk_reason"] = "held_for_advice_digest"
            raise _HeldForDigest()
        from scripts.lib.cio_telegram_transport import send_cio_message
        r = send_cio_message(operator_payload["text"], subject="", kind="cio_advisory",
                             dedupe_key=ces.transition_key(result), reply_markup=operator_payload.get("reply_markup"),
                             parse_mode="HTML", link_preview_options=operator_payload.get("link_preview_options"))
        # send_cio_message returns {"delivered": bool, "reason": str, "deduped": bool, ...}. Reading
        # "sent"/"ok" recorded every desk message as failed on the first live run (2026-09-15 12:30).
        r = r or {}
        out["cio_desk"] = bool(r.get("delivered"))
        # Keep the Telegram ids with the transition key: a later correction must be able to
        # reply to the exact message (the 2026-09-28 10:20 AXTI alert had none on record).
        out["cio_desk_dedupe_key"] = r.get("dedupe_key")
        if r.get("message_refs"):
            out["cio_desk_message_refs"] = r.get("message_refs")
        if not out["cio_desk"]:
            out["cio_desk_reason"] = "deduped" if r.get("deduped") else (r.get("reason") or "not delivered")
    except _HeldForDigest:
        pass
    except Exception as exc:
        out["cio_desk_error"] = f"{type(exc).__name__}: {str(exc)[:120]}"
    try:
        from scripts.lib.cio_event_bus import CIOEventBus
        # `symbols` (plural) is what cio_reactive_cycle binds the wake subject from;
        # sending only `symbol` left the V BUY_READY review subject-less (M5 09-24).
        CIOEventBus().emit("watch.new_signal", {"symbol": result["symbol"], "symbols": [result["symbol"]],
                                                "signal": "cio_entry_state",
                                                "state": result["state"], "entry_low": result["entry_low"],
                                                "entry_high": result["entry_high"], "price": result["price"],
                                                "rr": result["rr"], "market_cap_label": result["market_cap_label"]},
                           source="cio_entry_state_runner", semantic_event_key=ces.transition_key(result))
        out["cio_bus"] = True
    except Exception as exc:
        out["cio_bus_error"] = f"{type(exc).__name__}: {str(exc)[:120]}"
    return out


def _card_option_reasons(alternatives: dict | None, alt: dict | None) -> list[str]:
    """Expose actual option gate facts; never invent a rejection reason."""
    out: list[str] = []
    source = alternatives if isinstance(alternatives, dict) else {}
    out.extend(str(x) for x in (source.get("notes") or []) if x)
    out.extend(str(x) for x in (alt or {}).get("notes", []) if x)
    if (alt or {}).get("detail"):
        out.append(str(alt["detail"]))
    for row in source.get("alternatives") or []:
        out.extend(str(x) for x in (row.get("disqualified_by") or []) if x)
    return list(dict.fromkeys(out))[:5]


def cio_card_payload(result: dict, evidence: dict, *, review: dict | None = None) -> dict:
    """Build the shared Telegram CIO card from the canonical entry packet facts."""
    from lib.telegram_rich import cio_entry_alert
    item = {**(evidence or {}), **(result or {})}
    try:
        from lib.cio_options_fluency import build_buy_ready_packet
        packet = build_buy_ready_packet(result, {**evidence, "held": result.get("held"),
                                                  "plan_source": result.get("plan_source")})
        eq = packet.get("equity") or {}
        item.update({"price": eq.get("price", item.get("price")),
                     "entry_low": eq.get("entry_low", item.get("entry_low")),
                     "entry_high": eq.get("entry_high", item.get("entry_high")),
                     "stop": eq.get("stop", item.get("stop")),
                     "target": eq.get("target", item.get("target")),
                     "rr_at_ideal_entry": eq.get("reward_risk_worst_in_zone", result.get("rr")),
                     "rr_at_current_price": eq.get("reward_risk_at_quote", result.get("rr_at_current_price")),
                     "distance_pct": eq.get("distance_pct", result.get("distance_pct")),
                     "time_horizon": eq.get("time_horizon") or packet.get("time_horizon") or result.get("time_horizon"),
                     "first_hard_block": packet.get("first_hard_block") or item.get("first_hard_block"),
                     "catalyst": (packet.get("thesis_indicators") or {}).get("catalyst") or result.get("catalyst"),
                     "options_status": (packet.get("options_alternatives") or {}).get("status") or "not evaluated",
                     "options_reasons": _card_option_reasons(packet.get("options_alternatives"), packet.get("options_alt")),
                     "thesis": (packet.get("thesis_indicators") or {}).get("drivers", []),
                     "capital_impact": (eq.get("capital") and f"{eq.get('capital')} per share") or "unavailable"})
        alts = (packet.get("options_alternatives") or {}).get("alternatives") or []
        if alts:
            item["options_summary"] = str(alts[0].get("strategy") or "option alternative")
    except Exception as exc:  # noqa: BLE001 -- card must degrade to canonical entry facts
        item.setdefault("options_status", f"unavailable ({type(exc).__name__})")
    fresh = review or evidence.get("cio_review")
    if isinstance(fresh, dict):
        item["cio_review_status"] = fresh.get("status")
        item["cio_review_id"] = fresh.get("decision_id")
    else:
        # No review this run: the latest CIO decision on record (gather), never a blank "unreviewed".
        item["cio_review_status"] = (evidence or {}).get("cio_review_status")
        item["cio_review_id"] = (evidence or {}).get("cio_review_id")
    item["next_action"] = "CIO review follow-up received" if review else item.get("next_action")
    return cio_entry_alert(item).render()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true", help="record states, write CIO decisions and send alerts")
    ap.add_argument("--max-alerts", type=int, default=MAX_ALERTS_PER_RUN)
    a = ap.parse_args()
    conn = _conn()
    cur = conn.cursor()
    if a.apply:
        cur.execute(DDL)
        conn.commit()
    evidence = gather(cur)
    results = {sym: ces.evaluate(e) for sym, e in evidence.items()}
    try:
        prior = last_states(cur)
    except Exception:
        conn.rollback()
        prior = {}
    counts: dict[str, int] = {}
    for r in results.values():
        counts[r["state"]] = counts.get(r["state"], 0) + 1
    actionable = sorted((r for r in results.values() if r["state"] in ces.ACTIONABLE),
                        key=lambda r: (0 if r["state"] == "BUY_READY" else 1, abs(r["distance_pct"] or 0)))
    keys = [ces.transition_key(r) for r in actionable]
    buy_keys = [ces.transition_key({**r, "state": "BUY_READY"}) for r in actionable if r["state"] == "ENTRY_NEAR"]
    done = alerted_today(cur, keys + buy_keys) if (a.apply and keys) else set()
    starred = starred_symbols(cur)
    pending = alert_worthy(actionable, prior, done, starred)
    to_alert = pending[: max(0, a.max_alerts)]
    digest = pending[max(0, a.max_alerts):]
    sent = []
    reviews: dict[str, dict] = {}
    # M5 09-24: options alternatives + portfolio facts + CIO review before any render
    # (render_cio is also the cio_decisions rationale written below).
    for r in (to_alert if a.apply else to_alert[:1]):
        reviews[r["symbol"]] = prepare_packet_inputs(r, evidence[r["symbol"]], apply=a.apply)
    if a.apply:
        for sym, r in results.items():
            if prior.get(sym) != r["state"]:
                alert = r in to_alert
                cur.execute("""INSERT INTO cio_entry_states (symbol, state, prior_state, alerted, details)
                               VALUES (%s,%s,%s,%s,%s::jsonb)""",
                            (sym, r["state"], prior.get(sym), alert,
                             json.dumps({**r, "transition_key": ces.transition_key(r)}, default=str)))
        for r in to_alert:
            if prior.get(r["symbol"]) == r["state"]:
                cur.execute("""INSERT INTO cio_entry_states (symbol, state, prior_state, alerted, details)
                               VALUES (%s,%s,%s,true,%s::jsonb)""",
                            (r["symbol"], r["state"], r["state"],
                             json.dumps({**r, "transition_key": ces.transition_key(r)}, default=str)))
            did = f"cio-entry-{r['symbol'].lower()}-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"
            cur.execute("""INSERT INTO cio_decisions (decision_id, symbol, strategy_type, action, action_class, priority,
                                                      confidence_raw, decision_safety, human_review_required, rationale,
                                                      status, agent_votes)
                           VALUES (%s,%s,%s,%s,'entry',%s,%s,'safe',true,%s,'proposed','{}')""",
                        (did, r["symbol"], r.get("plan_source"), r["state"], "high" if r["state"] == "BUY_READY" else "medium",
                         None, ces.render_cio(r, evidence[r["symbol"]])[:500]))
        conn.commit()
        for r in digest:
            # recorded as alerted so the digest names do not come back one by one later today
            cur.execute("""INSERT INTO cio_entry_states (symbol, state, prior_state, alerted, details)
                           VALUES (%s,%s,%s,true,%s::jsonb)""",
                        (r["symbol"], r["state"], r["state"],
                         json.dumps({**r, "transition_key": ces.transition_key(r), "via": "digest"}, default=str)))
        conn.commit()
        for r in to_alert:
            if r["symbol"] in reviews:
                record_review(cur, reviews[r["symbol"]], r)
        conn.commit()
        for r in to_alert:
            sent.append({"symbol": r["symbol"], "state": r["state"], **send_alerts(r, evidence[r["symbol"]])})
            save_packet(r, evidence[r["symbol"]])
        follow_ups = follow_up_pending_reviews(cur, evidence)
        conn.commit()
        if follow_ups:
            sent.append({"review_follow_ups": follow_ups})
        if digest:
            digest_syms = [str(r["symbol"]).upper() for r in digest if r.get("symbol")]
            sent.append({
                "digest": digest_syms,
                **operator_send(
                    stamp_cio_stance(
                        ces.render_digest(digest),
                        [r["symbol"] for r in digest],
                        only_conflicts=True,
                    ),
                    primary_symbols=digest_syms,
                ),
            })
        RECEIPT.parent.mkdir(parents=True, exist_ok=True)
        RECEIPT.write_text(json.dumps({"as_of": datetime.now(timezone.utc).isoformat(), "counts": counts,
                                       "alerts": sent}, indent=2, default=str))
    else:
        conn.rollback()
    report = {"mode": "apply" if a.apply else "dry_run", "tracked": len(results), "states": counts,
              "actionable": len(actionable), "would_alert": [f"{r['symbol']} {r['state']}" for r in to_alert],
              "would_digest": [f"{r['symbol']} {r['state']}" for r in digest],
              "sent": sent,
              "blocked_reasons": _top_reasons(results.values())}
    if reviews:
        report["reviews"] = {k: {"status": v.get("status"), "mode": v.get("mode")} for k, v in reviews.items()}
    if not a.apply and to_alert:
        report["sample_operator_message"] = stamp_cio_stance(
            ces.render_operator(to_alert[0], evidence[to_alert[0]["symbol"]]), [to_alert[0]["symbol"]])
    print(json.dumps(report, indent=2, default=str))
    return 0


def _top_reasons(results) -> dict:
    c: dict[str, int] = {}
    for r in results:
        for reason in r["reasons"]:
            import re as _re
            key = _re.sub(r"[0-9]+(\.[0-9]+)?", "N", reason)
            c[key] = c.get(key, 0) + 1
    return dict(sorted(c.items(), key=lambda kv: -kv[1])[:8])


if __name__ == "__main__":
    raise SystemExit(main())
