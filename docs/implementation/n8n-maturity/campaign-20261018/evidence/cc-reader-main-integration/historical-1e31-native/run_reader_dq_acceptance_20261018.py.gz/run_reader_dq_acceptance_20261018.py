"""One fixed, bounded host acceptance cohort. Do not invoke before review.

No arguments, dependency installs, remotes, grants, deployment or business effects.
The approved host invocation acquires its own generated-file leases; preparation
and permission waiting acquire none. Prior cohort wrappers and logs stay frozen.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import re
import runpy
import signal
import subprocess
import sys
import time
import uuid
from html.parser import HTMLParser
from pathlib import Path

PYTHON = "/home/johnclaw/trade-ai-v12-rebuild/trade-ai-v12-rebuild/.venv/bin/python"
NODE_DIR = Path("/home/johnclaw/.nvm/versions/node/v22.23.2/bin")
OUT = Path("/tmp/n8n-campaign-20261018/reader-dq-native-hostbuild-20261018")
PRIOR_WRAPPER = Path("/tmp/n8n-campaign-20261018/run_native_cohort_20261018.py")
PRIOR_DIGEST = "35e43202b04a77a1c62f0d154905471650359084cff12546b52dc0555c45d5a7"
CANDIDATES = (
    (
        "sop",
        "/home/johnclaw/tradeai-wt-n8n-sop-attestation-truth-20261018",
        "30edda37c26caeae1458b8d97c2b690d0b1f14ed",
        False,
    ),
    (
        "feedback",
        "/home/johnclaw/tradeai-wt-n8n-feedback-hold-preservation-20261018",
        "726ae9fca3bebd1283d9e8b378df7bb07371496b",
        False,
    ),
    (
        "rotation",
        "/home/johnclaw/tradeai-wt-n8n-rotation-publication-20261018",
        "de7564bb846bfd9988a2931eaa2324d6aec82d8e",
        False,
    ),
    (
        "reader",
        "/home/johnclaw/tradeai-wt-n8n-cc-reader-first-20261018",
        "1e31f83fcfde3b8603a634129239bb52a32c27a2",
        True,
    ),
    (
        "data-quality",
        "/home/johnclaw/tradeai-wt-n8n-data-quality-safe-20261018",
        "10bfe5ba5cc9bf76acee8163a54cdb2cb31acb68",
        False,
    ),
)
GENERATED = (
    "docs/INDEX.md",
    "docs/project/CI_EVIDENCE_LATEST.md",
    "docs/project/RELEASE_MANIFEST_LATEST.md",
    "docs/diligence/current/OPTIONS_RISK_BLOCK_MATRIX.md",
)
MAX_FILES = 5000
MAX_ARTIFACT_BYTES = 200 * 1024 * 1024


class Interrupted(Exception):
    pass


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def exclusive_json(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def remaining(deadline, maximum):
    value = min(float(maximum), deadline - time.monotonic())
    if value <= 0:
        raise TimeoutError("absolute candidate deadline exhausted")
    return value


def stop_group(process):
    if process is None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=3)
    except subprocess.TimeoutExpired:
        pass
    # A shell may exit while its descendants remain in the same process group.
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    process.wait(timeout=3)


def capture(argv, cwd, env, deadline, maximum=20):
    remaining(deadline, maximum)  # do not spawn even a helper after its deadline
    process = subprocess.Popen(
        argv,
        cwd=cwd,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        start_new_session=True,
    )
    try:
        stdout, stderr = process.communicate(timeout=remaining(deadline, maximum))
    except BaseException:
        stop_group(process)
        raise
    require(len(stdout) + len(stderr) <= 65536, "bounded helper output exceeded")
    if process.returncode:
        raise RuntimeError("helper failed: " + str(argv[:2]) + ": " + stderr[:1000])
    return stdout.strip()


def git(root, env, deadline, *args):
    return capture(["/usr/bin/git", *args], root, env, deadline)


def identity(root, expected, env, deadline):
    require(
        git(root, env, deadline, "rev-parse", "--show-toplevel") == str(root),
        "wrong physical repository",
    )
    head = git(root, env, deadline, "rev-parse", "HEAD")
    status = git(root, env, deadline, "status", "--porcelain")
    require(head == expected, "candidate HEAD changed or does not match frozen pin")
    require(status == "", "candidate tracked/untracked worktree is not clean")
    return {
        "head": head,
        "branch": git(root, env, deadline, "branch", "--show-current"),
        "clean": True,
    }


def durable_json(path, value):
    # A complete capsule must reach durable storage BEFORE canonical acquire.
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def validated_request(path):
    require(not path.is_symlink(), "symlinked invocation request refused")
    raw = path.read_bytes()
    require(len(raw) <= 16384, "session request exceeds bound")
    value = json.loads(raw)
    require(
        type(value) is dict
        and set(value)
        == {
            "schema",
            "invocation_id",
            "root",
            "head",
            "agent",
            "paths",
            "wrapper_sha256",
        }
        and value["schema"] == "CampaignLeaseInvocation@v1"
        and str(uuid.UUID(value["invocation_id"])) == value["invocation_id"]
        and value["agent"] == "codex"
        and (value["root"], value["head"]) in {(row[1], row[2]) for row in CANDIDATES}
        and re.fullmatch(r"[0-9a-f]{40}", value["head"]) is not None
        and type(value["paths"]) is list
        and value["paths"]
        == list(GENERATED)
        + (
            ["apps/command-center-v3/dist"]
            if "apps/command-center-v3/dist" in value["paths"]
            else []
        )
        and digest(Path(__file__).read_bytes()) == value["wrapper_sha256"],
        "invalid or changed fixed invocation request",
    )
    return value


def journal_acquire_intent(request, capsule_path, args, kwargs):
    # Observe canonical arguments without changing any arguments/IDs or decision.
    require(not args, "unexpected positional canonical acquire arguments")
    require(
        set(kwargs) == {"session_id", "agent_id", "paths", "stores"}
        and kwargs["agent_id"] == request["agent"]
        and kwargs["paths"] == request["paths"]
        and kwargs["stores"] == []
        and str(uuid.UUID(kwargs["session_id"])) == kwargs["session_id"],
        "canonical acquire does not match invocation",
    )
    durable_json(
        capsule_path,
        {
            "schema": "CampaignLeaseAcquireIntent@v1",
            "request": request,
            "session_id": kwargs["session_id"],
        },
    )


def governed_cli(request_path, capsule_path, argv):
    # Execute the actual CLI and session validator. The child-only observer adds
    # a durable pre-acquire identity journal; original acquire gets EXACT args.
    from scripts.lib import agent_session_receipt

    request = validated_request(Path(request_path))
    require(str(Path.cwd().resolve()) == request["root"], "journal worktree mismatch")
    original = agent_session_receipt.LeaseCoordinator

    class JournalCoordinator(original):
        def acquire(self, *args, **kwargs):
            journal_acquire_intent(request, Path(capsule_path), args, kwargs)
            return super().acquire(*args, **kwargs)

    agent_session_receipt.LeaseCoordinator = JournalCoordinator
    original_argv = sys.argv
    try:
        sys.argv = ["scripts/agent_session_start.py", *argv]
        runpy.run_path(sys.argv[0], run_name="__main__")
    finally:
        agent_session_receipt.LeaseCoordinator = original
        sys.argv = original_argv


def cleanup_owned_lease(request_path, capsule_path, coordinator=None):
    request = validated_request(Path(request_path))
    capsule_path = Path(capsule_path)
    if not capsule_path.exists():
        # The sole observed acquire cannot delegate before durable journal PASS.
        return {"outcome": "NO_ACQUIRE_INTENT", "cleanup_complete": True}
    require(not capsule_path.is_symlink(), "symlinked lease capsule refused")
    raw = capsule_path.read_bytes()
    require(len(raw) <= 32768, "lease capsule exceeds bound")
    capsule = json.loads(raw)
    require(
        type(capsule) is dict
        and set(capsule) == {"schema", "request", "session_id"}
        and capsule["schema"] == "CampaignLeaseAcquireIntent@v1"
        and capsule["request"] == request
        and str(uuid.UUID(capsule["session_id"])) == capsule["session_id"],
        "invalid exact invocation lease capsule",
    )
    if coordinator is None:
        from scripts.lib.agent_file_lease import LeaseCoordinator

        require(
            str(Path.cwd().resolve()) == request["root"], "cleanup worktree mismatch"
        )
        coordinator = LeaseCoordinator(repo_root=Path.cwd())
    owned = [
        x for x in coordinator.list_active() if x["session_id"] == capsule["session_id"]
    ]
    require(len(owned) <= 1, "ambiguous duplicate invocation lease refused")
    if not owned:
        return {
            "outcome": "EXACT_SESSION_ABSENT",
            "cleanup_complete": True,
            "session_id": capsule["session_id"],
        }
    lease = owned[0]
    require(
        lease["agent_id"] == request["agent"]
        and lease["paths"] == request["paths"]
        and lease["stores"] == []
        and lease["deployment"] is False
        and lease["production"] is False,
        "lease identity/claims mismatch; refusing release",
    )
    require(
        coordinator.release(lease["lease_id"], session_id=capsule["session_id"]),
        "exact lease release failed",
    )
    require(
        not any(
            x["session_id"] == capsule["session_id"] for x in coordinator.list_active()
        ),
        "invocation lease still active after release",
    )
    return {
        "outcome": "EXACT_LEASE_RELEASED",
        "cleanup_complete": True,
        "session_id": capsule["session_id"],
        "lease_id": lease["lease_id"],
    }


def cleanup_helper(root, request_path, capsule_path, env, deadline):
    code = "import runpy,sys,json; sys.path.insert(0,'.'); n=runpy.run_path(sys.argv[1]); print(json.dumps(n['cleanup_owned_lease'](sys.argv[2],sys.argv[3])))"
    return json.loads(
        capture(
            [
                PYTHON,
                "-c",
                code,
                str(Path(__file__).resolve()),
                str(request_path),
                str(capsule_path),
            ],
            root,
            env,
            deadline,
            maximum=20,
        )
    )


def lease_helper(root, session, env, deadline, action):
    code = (
        "from pathlib import Path; import sys; "
        "from scripts.lib.agent_file_lease import LeaseCoordinator; "
        "c=LeaseCoordinator(repo_root=Path.cwd()); "
        "owned=[x for x in c.list_active() if x['lease_id']==sys.argv[1] and x['session_id']==sys.argv[2]]; "
        "\nif not owned: raise RuntimeError('owned lease unavailable')\n"
    )
    if action == "heartbeat":
        code += "c.heartbeat(sys.argv[1])\n"
    else:
        code += "\nif not c.release(sys.argv[1],session_id=sys.argv[2]): raise RuntimeError('lease release failed')\n"
    capture(
        [PYTHON, "-c", code, session["lease"]["lease_id"], session["session_id"]],
        root,
        env,
        deadline,
        maximum=20,
    )


def run_step(name, argv, root, env, operation_deadline, maximum, session):
    started_at = now()
    started = time.monotonic()
    step_deadline = min(operation_deadline, started + maximum)
    log = OUT / (name + ".log")
    process = None
    result = {"stage": name, "argv": argv, "cwd": str(root), "started_at": started_at}
    try:
        with log.open("xb") as stream:
            remaining(step_deadline, maximum)
            process = subprocess.Popen(
                argv,
                cwd=root,
                env=env,
                stdout=stream,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            result["pid"] = process.pid
            exclusive_json(OUT / (name + "-started.json"), result)
            print(json.dumps({"event": "stage_started", **result}), flush=True)
            last_heartbeat = time.monotonic()
            while True:
                try:
                    code = process.wait(timeout=remaining(step_deadline, 15))
                    break
                except subprocess.TimeoutExpired:
                    remaining(step_deadline, 15)
                    if time.monotonic() - last_heartbeat >= 20:
                        lease_helper(
                            Path(session["worktree_path"]),
                            session,
                            env,
                            min(operation_deadline, step_deadline),
                            "heartbeat",
                        )
                        last_heartbeat = time.monotonic()
        result["exit_code"] = code
        result["passed"] = code == 0
    except BaseException as error:
        stop_group(process)
        result["passed"] = False
        result["error"] = type(error).__name__ + ": " + str(error)
        raise
    finally:
        result["finished_at"] = now()
        result["elapsed_seconds"] = time.monotonic() - started
        if log.exists():
            result["log"] = {
                "path": str(log),
                "sha256": digest(log.read_bytes()),
                "bytes": log.stat().st_size,
            }
        exclusive_json(OUT / (name + "-result.json"), result)
    return result


def reader_dependencies(app, env, deadline):
    # Existing shared dependencies are read only. In particular, never npm ci a
    # node_modules symlink. The executable preflight also prevents the canonical
    # native script's missing-tsc install fallback from being selected.
    for name in ("tsc", "esbuild"):
        require(
            os.access(app / "node_modules" / ".bin" / name, os.X_OK),
            "required existing dependency unavailable: " + name,
        )
    node = capture([str(NODE_DIR / "node"), "--version"], app, env, deadline)
    require(re.fullmatch(r"v22\.[0-9]+\.[0-9]+", node) is not None, "Node22 required")
    lock = json.loads((app / "package-lock.json").read_text())
    versions = {}
    for name in ("react", "react-dom", "esbuild", "typescript", "vite"):
        actual = json.loads((app / "node_modules" / name / "package.json").read_text())[
            "version"
        ]
        require(
            actual == lock["packages"]["node_modules/" + name]["version"],
            "dependency differs from lock: " + name,
        )
        versions[name] = actual
    return {
        "node": node,
        "npm": capture([str(NODE_DIR / "npm"), "--version"], app, env, deadline),
        "packages": versions,
        "shared_node_modules_symlink": (app / "node_modules").is_symlink(),
        "package_sha256": digest((app / "package.json").read_bytes()),
        "lock_sha256": digest((app / "package-lock.json").read_bytes()),
    }


def artifact_inventory(directory):
    require(
        not directory.is_symlink() and directory.resolve() == directory,
        "symlinked/external dist refused",
    )
    require(directory.is_dir(), "dist directory unavailable")
    files = {}
    total = 0
    for path in sorted(directory.rglob("*")):
        require(not path.is_symlink(), "symlink in artifact refused")
        if not path.is_file():
            continue
        size = path.stat().st_size
        require(size <= 64 * 1024 * 1024, "artifact file exceeds bound")
        total += size
        require(
            len(files) < MAX_FILES and total <= MAX_ARTIFACT_BYTES,
            "artifact inventory exceeds bound",
        )
        files[str(path.relative_to(directory))] = {
            "sha256": digest(path.read_bytes()),
            "bytes": size,
        }
    return {"files": files, "total_bytes": total}


def closed_metadata(raw):
    require(len(raw) <= 16384, "build metadata exceeds bound")

    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate build metadata field")
            result[key] = value
        return result

    def bad_constant(value):
        raise RuntimeError("nonfinite build metadata value: " + value)

    value = json.loads(raw, object_pairs_hook=pairs, parse_constant=bad_constant)
    allowed = {
        "ui_version",
        "base_version",
        "built_at",
        "release_notes",
        "git_sha",
        "build_sha",
        "source_sha",
        "source_commit",
        "branch",
    }
    require(
        type(value) is dict and set(value) == allowed,
        "unexpected or missing fixed-producer build metadata fields",
    )
    return value


class EntryScripts(HTMLParser):
    def __init__(self):
        super().__init__()
        self.sources = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "script" and attrs.get("src"):
            self.sources.append(attrs["src"])


def verify_build(app, head, branch, stage, deadline):
    remaining(deadline, 60)
    directory = app / "dist"
    inventory = artifact_inventory(directory)
    meta = closed_metadata((directory / "build-meta.json").read_bytes())
    require(
        all(meta[key] == head for key in ("git_sha", "source_sha", "source_commit")),
        "known compiled Git identity unavailable or mismatched",
    )
    require(
        meta["build_sha"] == head[:12] and meta["branch"] == branch,
        "build identity aliases/branch mismatch",
    )
    require(meta["base_version"] == "3.14", "unexpected fixed-producer base UI version")
    require(
        type(meta["ui_version"]) is str
        and meta["ui_version"].startswith("3.14+")
        and len(meta["ui_version"]) > 5,
        "build stamp unavailable",
    )
    built = dt.datetime.fromisoformat(meta["built_at"].replace("Z", "+00:00"))
    require(
        built.tzinfo is not None
        and dt.datetime.fromisoformat(stage["started_at"])
        <= built
        <= dt.datetime.fromisoformat(stage["finished_at"]),
        "build metadata is not fresh inside actual build window",
    )
    parser = EntryScripts()
    parser.feed((directory / "index.html").read_text())
    markers = []
    for source in parser.sources:
        require(
            source.startswith("/v3/") and ".." not in Path(source).parts,
            "unexpected entry script destination",
        )
        relative = source[len("/v3/") :]
        require(
            relative in inventory["files"] and relative.endswith(".js"),
            "entry script missing from artifact",
        )
        raw = (directory / relative).read_bytes()
        if head.encode() in raw and meta["ui_version"].encode() in raw:
            markers.append(relative)
    require(
        markers,
        "exact compiled source SHA and UI stamp not found in actual emitted entry script",
    )
    remaining(deadline, 60)
    return {
        "known_identity": True,
        "metadata": meta,
        "inventory": inventory,
        "compiled_marker_assets": markers,
        "proof_limit": "Static emitted artifact identity only; not deployed/authenticated/refreshed browser or business-output proof.",
    }


def run_candidate(name, location, head, build, env):
    root = Path(location).resolve()
    started = time.monotonic()
    hard_deadline = started + (2520 if build else 1920)
    operation_deadline = hard_deadline - 60  # preserve bounded lease-cleanup time
    record = {
        "candidate": name,
        "worktree": str(root),
        "expected_head": head,
        "started_at": now(),
        "qualifying_acceptance": False,
        "stages": [],
    }
    session = None
    request_path = None
    capsule_path = OUT / (name + "-acquire-intent.json")
    try:
        before = identity(root, head, env, operation_deadline)
        record["identity_before"] = before
        app = root / "apps/command-center-v3"
        if build:
            record["dependencies_before"] = reader_dependencies(
                app, env, operation_deadline
            )
        command = [
            "--agent",
            "codex",
            "--mode",
            "mutating",
            "--expected-worktree",
            str(root),
            "--expected-head",
            head,
            "--doc-read",
            "AGENTS.md",
            "--doc-read",
            "AI_WORK_POLICY.md",
            "--task-scope",
            "Fixed reader/DQ canonical acceptance; generated test/build artifacts only; no runtime actions",
            "--json",
        ]
        paths = list(GENERATED) + (["apps/command-center-v3/dist"] if build else [])
        for path in paths:
            command += ["--claim", path]
        request_path = OUT / (name + "-lease-invocation.json")
        durable_json(
            request_path,
            {
                "schema": "CampaignLeaseInvocation@v1",
                "invocation_id": str(uuid.uuid4()),
                "root": str(root),
                "head": head,
                "agent": "codex",
                "paths": paths,
                "wrapper_sha256": digest(Path(__file__).read_bytes()),
            },
        )
        code = "import runpy,sys; sys.path.insert(0,'.'); n=runpy.run_path(sys.argv[1]); n['governed_cli'](sys.argv[2],sys.argv[3],sys.argv[4:])"
        raw_session = capture(
            [
                PYTHON,
                "-c",
                code,
                str(Path(__file__).resolve()),
                str(request_path),
                str(capsule_path),
                *command,
            ],
            root,
            env,
            operation_deadline,
            maximum=60,
        )
        session = json.loads(raw_session)
        exclusive_json(OUT / (name + "-session.json"), session)
        require(
            session["ok"] is True
            and session["expected_head"] == head
            and session["identity"]["ok"] is True
            and session["worktree_path"] == str(root),
            "governed session refused",
        )
        record["session_id"] = session["session_id"]
        record["lease_id"] = session["lease"]["lease_id"]
        native = run_step(
            name + "-native",
            ["/bin/bash", "scripts/ai_local_acceptance.sh"],
            root,
            env,
            operation_deadline,
            1800,
            session,
        )
        record["stages"].append(native)
        require(native["passed"], "canonical native acceptance failed")
        record["identity_after_native"] = identity(root, head, env, operation_deadline)
        if build:
            require(
                reader_dependencies(app, env, operation_deadline)
                == record["dependencies_before"],
                "dependency inputs changed",
            )
            directory = app / "dist"
            if directory.exists() or directory.is_symlink():
                exclusive_json(
                    OUT / "reader-dist-before.json", artifact_inventory(directory)
                )
                meta = directory / "build-meta.json"
                if meta.is_file():
                    with (OUT / "reader-build-meta-before.json").open("xb") as stream:
                        stream.write(meta.read_bytes())
            host_build = run_step(
                name + "-host-build",
                [str(NODE_DIR / "npm"), "run", "build"],
                app,
                env,
                operation_deadline,
                600,
                session,
            )
            record["stages"].append(host_build)
            require(host_build["passed"], "complete npm run build failed")
            record["build_evidence"] = verify_build(
                app, head, before["branch"], host_build, operation_deadline
            )
            exclusive_json(OUT / "reader-build-evidence.json", record["build_evidence"])
            require(
                reader_dependencies(app, env, operation_deadline)
                == record["dependencies_before"],
                "package/dependency inputs changed after build",
            )
        record["identity_after"] = identity(root, head, env, operation_deadline)
        record["qualifying_acceptance"] = True
    except Interrupted as error:
        record["interrupted"] = True
        record["error"] = str(error)
    except Exception as error:  # noqa: BLE001 - record any failed stage/cleanup; never qualify it.
        record["error"] = type(error).__name__ + ": " + str(error)
    finally:
        # Child process groups are already stopped by run_step on every error.
        # Ignore another interrupt only during this bounded ownership cleanup.
        old_handlers = {
            sig: signal.signal(sig, signal.SIG_IGN)
            for sig in (signal.SIGINT, signal.SIGTERM)
        }
        try:
            if request_path is not None:
                try:
                    cleanup = cleanup_helper(
                        root, request_path, capsule_path, env, hard_deadline
                    )
                    require(
                        cleanup["cleanup_complete"] is True, "lease cleanup incomplete"
                    )
                    record["lease_cleanup"] = cleanup
                    record["lease_released"] = (
                        cleanup["outcome"] == "EXACT_LEASE_RELEASED"
                    )
                    if record["qualifying_acceptance"]:
                        require(
                            cleanup["outcome"] == "EXACT_LEASE_RELEASED"
                            and cleanup["session_id"] == record["session_id"]
                            and cleanup["lease_id"] == record["lease_id"],
                            "successful acceptance requires exact proven lease release",
                        )
                except Exception as error:  # noqa: BLE001 - record any failed stage/cleanup; never qualify it.
                    record["lease_released"] = False
                    record["release_error"] = type(error).__name__ + ": " + str(error)
                    record["qualifying_acceptance"] = False
            else:
                record["lease_acquired"] = False
            record["finished_at"] = now()
            record["elapsed_seconds"] = time.monotonic() - started
            exclusive_json(OUT / (name + "-" + head + "-result.json"), record)
            print(json.dumps(record), flush=True)
        finally:
            for sig, handler in old_handlers.items():
                signal.signal(sig, handler)
    return record


def interrupt(signum, _frame):
    raise Interrupted("requested signal " + str(signum))


def main():
    require(len(sys.argv) == 1, "this wrapper accepts no arguments")
    require(digest(PRIOR_WRAPPER.read_bytes()) == PRIOR_DIGEST, "prior wrapper changed")
    require(OUT.parent.resolve() == OUT.parent, "unexpected output parent")
    OUT.mkdir(mode=0o700, exist_ok=False)
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, interrupt)
    env = {
        **os.environ,
        "PATH": str(Path(PYTHON).parent)
        + os.pathsep
        + str(NODE_DIR)
        + os.pathsep
        + os.environ.get("PATH", ""),
        "TRADE_AI_CI": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
    }
    results = []
    for candidate in CANDIDATES:
        row = run_candidate(*candidate, env)
        results.append(row)
        if row.get("interrupted"):
            break
    passed = len(results) == len(CANDIDATES) and all(
        row["qualifying_acceptance"] for row in results
    )
    exclusive_json(
        OUT / "cohort-result.json",
        {
            "required_candidates": len(CANDIDATES),
            "completed_candidates": len(results),
            "passed": passed,
            "candidates": [
                {
                    "candidate": row["candidate"],
                    "head": row["expected_head"],
                    "qualifying_acceptance": row["qualifying_acceptance"],
                }
                for row in results
            ],
            "scope": "Local native/source and static build identity only; no deployment or business-output proof.",
        },
    )
    return 0 if passed else 1


if __name__ == "__main__":
    sys.exit(main())
