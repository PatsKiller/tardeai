# Ship compatible CC readers before projection v2 writers

Status: DRAFT
as_of: 2026-10-19T00:17:36.178876+00:00
Measured at: reviewed source 72ed52373a7b4ef4a3bedcd9ec3d3f3305177ed3; baseline 7af14c7782cf7ab0cba261cc25e6789fe810b092; production a2aef7b4d2de17e737526337a2ffc37848deda4f

A loaded old CC bundle can turn unavailable v2 totals into zero, count a sample
as a full window, or keep a retained outbox green after a backend error. A server
restart or HTTP rejection does not replace that already loaded code. The actual
old readers remain frozen in fixtures, alongside source-backed v1/v2 producer
observations. Five expected baseline assertions fail and two controls pass;
the identical seven assertions pass with the compatible readers.

This first stage preserves the API and all three actual v1 producers unchanged.
Every new reader explicitly requests projection_version=2 on its existing read
path, giving the later writer a version selector and independent URL cache key.
The current old backend still returns v1; the new readers label that response
as legacy/partial, without asserting unknown complete totals. Unsupported majors,
errors and stale records remain visible rather than invented healthy counts.

The loaded bundle's full source SHA and build stamp are compiled into the code.
A separate bounded metadata poll compares the currently served artifact and
shows an explicit reload action if it differs. It does not claim to force old
tabs to refresh, invalidate sessions, or establish authentication/MFA. Independent
source validation passes32 Python tests and six affected TS suites.

The original exact72 sandbox npm build passed but could not resolve Git identity;
its metadata remains unavailable. The requested host Vite build never started
and has no successful receipt. Those observations stay separate. Final integrated
frontend/native acceptance, a known compiled host identity, and actual
authenticated refreshed-client readback remain required before the next stage.

All four new TS suites are added to the existing package build. The real reader
Python fixture uses esbuild and React; canonical CI therefore installs the locked
frontend dependencies through one shared action. It reuses the existing shard
plan so only the owning shard installs Node/npm dependencies; ordinary/full jobs
also install them before running registered tests. No mandatory tests are skipped
or deferred by this dependency setup. A focused22-test run executes the actual
metadata selector over the real plan and the actual reader/component fixtures.

The later writer must preserve real v1 defaults and enable v2 only on an explicit
supported version. Its authenticated client/rollback acceptance is separate.
This packet claims local implementation, source review and hermetic behavior;
it claims no deployment, activation, live browser proof or business recovery.
Raw failed and passing observations are retained losslessly in the manifest.
