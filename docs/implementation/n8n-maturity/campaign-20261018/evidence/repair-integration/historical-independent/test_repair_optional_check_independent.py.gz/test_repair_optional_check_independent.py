"""A real PR rollup includes an intentionally skipped optional full-suite job."""
from scripts.lib import self_heal_fix_evaluator as E


def test_optional_skipped_job_does_not_veto_successful_versioned_mandatory_checks():
    sha = 'a' * 40
    required = ['cio-hardening', 'agent-governance', 'release-readiness']
    checks = [{'name': name, 'status': 'COMPLETED', 'conclusion': 'SUCCESS'} for name in required]
    checks.append({'name': 'cio-hardening-full', 'status': 'COMPLETED', 'conclusion': 'SKIPPED'})
    result = E.pr_head_verdict({'headRefOid': sha, 'statusCheckRollup': checks}, expected_head=sha,
                               required=required, policy_version='2026-10-18.1')
    assert result['verdict'] == 'pass'
