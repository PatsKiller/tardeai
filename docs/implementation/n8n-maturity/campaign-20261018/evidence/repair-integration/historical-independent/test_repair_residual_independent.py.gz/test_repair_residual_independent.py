"""Independent repair candidate adversarial checks; hermetic, no provider or subprocess."""
from datetime import datetime, timezone
from scripts import self_heal_fixer as S
from scripts.lib import self_heal_fixer as F


def test_error_message_mentioning_assert_does_not_prove_an_assertion(tmp_path):
    p = tmp_path / "report.xml"
    p.write_text('<testsuites><testsuite><testcase classname="regression" name="case">'
                 '<failure message="ValueError: assert expected output">'
                 'raise ValueError("assert expected output")</failure></testcase></testsuite></testsuites>')
    proof = S.pytest_proof(p)
    assert proof["assertion_failures"] == []


def test_huge_provider_cost_is_unknown_instead_of_parser_error():
    try:
        value = F.reported_cost(10 ** 1000)
    except OverflowError:
        value = "parser_exception"
    assert value is None


def test_expired_absolute_job_deadline_prevents_lifecycle_subprocess(tmp_path):
    calls = []
    job = {"state": F.FIX_READY_LOCAL, "branch": "safe-canary", "deadline_at": "2026-10-18T17:59:59+00:00"}
    S.advance(job, cfg={}, now=datetime(2026, 10, 18, 18, tzinfo=timezone.utc), diag_state={},
              root=tmp_path, repo=tmp_path,
              gh=lambda argv: calls.append(argv) or {"rc": 0, "out": "[]"})
    assert calls == [], "every subprocess must honor the job's absolute deadline"
