"""Repair qualification regressions. External effects are temporary fixtures only."""
import copy
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import pytest

from scripts.lib import self_heal_fix_evaluator as E
from scripts.lib import self_heal_fixer as F
from scripts import self_heal_fixer as S

SHA = 'a' * 40
POLICY = {'schema': 'SelfHealCiAcceptancePolicy@v1', 'version': '2026-10-18.1',
          'required_checks': ['cio-hardening', 'agent-governance', 'release-readiness']}
NOW = datetime(2026, 10, 18, 18, 0, tzinfo=timezone.utc)


def rollup(conclusion='SUCCESS', names=('mandatory',)):
    return [{'name': name, 'status': 'COMPLETED', 'conclusion': conclusion} for name in names]


def test_required_checks_cannot_be_empty():
    assert E.pr_head_verdict({'headRefOid': SHA, 'statusCheckRollup': rollup()}, expected_head=SHA)['verdict'] != 'pass'


@pytest.mark.parametrize('conclusion', ['SKIPPED', 'NEUTRAL'])
def test_mandatory_check_must_succeed(conclusion):
    assert E.pr_head_verdict({'headRefOid': SHA, 'statusCheckRollup': rollup(conclusion)},
                            expected_head=SHA, required=['mandatory'])['verdict'] != 'pass'


def test_short_equal_heads_do_not_identify_candidate():
    short = SHA[:12]
    assert E.pr_head_verdict({'headRefOid': short, 'statusCheckRollup': rollup()},
                            expected_head=short, required=['mandatory'])['verdict'] != 'pass'


@pytest.mark.parametrize('raw', ['not-json', '{"result":"complete"}', '{"total_cost_usd":null}',
                               '{"total_cost_usd":"bad"}', '{"total_cost_usd":-1}',
                               '{"total_cost_usd":true}', '{"total_cost_usd":NaN}'])
def test_unknown_or_invalid_provider_cost_stays_unknown(raw):
    # A parser exception is not the contract: unknown cost must be a typed result.
    try:
        cost = F.parse_claude_result(raw)['cost_usd']
    except (ValueError, TypeError):
        cost = 'parser_exception'
    assert cost is None


def test_ci_rejection_blocks_deployment_even_with_merged_ancestor(tmp_path, monkeypatch):
    release = tmp_path / 'sha'
    release.write_text('c' * 40)
    job = {'state': F.FIX_PR_OPENED, 'lane': 'safe-canary', 'pr_number': 1, 'head_sha': SHA,
           'history': [], 'iterations': [{'passed': True, 'acceptance': {'accepted': True, 'commit_sha': SHA}}]}
    doc = {'state': 'MERGED', 'mergeCommit': {'oid': 'b' * 40}, 'headRefOid': SHA,
           'statusCheckRollup': rollup('FAILURE', POLICY['required_checks'])}
    monkeypatch.setattr(S, 'git', lambda *a, **k: {'rc': 0, 'out': '', 'err': ''})
    result = S.advance(job, cfg={'acceptance': POLICY, 'lifecycle': {'release_current_sha_file': str(release)}},
                       now=NOW, diag_state={}, root=tmp_path, repo=tmp_path,
                       gh=lambda *a: {'rc': 0, 'out': json.dumps(doc), 'err': ''})
    assert job['acceptance']['accepted'] is False
    assert result is None and job['state'] == F.FIX_PR_OPENED


def test_previous_rejection_blocks_output_recovery(tmp_path, monkeypatch):
    job = {'state': F.FIX_DEPLOYED, 'lane': 'safe-canary', 'head_sha': SHA, 'history': [],
           'acceptance': {'accepted': False}, 'deployed_at': NOW.isoformat()}
    monkeypatch.setattr(S, 'output_recovered', lambda *a: {'recovered': True, 'run_id': 'fresh', 'finished_at': NOW.isoformat()})
    result = S.advance(job, cfg={'acceptance': POLICY, 'intake': {'ledger_rel': 'ledger'}}, now=NOW,
                       diag_state={}, root=tmp_path, repo=tmp_path, gh=lambda *a: {})
    assert result is None and job['state'] == F.FIX_DEPLOYED


def test_collection_error_is_not_red_first():
    cand = {'commit_sha': SHA, 'tree_sha': 'd' * 40, 'base_sha': 'b' * 40}
    runs = [{'kind': kind, 'run_id': kind, 'checkout_sha': cand['base_sha'] if kind == 'red_first' else SHA,
             'head_after': cand['base_sha'] if kind == 'red_first' else SHA, 'overlay_from': SHA if kind == 'red_first' else None,
             'integrity_ok': True, 'rc': 2 if kind == 'red_first' else 0} for kind in E.REQUIRED_RUNS]
    fact = {'tests_run': ['tests/test_safe.py'], 'red_first': True, 'targeted_rc': 0, 'ci_rc': 0,
            'refusals': [], 'candidate': cand, 'guard': {'tree_sha': cand['tree_sha']}, 'test_runs': runs}
    assert E.local_verdict(fact)['accepted'] is False


def test_subprocess_is_bounded_by_absolute_job_deadline(tmp_path, monkeypatch):
    marker = tmp_path / 'late-effect'
    class SlowSetup:
        def __init__(self, *args, **kwargs):
            self.branch = 'safe'; self.fix_wt = tmp_path / 'wt'; self.eval_root = tmp_path / 'eval'
        def setup(self):
            S.run([sys.executable, '-c', 'import time; from pathlib import Path; time.sleep(.25); Path(' + repr(str(marker)) + ').write_text("late")'], timeout=5)
            return 'setup_stopped'
        def teardown(self, **kwargs):
            pass
    monkeypatch.setattr(S, 'Attempt', SlowSetup)
    cfg = {'iteration': {'max_minutes': .001}}
    job = {'state': F.FIX_REQUESTED, 'history': [], 'iterations': [], 'cost_usd': 0}
    S.attempt_job(job, {}, cfg=cfg, environ={}, now=lambda: NOW, evidence_dir=tmp_path,
                  may_push=False, rails='', backend='test')
    assert not marker.exists(), 'subprocess performed work after absolute job deadline'

