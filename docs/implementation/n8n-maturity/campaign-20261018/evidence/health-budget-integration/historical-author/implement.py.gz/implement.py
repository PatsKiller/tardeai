from pathlib import Path
root=Path('/home/johnclaw/tradeai-wt-n8n-health-retry-budget-20261019')
helper='''"""Host-only durable attempt accounting shared by bounded recovery owners.

This module creates neither authority nor initial history. The health namespace additionally requires a
host history source; no such production source is provisioned by this change. Reservations never refund.
"""
from __future__ import annotations

import datetime as dt
import fcntl
import json
import math
import os
import re
import time
import uuid
from contextlib import contextmanager
from pathlib import Path

SUPERVISOR = "supervisor_recovery"
HEALTH = "system_health_retry"
LOCK_WAIT_S = 3.0
_HEALTH_FIELDS = {"schema", "namespace", "component", "ts", "attempt_id", "command_digest"}


def _closed_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate_history_field")
        result[key] = value
    return result


def _policy(now, limit, window_s, namespace):
    if (type(limit) is not int or limit < 0 or type(window_s) is not int or window_s <= 0
            or not isinstance(now, dt.datetime) or now.tzinfo is None or now.utcoffset() is None
            or namespace not in (SUPERVISOR, HEALTH)):
        raise ValueError("invalid_budget_or_clock")
    return now.astimezone(dt.timezone.utc)


def counts(path: Path, now, *, limit: int, window_s: int, namespace: str, text=None) -> dict[str, int]:
    """Count a trusted history snapshot. Supervisor reservation/result rows retain v1 identity semantics."""
    instant = _policy(now, limit, window_s, namespace)
    cutoff = instant - dt.timedelta(seconds=window_s)
    raw = path.read_text(encoding="utf-8") if text is None else text
    if type(raw) is not str:
        raise ValueError("unavailable_history_source")
    attempts = set()
    identities = {}
    for index, line in enumerate(raw.splitlines()):
        if not line.strip():
            continue
        row = json.loads(line, object_pairs_hook=_closed_object)
        if not isinstance(row, dict):
            raise ValueError("malformed_budget_history")
        if namespace == HEALTH:
            if (set(row) != _HEALTH_FIELDS or row.get("schema") != "HealthRetryAttempt@v1"
                    or row.get("namespace") != HEALTH or not isinstance(row.get("component"), str)
                    or not row["component"].strip() or not isinstance(row.get("attempt_id"), str)
                    or re.fullmatch(r"[0-9a-f]{32}", row["attempt_id"]) is None
                    or not isinstance(row.get("command_digest"), str)
                    or re.fullmatch(r"[0-9a-f]{64}", row["command_digest"]) is None):
                raise ValueError("malformed_health_attempt")
            lane, attempt, attempted = row["component"], row["attempt_id"], True
            identity = tuple(row[key] for key in sorted(_HEALTH_FIELDS))
            if attempt in identities:
                raise ValueError("duplicate_health_attempt_identity")
        else:
            if (row.get("schema") != "Recovery@v1" or type(row.get("executed")) is not bool
                    or not isinstance(row.get("lane_id"), str) or not row["lane_id"]
                    or row.get("mode") not in ("live", "shadow")):
                raise ValueError("malformed_budget_history")
            if any(field in row and type(row[field]) is not bool for field in ("attempted", "attempt_reserved")):
                raise ValueError("malformed_attempt_flags")
            lane, attempt = row["lane_id"], row.get("attempt_id")
            identity = (lane, row.get("action"), row.get("level"), row.get("mode"), row.get("ts"))
            if "attempt_id" in row:
                if not isinstance(attempt, str) or not attempt or row.get("attempt_reserved") is not True:
                    raise ValueError("malformed_attempt_identity")
                if attempt in identities and identities[attempt] != identity:
                    raise ValueError("conflicting_attempt_identity")
            # Legacy timeout/spawn failures count even though executed=false.
            attempted = (row.get("attempt_reserved") is True or row.get("attempted") is True
                         or row["executed"] or (row["mode"] == "live" and bool(row.get("error"))))
        if attempt:
            identities[attempt] = identity
        at = dt.datetime.fromisoformat(str(row.get("ts") or "").replace("Z", "+00:00"))
        if at.tzinfo is None or at.utcoffset() is None or at > instant:
            raise ValueError("invalid_budget_history_clock")
        if attempted and at >= cutoff:
            attempts.add((lane, attempt if attempt else f"legacy-line-{index}"))
    result = {}
    for lane, _ in attempts:
        result[lane] = result.get(lane, 0) + 1
    return result


def append(path: Path, row: dict) -> None:
    """Caller owns the journal lock; append and fsync before invoking any effect."""
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(row, sort_keys=True, default=str) + "\\n")
        stream.flush()
        os.fsync(stream.fileno())


@contextmanager
def journal_lock(path: Path, *, deadline=None):
    """Bound reservation/settlement contention by both a small host cap and the caller's deadline."""
    end = time.monotonic() + LOCK_WAIT_S
    if deadline is not None:
        if type(deadline) not in (int, float) or not math.isfinite(deadline):
            raise ValueError("invalid_lock_deadline")
        end = min(end, deadline)
    with path.with_suffix(".lock").open("a", encoding="utf-8") as lock:
        while True:
            if time.monotonic() >= end:
                raise TimeoutError("attempt_budget_lock_deadline")
            try:
                fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                time.sleep(min(0.01, max(0, end - time.monotonic())))
        try:
            yield
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def reserve(path: Path, row: dict, now, *, limit: int, window_s: int, namespace: str,
            live: bool, history_source=None, deadline=None, observed_count=0) -> tuple[bool, str]:
    """One lock/read/validate/reserve/fsync owner. A missing or unknown source never initializes zero."""
    try:
        _policy(now, limit, window_s, namespace)
        if type(live) is not bool or type(observed_count) is not int or observed_count < 0:
            raise ValueError("invalid_admission")
        with journal_lock(path, deadline=deadline):
            # Existing bytes must survive; no initializer or empty replacement is permitted.
            disk = path.read_text(encoding="utf-8")
            if namespace == HEALTH:
                if history_source is None:
                    return False, "uninitialized"
                text = history_source(path, now)
                if text is None:
                    return False, "uninitialized"
                if type(text) is not str or text != disk:
                    raise ValueError("unbound_history_source")
                lane = row.get("component")
            else:
                text, lane = disk, row.get("lane_id")
            recent = counts(path, now, limit=limit, window_s=window_s, namespace=namespace, text=text)
            if not isinstance(lane, str) or not lane:
                raise ValueError("invalid_admission_lane")
            allowed = max(recent.get(lane, 0), observed_count) < limit
            if namespace == SUPERVISOR:
                row["would_execute"] = allowed
                if live and allowed:
                    row["attempt_id"] = uuid.uuid4().hex
                    record = {**row, "attempt_reserved": True, "attempted": False}
                else:
                    record = row
                # Validate new rows as well as historical rows before persisting or acting.
                counts(path, now, limit=limit, window_s=window_s, namespace=namespace,
                       text=json.dumps(record))
                append(path, record)
            elif live and allowed:
                record = {**row, "attempt_id": uuid.uuid4().hex}
                counts(path, now, limit=limit, window_s=window_s, namespace=namespace,
                       text=json.dumps(record))
                append(path, record)
                row.update(record)
            return allowed, "known"
    except (OSError, ValueError, TypeError, OverflowError):
        return False, "unavailable"
'''
(root/'scripts/lib/recovery_attempt_budget.py').write_text(helper)
p=root/'scripts/supervisor_breach_detector.py'
s=p.read_text(); start=s.index('def _recovery_budget('); end=s.index('\ndef _self_heal_l1_l2',start)
s=s[:start]+'''def _recovery_budget(path: Path, now) -> dict[str, int]:
    """Compatibility wrapper over the shared owner; existing Recovery@v1 history is unchanged."""
    from lib import recovery_attempt_budget as budget

    return budget.counts(path, now, limit=L1_MAX_PER_WINDOW, window_s=L1_WINDOW_S,
                         namespace=budget.SUPERVISOR)


def _recovery_row(path: Path, row: dict) -> None:
    from lib import recovery_attempt_budget as budget

    budget.append(path, row)


def _reserve_recovery(path: Path, row: dict, now, *, live: bool) -> tuple[bool, str]:
    from lib import recovery_attempt_budget as budget

    return budget.reserve(path, row, now, limit=L1_MAX_PER_WINDOW, window_s=L1_WINDOW_S,
                          namespace=budget.SUPERVISOR, live=live)

''' + s[end:]
s=s.replace('''    import fcntl
    import subprocess
    by_id''','''    import subprocess
    from lib import recovery_attempt_budget as budget

    by_id''',1)
s=s.replace('''        with rec_p.with_suffix(".lock").open("a", encoding="utf-8") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            _recovery_row(rec_p, row)''','''        try:
            with budget.journal_lock(rec_p):
                _recovery_row(rec_p, row)
        except (OSError, ValueError):
            # The durable reservation still consumes the attempt if result recording is unavailable.
            out["budget_status"] = "unavailable"
            break''',1)
p.write_text(s)
p=root/'scripts/system_health_agent.py';s=p.read_text()
s=s.replace('def _attempt_retry(comp, conn):','''def _health_retry_history(path, now):
    """UNINITIALIZED: no reviewed complete host-history source is installed.

    Legacy PG events are deduplicated and cannot establish complete attempt history. Neither a file,
    environment flag nor a caller-supplied initialized boolean creates this missing provenance.
    """
    return None


def _attempt_retry(comp, conn, *, attempt_state=None):''',1)
s=s.replace('''    cmd = comp.get("retry_cmd")
''','''    if attempt_state is not None:
        attempt_state.update(attempted=False, budget_status="not_evaluated")
    cmd = comp.get("retry_cmd")
''',1)
start=s.index('    # Check retry count today.',s.index('def _attempt_retry'))
end=s.index('    # Clear stale lock ONLY',start)
s=s[:start]+'''    import hashlib
    import math
    import time
    from lib import recovery_attempt_budget as budget

    def hold(reason):
        if attempt_state is not None:
            attempt_state["budget_status"] = reason
        _log_event(conn, component, "RETRY_BUDGET_HELD", "WARN", reason, success=False)
        return False

    # Include contention and DB inspection in this attempt's absolute process deadline.
    timeout_s = comp.get("max_runtime_sec", 300)
    if (type(MAX_RETRIES) is not int or MAX_RETRIES < 0 or type(timeout_s) not in (int, float)
            or not math.isfinite(timeout_s) or timeout_s <= 0):
        return hold("unavailable")
    deadline = time.monotonic() + timeout_s
    retries_today = 0
    try:
        cur = conn.cursor()
        cur.execute(
            """SELECT COUNT(*) FROM system_health_events
            WHERE component=%s AND event_type IN ('RETRY', 'RETRY_TIMEOUT', 'RETRY_ERROR')
            AND created_at > NOW() - INTERVAL '24 hours'""",
            [component],
        )
        retries_today = cur.fetchone()[0]
        conn.commit()  # never retain an idle read transaction through a subprocess
        if type(retries_today) is not int or retries_today < 0:
            return hold("unavailable")
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        return hold("unavailable")

    state_root = Path(os.environ.get("TRADEAI_STATE_ROOT") or
                      (Path.home() / "trade-ai-releases" / "persistent-state"))
    journal = state_root / "data/runtime/health_retry_attempts.jsonl"
    reservation = {
        "schema": "HealthRetryAttempt@v1", "namespace": budget.HEALTH, "component": component,
        "ts": datetime.now(timezone.utc).isoformat(),
        "command_digest": hashlib.sha256(cmd.encode("utf-8")).hexdigest(),
    }
    allowed, status = budget.reserve(
        journal, reservation, datetime.now(timezone.utc), limit=MAX_RETRIES, window_s=86400,
        namespace=budget.HEALTH, live=True, history_source=_health_retry_history,
        deadline=deadline, observed_count=retries_today,
    )
    if not allowed:
        return hold("exhausted" if status == "known" else status)
    if attempt_state is not None:
        attempt_state.update(budget_status="known", attempt_id=reservation["attempt_id"])
    # Reservation is irrevocable, including a crash or deadline expiry before spawn.
    if time.monotonic() >= deadline:
        return hold("deadline_exhausted")

''' + s[end:]
s=s.replace('''    timeout_s = comp.get("max_runtime_sec", 300)
    proc = None
''','''    proc = None
''',1)
s=s.replace('''        proc = subprocess.Popen(
''','''        if time.monotonic() >= deadline:
            return hold("deadline_exhausted")
        if attempt_state is not None:
            attempt_state["attempted"] = True
        proc = subprocess.Popen(
''',1)
s=s.replace('''out, err = proc.communicate(timeout=timeout_s)''','''out, err = proc.communicate(timeout=max(0, deadline - time.monotonic()))''',1)
s=s.replace('''                success = _attempt_retry(comp, conn)
                check["action_taken"] = "retry_success" if success else "retry_failed"
                report["summary"]["retried"] += 1''','''                attempt_state = {}
                success = _attempt_retry(comp, conn, attempt_state=attempt_state)
                attempted = attempt_state.get("attempted") is True
                check["retry_admission"] = attempt_state
                check["action_taken"] = ("retry_success" if success else "retry_failed") if attempted else "retry_held"
                report["summary"]["retried"] += int(attempted)
                if not attempted:
                    report["summary"]["retry_held"] = report["summary"].get("retry_held", 0) + 1''',1)
s=s.replace('''else {"recovered": False, "reason": "retry_process_failed"}''','''else {"recovered": False, "reason": "retry_process_failed" if attempted
                          else "retry_budget_" + attempt_state.get("budget_status", "unavailable")}''',1)
s=s.replace('''"retry_completed_unproven_escalated" if success else "retry_failed_escalated"''','''"retry_completed_unproven_escalated" if success else
                            "retry_failed_escalated" if attempted else "retry_held_escalated"''',1)
s=s.replace('''            "retry_failed_escalated",
''','''            "retry_failed_escalated",
            "retry_held_escalated",
''',1)
p.write_text(s)
