#!/usr/bin/env python3
"""system_health_agent.py — Execution Integrity Agent.

Continuously monitors every cron job, process, and execution path.
Detects silent failures, lock contention, stale output, abnormal runtimes.
Self-heals with retries. Escalates via central alert router.

Schedule: */5 * * * 1-5 (every 5 min weekdays), */15 * * * 0,6 (every 15 min weekends)

NO bypass_router. NO direct Telegram. ALL alerts through central router.
"""

import argparse, json, logging, os, subprocess, sys, time, uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _resolve_log(log_file: str) -> Path:
    """Prefer the governed state log, never a frozen code log merely because it exists.

    Legacy code-log compatibility is reported as drift by the freshness reader;
    it supplies activity only, never accepted business-output proof.
    """
    code = PROJECT_ROOT / "logs" / log_file
    if not log_file:
        return code
    root = os.getenv("TRADEAI_STATE_ROOT") or str(PROJECT_ROOT.parent.parent / "persistent-state")
    state = Path(root) / "logs" / log_file
    if state.exists():
        return state
    return code if code.exists() else state


sys.path.insert(0, str(PROJECT_ROOT / "scripts"))

from dotenv import load_dotenv

load_dotenv(PROJECT_ROOT / ".env")

logging.basicConfig(level=logging.INFO, format="%(asctime)s [health-agent] %(message)s")
log = logging.getLogger("system_health_agent")

# ── Configuration: Every monitored component ─────────────────────────────────
# schedule: cron-style human readable, for display
# log_file: path relative to PROJECT_ROOT/logs
# max_age_min: max minutes since last log output before flagged stale
# max_runtime_sec: max expected runtime before flagged slow
# critical: if True, failure triggers P0 escalation
# retry_cmd: command to retry on failure (relative to PROJECT_ROOT)
# downstream: what breaks if this fails
MONITORED_COMPONENTS = [
    # ── Pipeline Core ──
    {
        "component": "trade_ai_orchestrator",
        "display": "Trade AI Orchestrator",
        "schedule": "0 9,10,12,14,16 * * 1-5",
        "log_file": "screener_pm.log",
        "monitor_lane_ids": ["orchestrator-slot", "orchestrator-slot-midday"],
        "max_age_min": 180,
        "max_runtime_sec": 600,
        "critical": True,
        "retry_cmd": ".venv/bin/python scripts/trade_ai_orchestrator.py --run-label 0900 --no-llm --no-alerts --allow-underfilled",
        "downstream": "strategy_signals, proposals, ATM execution",
        "lock_file": "/tmp/screener_pm.lock",
    },
    {
        "component": "auto_proposal_generator",
        "display": "Auto Proposal Generator",
        "schedule": "*/30 9-16 * * 1-5",
        "log_file": "auto_proposal.log",
        "monitor_lane_ids": ["auto-proposal-general"],
        "max_age_min": 60,
        "max_runtime_sec": 300,
        "critical": True,
        "retry_cmd": ".venv/bin/python scripts/auto_proposal_generator.py --today --apply",
        "downstream": "proposals, ATM execution",
    },
    {
        "component": "rotation_autopilot",
        "display": "Rotation Autopilot (IWM/SPY trend switch)",
        "schedule": "*/15 4-16 * * 1-5",
        "log_file": "rotation_autopilot.log",
        "max_age_min": 45,
        "max_runtime_sec": 180,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/rotation_autopilot.py --tick --trigger health_retry",
        "downstream": "watchlist, qualified_intelligence, strategy_signals, proposals",
        "lock_file": "/tmp/tradeai_rotation_autopilot.lock",
    },
    {
        "component": "incubator_proposal_promoter",
        "display": "Incubator Promoter",
        "schedule": "0 7-17 * * 1-5",
        "log_file": "incubator_promoter.log",
        "monitor_lane_ids": ["incubator-proposal-promoter"],
        "max_age_min": 180,
        "max_runtime_sec": 300,
        "critical": True,
        "retry_cmd": ".venv/bin/python scripts/incubator_proposal_promoter.py --run",
        "downstream": "proposals from incubator",
        "lock_file": "/tmp/incubator_promoter.lock",
    },
    {
        "component": "finviz_screener_runner",
        "display": "Finviz Screener",
        "schedule": "0 8 * * 1-5",
        "log_file": "finviz_screener.log",
        "monitor_lane_ids": ["finviz-screener-runner"],
        "receipt_lane_id": "finviz-screener-runner",
        "receipt_script": "finviz_screener_runner.py",
        "max_age_min": 1500,
        "max_runtime_sec": 600,
        "critical": True,
        "retry_cmd": ".venv/bin/python scripts/finviz_screener_runner.py --apply",
        "downstream": "scanner input data",
    },
    {
        "component": "news_ingestion",
        "display": "News Ingestion",
        "schedule": ["30 12 * * 1-5", "30 0 * * *"],
        "log_file": "news_ingestion.log",
        "max_age_min": 780,
        "max_runtime_sec": 600,
        "critical": True,
        "retry_cmd": ".venv/bin/python scripts/news_ingestion.py --priority",
        "downstream": "catalyst detection, news alerts",
    },
    # ── Trade Monitoring ──
    {
        "component": "unified_stop_supervisor",
        "display": "Stop Supervisor",
        "schedule": "*/3 9-16 * * 1-5",
        "log_file": "unified_stop_supervisor.log",
        "max_age_min": 10,
        "max_runtime_sec": 120,
        "critical": True,
        "retry_cmd": ".venv/bin/python scripts/unified_stop_supervisor.py --apply",
        "downstream": "trailing stops, target exits, stop monitoring",
    },
    {
        "component": "holding_protection_advisor",
        "display": "Stop/Trail Protection Advisor",
        "schedule": "5 17 * * 1-5",
        "log_file": "protection_advisor.log",
        "max_age_min": 1500,
        "max_runtime_sec": 900,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/holding_protection_advisor.py",
        "downstream": "stop/trail advisories, Stop Management tab",
        "lock_file": "/tmp/protection_advisor.lock",
    },
    {
        "component": "stop_drift_alert",
        "display": "Stop Drift + Lock-in Alerts",
        "schedule": "35 17 * * 1-5",
        "log_file": "stop_drift_alert.log",
        "max_age_min": 1500,
        "max_runtime_sec": 120,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/stop_drift_alert.py --send",
        "downstream": "raise-stop + lock-in Telegram nudges",
        "lock_file": "/tmp/stop_drift_alert.lock",
    },
    # paper_trade_monitor replaced by unified_stop_supervisor (STOP-V2.2)
    {
        "component": "alpaca_reconciler",
        "display": "Alpaca Reconciler",
        "schedule": "5 16 * * 1-5",
        "log_file": "alpaca_reconciler.log",
        "max_age_min": 1500,
        "max_runtime_sec": 60,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/alpaca_paper_reconciler.py",
        "downstream": "DB-broker sync",
    },
    # ── Data Pipeline ──
    {
        "component": "finviz_enrichment",
        "display": "Finviz Enrichment",
        "schedule": "10 7 * * 1-5",
        "log_file": "finviz_enrichment.log",
        "max_age_min": 1500,
        "max_runtime_sec": 600,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/finviz_enrichment.py",
        "downstream": "enriched scanner data",
    },
    {
        "component": "price_db_sync",
        "display": "Price DB Sync",
        "schedule": "20 7 * * 1-5",
        "log_file": "price_db_sync.log",
        "max_age_min": 1500,
        "max_runtime_sec": 600,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/price_db_sync.py",
        "downstream": "price data freshness",
    },
    {
        "component": "rag_indexer",
        "display": "RAG Indexer",
        "schedule": "0 */4 * * *",
        "log_file": "rag_indexer.log",
        "max_age_min": 300,
        "max_runtime_sec": 600,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/rag_indexer.py",
        "downstream": "agent context, RAG search",
    },
    {
        "component": "indicator_engine",
        "display": "Indicator Engine",
        "schedule": "0 8 * * 1-5",
        "log_file": "indicator_engine.log",
        "max_age_min": 1500,
        "max_runtime_sec": 900,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/indicator_engine.py",
        "downstream": "technical indicators",
    },
    # ── Agents ──
    {
        "component": "aegis_morning_brief",
        "display": "Aegis Morning Brief",
        "schedule": "5 8 * * 1-5",
        "log_file": "aegis_brief.log",
        "max_age_min": 1500,
        "max_runtime_sec": 300,
        "critical": False,
        "retired": "2026-09-14 operator decision: one 07:30 ET brief (lane morning-brief-0730); the 08:05 "
        "aegis_morning_brief_delivery lane is RETIRED in config/lane_registry.json. The agent kept "
        "it MISSING and retried the retired sender twice a day until 2026-10-07 (exit 127 only "
        "because .venv/bin/python is absent from the served tree).",
        "downstream": "daily brief delivery",
    },
    {
        "component": "telegram_command_handler",
        "display": "Telegram callback poller (systemd)",
        # 2026-10-07: the handler is tradeai-telegram-callback-poller.service (lane telegram-callback-poller,
        # Restart=always, RestartSec=5) logging every ~25 s to <state root>/logs/telegram_callback_poller.log.
        # No retry_cmd: launching a second --poll process would duplicate getUpdates polling; systemd restarts it.
        "schedule": "*/2 * * * *",
        "log_file": "telegram_callback_poller.log",
        "max_age_min": 5,
        "max_runtime_sec": 60,
        "critical": True,
        "downstream": "operator commands, approval buttons",
    },
    # ── Cleanup & Governance ──
    {
        "component": "cleanup_stale_proposals",
        "display": "Stale Proposal Cleanup",
        "schedule": "0 10,15 * * 1-5",
        "log_file": "cleanup_stale_proposals.log",
        "max_age_min": 1500,
        "max_runtime_sec": 60,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/cleanup_stale_proposals.py --apply",
        "downstream": "proposal hygiene",
    },
    {
        "component": "pipeline_watchdog",
        "display": "Pipeline Watchdog",
        "schedule": "0 */2 * * *",
        "log_file": "pipeline_watchdog.log",
        "max_age_min": 150,
        "max_runtime_sec": 300,
        "critical": True,
        "retry_cmd": ".venv/bin/python scripts/pipeline_watchdog.py",
        "downstream": "pipeline self-healing",
    },
    # ── TCA ──
    {
        "component": "tca_analyzer",
        "display": "TCA Execution Quality",
        "schedule": "30 16 * * 1-5",
        "log_file": "tca_analyzer.log",
        "max_age_min": 1500,
        "max_runtime_sec": 60,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/paper_execution_quality_analyzer.py --recent --apply",
        "downstream": "execution quality page",
    },
    # ── LLM Backtesting (v3.8) ──
    {
        "component": "trade_close_llm_analyzer",
        "display": "LLM Close-of-Trade Analysis",
        # script runs weekday 21:00 (structured_eval.log); Sunday 23:00 run is monitored
        # separately by llm_backtest_reviewer. Was pointed at a log path that never existed.
        "schedule": "0 21 * * 1-5",
        "log_file": "structured_eval.log",
        "max_age_min": 1500,
        "max_runtime_sec": 300,
        "critical": False,
        "downstream": "trade_llm_reviews close_analysis, journal learning quality",
    },
    # NOTE: delayed_trade_llm_reviewer + monthly_grok_meta_review removed 2026-06-06 —
    # no backing script and no cron entry exists (never implemented / aspirational).
    # They produced permanent MISSING false positives. Re-add when the jobs actually exist.
    # ── ATM Position Reconciler ──
    {
        "component": "atm_position_reconciler",
        "display": "ATM Position Reconciler",
        "schedule": "*/15 9-16 * * 1-5",
        "log_file": "atm_position_reconciliation/cron.log",
        "max_age_min": 30,
        "max_runtime_sec": 120,
        "critical": False,
        "downstream": "reconciliation health, ghost position detection",
    },
    # ── Quote Refresh ──
    # ── ATM & Proposals ──
    {
        "component": "atm_auto_approver",
        "display": "ATM Auto Approver",
        "schedule": "*/15 7-15 * * 1-5",
        "log_file": "atm.log",
        "max_age_min": 30,
        "max_runtime_sec": 60,
        "critical": True,
        "retry_cmd": ".venv/bin/python scripts/atm_auto_approver.py",
        "downstream": "automated trade approval",
    },
    {
        "component": "proposal_enrichment",
        "display": "Proposal Enrichment",
        "schedule": "*/10 4-19 * * 1-5",
        "log_file": "proposal_enrichment.log",
        "max_age_min": 30,
        "max_runtime_sec": 600,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/proposal_enrichment_loop.py --run --limit 5",
        "downstream": "proposal readiness, agent reviews",
    },
    {
        "component": "agent_event_router",
        "display": "Agent Event Router",
        "schedule": "*/30 * * * *",
        "log_file": "agent_event_router.log",
        "max_age_min": 60,
        "max_runtime_sec": 300,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/agent_event_router.py",
        "downstream": "event-driven agent triggers",
    },
    {
        "component": "paper_execution_sweep",
        "display": "Paper Execution Sweep",
        "schedule": "*/15 9-16 * * 1-5",
        "log_file": "paper_execution.log",
        "max_age_min": 30,
        "max_runtime_sec": 120,
        "critical": True,
        "retry_cmd": ".venv/bin/python scripts/paper_execution_sweep.py",
        "downstream": "order submission, fill detection",
    },
    # ── Intelligence ──
    {
        "component": "alex_daily",
        "display": "Alex Daily Scan",
        "schedule": "0 5 * * 1-5",
        "log_file": "alex_daily.log",
        "max_age_min": 1500,
        "max_runtime_sec": 600,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/run_alex_daily.py --daily",
        "downstream": "CIO intelligence, daily alerts",
    },
    # RETIRED: its cron line has been commented out since 2026-08-08, but this entry kept a retry_cmd, so
    # the self-heal re-ran it every afternoon. Each run wrote 335-381 priority-high HUMAN_REVIEW
    # cio_decisions (3,594 proposed rows on 2026-09-15). A disabled lane is not stale and must not be
    # retried. Re-enabling it is a crontab + lane registry decision, not a self-heal.
    {
        "component": "cio_decision_engine",
        "display": "CIO Decision Engine",
        "schedule": "0 7 * * 1-5",
        "log_file": "cio_decisions.log",
        "max_age_min": 1500,
        "max_runtime_sec": 300,
        "critical": False,
        "retired": "cron disabled 2026-08-08",
        "downstream": "CIO decisions, portfolio allocation",
    },
    {
        "component": "data_gap_resolver",
        "display": "Data Gap Resolver",
        "schedule": "0 10-16 * * 1-5",
        "log_file": "data_gap_resolver.log",
        "max_age_min": 1500,
        "max_runtime_sec": 600,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/data_gap_resolver.py",
        "downstream": "data completeness, enrichment gaps",
    },
    # NOTE: overnight_batch removed 2026-06-06 — the job was intentionally retired
    # (cron tagged PHASE102-RETIRED; last clean run 2026-05-29). Monitoring a retired
    # job produced a permanent STALE false positive. Its agent_performance scorer was
    # rehomed to update_agent_performance.py (below), re-scheduled weekday 20:00.
    {
        "component": "update_agent_performance",
        "display": "Agent Performance Scorer",
        "schedule": "0 20 * * 1-5",
        "log_file": "update_agent_performance.log",
        "max_age_min": 1500,
        "max_runtime_sec": 600,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/update_agent_performance.py",
        "downstream": "agent_performance_history, weekly portfolio review",
    },
    {
        "component": "auto_enrichment",
        "display": "Auto Enrichment Runner",
        "schedule": "*/10 4-19 * * 1-5",
        "log_file": "auto_enrichment.log",
        "max_age_min": 15,
        "max_runtime_sec": 120,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/auto_enrichment_runner.py",
        "downstream": "symbol enrichment, data quality",
    },
    # ── Quote Refresh ──
    {
        "component": "proactive_quote_refresh",
        "display": "Quote Refresh",
        "schedule": "*/5 9-15 * * 1-5",
        "log_file": "proactive_quote_refresh_cron.log",
        "max_age_min": 15,
        "max_runtime_sec": 120,
        "critical": False,
        "retry_cmd": "bash scripts/run_scheduled_quote_refresh.sh --mode pending --limit 50",
        "downstream": "proposal price freshness",
    },
    # ── Portfolio live prices (Finviz authoritative — NOT SnapTrade) ──
    {
        "component": "portfolio_repricer_intraday",
        "display": "Portfolio Repricer (Finviz intraday)",
        "schedule": ["5 9 * * 1-5", "*/15 9-16 * * 1-5"],
        "log_file": "portfolio_repricer_intraday.log",
        "max_age_min": 25,
        "max_runtime_sec": 180,
        "critical": True,
        "retry_cmd": ".venv/bin/python scripts/portfolio_repricer.py",
        "downstream": "holdings.json prices, finviz_quote_cache, Command Center P/L",
        "lock_file": "/tmp/portfolio_repricer.lock",
    },
    {
        "component": "portfolio_repricer_postclose",
        "display": "Portfolio Repricer (EOD close)",
        "schedule": "10 16 * * 1-5",
        "log_file": "portfolio_repricer_postclose.log",
        "max_age_min": 1500,
        "max_runtime_sec": 300,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/portfolio_repricer.py",
        "downstream": "official close capture, holdings reconcile",
    },
    {
        "component": "market_quotes_intraday",
        "display": "Alpaca Market Quotes (intraday backup)",
        "schedule": "*/15 9-16 * * 1-5",
        "log_file": "market_data.log",
        "max_age_min": 25,
        "max_runtime_sec": 120,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/external_market_data_ingest.py --quotes",
        "downstream": "market_quotes DB — Fidelity price fallback behind Finviz",
        "lock_file": "/tmp/mkt_quotes_intraday.lock",
    },
    {
        "component": "snaptrade_sync",
        "display": "SnapTrade Holdings Sync (positions/basis only)",
        "schedule": ["50 9 * * 1-5", "0 13 * * 1-5", "35 17 * * 1-5"],
        "log_file": "snaptrade_sync.log",
        "max_age_min": 480,
        "max_runtime_sec": 120,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/snaptrade_sync.py --apply",
        "downstream": "Fidelity shares/cost_basis — never authoritative for live quotes",
    },
    # ── TradeInView / Journal ──
    {
        "component": "schwab_journal_ingest",
        "display": "Schwab Journal Ingest",
        "schedule": ["15 18 * * 1-5", "*/15 9-16 * * 1-5"],
        "log_file": "schwab_ingest.log",
        "max_age_min": 30,
        "max_runtime_sec": 300,
        "critical": False,
        # Semantic-failure signatures: the ingest can exit 0 with structurally-valid JSON while actually
        # failing (revoked/absent Schwab token → "no Schwab login token", rows_total:0), which the generic
        # Traceback/ERROR heuristics miss. Flag those so a run-and-fail is not recorded as OK on mtime alone.
        # Operator-action alerting for the token itself is handled by health_agent.collect_broker_token_health.
        "error_signatures": ["invalid_grant", "no Schwab login token", "Refresh token is invalid", "OAuthError"],
        # success markers so a stale error earlier in the log window doesn't flag a since-recovered run
        "success_signatures": ['"mode": "APPLIED"', '"inserted":'],
        "retry_cmd": "flock -n /tmp/schwab_ingest.lock bash -c '.venv/bin/python scripts/schwab_transaction_ingest.py --apply && .venv/bin/python scripts/schwab_journal_builder.py --apply'",
        "downstream": "trade_closed, TradeInView trade log, Schwab round-trips",
        "lock_file": "/tmp/schwab_ingest.lock",
    },
    {
        "component": "journal_review_builder",
        "display": "Journal Review Builder (LLM grades)",
        "schedule": "30 18 * * 1-5",
        "log_file": "journal_review.log",
        "max_age_min": 1500,
        "max_runtime_sec": 600,
        "critical": False,
        "retry_cmd": "flock -n /tmp/journal_review.lock .venv/bin/python scripts/journal_review_builder.py",
        "downstream": "journal_trade_reviews, TradeInView annotations",
        "lock_file": "/tmp/journal_review.lock",
    },
    {
        "component": "journal_annotation_reminder",
        "display": "TradeInView Annotation Reminder",
        "schedule": "30 23 * * 1-5",
        "log_file": "journal_annotation_reminder.log",
        "max_age_min": 1500,
        "max_runtime_sec": 120,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/journal_annotation_reminder.py",
        "downstream": "operator annotation coverage nudge",
    },
    {
        "component": "journal_tilt_morning_hook",
        "display": "TradeInView Tilt Morning Hook",
        "schedule": "0 12 * * 1-5",
        "log_file": "journal_tilt_hook.log",
        "max_age_min": 1500,
        "max_runtime_sec": 60,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/journal_tilt_morning_hook.py",
        "downstream": "operator_review_queue tilt review item",
    },
    # ── Recurring Backtesting (v4.0) ──
    {
        "component": "enterprise_backtester",
        "display": "Enterprise Backtester",
        "schedule": "0 22 * * 0",
        "log_file": "enterprise_backtester.log",
        "max_age_min": 10080,
        "max_runtime_sec": 3600,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/enterprise_backtester.py --replay-trades --apply",
        "downstream": "strategy_backtest_trades, backtest comparison",
    },
    {
        "component": "strategy_backtester",
        "display": "Strategy Backtester (Daily)",
        "schedule": "0 6 * * 1-5",
        "log_file": "strategy_backtester.log",
        "max_age_min": 1500,
        "max_runtime_sec": 1800,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/strategy_backtester.py --all-strategies --apply",
        "downstream": "strategy_backtest_trades, active strategy validation",
    },
    {
        "component": "llm_backtest_reviewer",
        "display": "LLM Backtest Trade Reviewer",
        "schedule": "0 23 * * 0",
        "log_file": "llm_backtest_review.log",
        "max_age_min": 10080,
        "max_runtime_sec": 7200,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/trade_close_llm_analyzer.py --source backtest --limit 50 --apply --confirm-llm-review-write --allow-local-llm",
        "downstream": "trade_llm_reviews, backtest learning",
    },
    # ── YouTube transcript ingest (weekday 19:00) ──
    {
        "component": "youtube_transcript_ingest",
        "display": "YouTube Transcript Ingest",
        "schedule": "0 19 * * 1-5",
        "log_file": "youtube_ingest.log",
        "max_age_min": 1500,
        "max_runtime_sec": 1800,
        "critical": False,
        "retry_cmd": ".venv/bin/python scripts/youtube_transcript_ingest.py --all-channels",
        "downstream": "youtube_transcripts, intelligence_whiteboard, CIO research queue",
    },
]

MAX_RETRIES = 2

# ── safe_flock event log ─────────────────────────────────────────────────────
SAFE_FLOCK_LOG = PROJECT_ROOT / "logs" / "safe_flock_events.jsonl"
SAFE_FLOCK_LOOKBACK_MIN = 30  # window for detecting repeated lock skips

# Components that are critical for repeated-lock-skip escalation
CRITICAL_COMPONENTS = {c["component"] for c in MONITORED_COMPONENTS if c.get("critical")}


def _ingest_safe_flock_events(lookback_min=SAFE_FLOCK_LOOKBACK_MIN):
    """Read recent safe_flock JSONL events. Returns (events, parse_errors)."""
    events = []
    parse_errors = 0
    if not SAFE_FLOCK_LOG.exists():
        return events, parse_errors
    try:
        cutoff = datetime.now(timezone.utc) - timedelta(minutes=lookback_min)
        with open(SAFE_FLOCK_LOG, "r") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    ev = json.loads(line)
                    # Parse timestamp
                    ts_str = ev.get("ts", "")
                    try:
                        ts = datetime.fromisoformat(ts_str)
                        if ts.tzinfo is None:
                            ts = ts.replace(tzinfo=timezone.utc)
                        else:
                            ts = ts.astimezone(timezone.utc)
                    except Exception:
                        ts = None
                    if ts and ts >= cutoff:
                        ev["_parsed_ts"] = ts
                        events.append(ev)
                except (json.JSONDecodeError, ValueError):
                    parse_errors += 1
    except Exception as e:
        log.warning(f"Failed to read safe_flock log: {e}")
    return events, parse_errors


def _last_scheduled_sync_fire(now=None):
    """Most recent time `alpaca_paper_adapter --sync-only` should have run.

    Cron: 0 10-16 * * 1-5 (hourly on the hour, 10:00-16:00 ET, weekdays).
    A grace hour is allowed for run duration and cron jitter, so a position is
    only 'unsynced' if it missed a fire that genuinely should have happened.
    """
    from datetime import timedelta as _td
    from zoneinfo import ZoneInfo as _ZI

    _et = _ZI("America/New_York")
    cur_t = (now or datetime.now(_et)).astimezone(_et)
    probe = cur_t.replace(minute=0, second=0, microsecond=0)
    for _ in range(24 * 10):  # bounded scan back ~10 days
        if probe.weekday() < 5 and 10 <= probe.hour <= 16 and probe <= cur_t:
            return probe - _td(hours=1)  # grace
        probe -= _td(hours=1)
    return cur_t - _td(days=10)


def _analyze_safe_flock(conn, dry_run=True, verbose=False):
    """Analyze safe_flock events and write health events for anomalies.

    Returns summary dict for inclusion in the health report.
    """
    events, parse_errors = _ingest_safe_flock_events()

    summary = {
        "events_seen": len(events),
        "parse_errors": parse_errors,
        "lock_skips": 0,
        "repeated_lock_skips": [],
        "stale_locks_cleared": 0,
        "command_failures": 0,
    }

    # Bucket events by component
    skips_by_component = {}
    for ev in events:
        et = ev.get("event_type", "")
        comp = ev.get("component", "unknown")

        if et == "lock_skip":
            summary["lock_skips"] += 1
            skips_by_component.setdefault(comp, []).append(ev)

        elif et == "stale_lock_cleared":
            summary["stale_locks_cleared"] += 1
            if conn and not dry_run:
                _log_event(
                    conn, comp, "SAFE_FLOCK_STALE_CLEARED", "WARN", ev.get("message", "Stale lock cleared")[:500]
                )

        elif et == "completed":
            exit_code = ev.get("exit_code")
            if exit_code is not None and exit_code != 0:
                summary["command_failures"] += 1
                if conn and not dry_run:
                    _log_event(
                        conn,
                        comp,
                        "SAFE_FLOCK_CMD_FAILED",
                        "WARN",
                        f"Command exited {exit_code}: {ev.get('command', '')[:200]}",
                    )

    # Detect repeated lock skips (2+ in window)
    for comp, skip_list in skips_by_component.items():
        if len(skip_list) >= 2:
            severity = "CRITICAL" if comp in CRITICAL_COMPONENTS else "WARN"
            summary["repeated_lock_skips"].append(
                {
                    "component": comp,
                    "count": len(skip_list),
                    "severity": severity,
                }
            )
            if conn and not dry_run:
                _log_event(
                    conn,
                    comp,
                    "SAFE_FLOCK_REPEATED_SKIP",
                    severity,
                    f"{len(skip_list)} lock skips in {SAFE_FLOCK_LOOKBACK_MIN}min window",
                )

    # Single lock skips (log as INFO)
    for comp, skip_list in skips_by_component.items():
        if len(skip_list) == 1 and conn and not dry_run:
            _log_event(conn, comp, "SAFE_FLOCK_LOCK_SKIP", "INFO", skip_list[0].get("message", "Lock skip")[:500])

    # Repeated parse errors
    if parse_errors >= 5 and conn and not dry_run:
        _log_event(
            conn,
            "safe_flock_parser",
            "SAFE_FLOCK_PARSE_ERRORS",
            "WARN",
            f"{parse_errors} malformed JSONL lines in safe_flock log",
        )

    if verbose:
        log.info(
            f"  safe_flock: {summary['events_seen']} events, "
            f"{summary['lock_skips']} skips, "
            f"{len(summary['repeated_lock_skips'])} repeated, "
            f"{summary['stale_locks_cleared']} stale cleared, "
            f"{summary['command_failures']} cmd failures"
        )

    return summary


def _get_conn():
    try:
        from db_adapter import _get_conn as _gc

        return _gc()
    except Exception:
        return None


def _log_event(conn, component, event_type, severity, message, action=None, success=None):
    try:
        cur = conn.cursor()
        # Source-side dedup: the */5 agent re-emits the same per-component event ~288x/day,
        # which is the SIEM firehose. Log only state CHANGES (and first occurrences) — if the
        # same (event_type, severity) for this component was logged in the last 25 min, skip.
        cur.execute(
            """SELECT event_type, severity FROM system_health_events
                       WHERE component = %s AND created_at > NOW() - INTERVAL '25 minutes'
                       ORDER BY created_at DESC LIMIT 1""",
            [component],
        )
        last = cur.fetchone()
        if last and last[0] == event_type and last[1] == severity:
            conn.commit()  # release the dedup-SELECT txn — leaving it open through a later
            return  # subprocess wait gets the conn idle-in-txn killed at 120s
        cur.execute(
            """INSERT INTO system_health_events
            (component, event_type, severity, message, action_taken, success)
            VALUES (%s, %s, %s, %s, %s, %s)""",
            [
                component,
                event_type,
                severity,
                message[:500] if message else None,
                action[:200] if action else None,
                success,
            ],
        )
        conn.commit()
    except Exception as e:
        log.warning(f"Failed to log event: {e}")


def _send_alert(message, urgent=False, *, dedupe_minutes=None):
    """Send alert through central router. NEVER bypass.

    CRITICAL escalations are P1 intents with dedupe off; WARN escalations are P3, archived for the digest.
    The return value reports intent acceptance; it cannot establish delivery.
    """
    try:
        from telegram_alert import send_telegram

        options = (
            {"dedupe_minutes": 0}
            if urgent
            else ({"dedupe_minutes": dedupe_minutes} if dedupe_minutes is not None else {})
        )
        return send_telegram(message, priority=("P1" if urgent else "P3"), producer="system_health_agent", **options)
    except Exception as e:
        log.error(f"Alert send failed: {e}")
        return False


def _cron_field_matches(field, value, min_val, max_val):
    """Match a single cron field against `value`. Supports '*', lists, ranges and '/steps'."""
    field = field.strip()
    if field in ("*", "?"):
        return True
    for part in field.split(","):
        base, step = part, 1
        if "/" in part:
            base, step_s = part.split("/", 1)
            try:
                step = int(step_s)
            except ValueError:
                step = 1
        if base in ("*", ""):
            lo, hi = min_val, max_val
        elif "-" in base:
            lo_s, hi_s = base.split("-", 1)
            try:
                lo, hi = int(lo_s), int(hi_s)
            except ValueError:
                continue
        else:
            try:
                if int(base) == value:
                    return True
            except ValueError:
                pass
            continue
        if lo <= value <= hi and (value - lo) % step == 0:
            return True
    return False


def _cron_fires_at(schedule, dt):
    """True if 5-field cron `schedule` fires at the minute-resolution datetime `dt`."""
    parts = schedule.split()
    if len(parts) != 5:
        return False
    minute_f, hour_f, dom_f, month_f, dow_f = parts
    if not _cron_field_matches(minute_f, dt.minute, 0, 59):
        return False
    if not _cron_field_matches(hour_f, dt.hour, 0, 23):
        return False
    if not _cron_field_matches(month_f, dt.month, 1, 12):
        return False
    # Python weekday(): Mon=0..Sun=6  ->  cron: Sun=0..Sat=6 (with 7 also = Sun)
    cron_dow = (dt.weekday() + 1) % 7
    dow_ok = _cron_field_matches(dow_f, cron_dow, 0, 6) or (cron_dow == 0 and _cron_field_matches(dow_f, 7, 0, 7))
    dom_ok = _cron_field_matches(dom_f, dt.day, 1, 31)
    # Standard cron rule: when both day-of-month and day-of-week are restricted, either matches.
    if dom_f.strip() != "*" and dow_f.strip() != "*":
        return dom_ok or dow_ok
    return dom_ok and dow_ok


def _weekday_only_schedule(schedule):
    """True if the cron string can never fire on a weekend (dow excludes Sat+Sun).

    These are market-day jobs: their crons are wrapped in market_day_gate.sh (or
    equivalent), so on NYSE holidays they are scheduled-but-skipped by design and
    must not be treated as having a scheduled fire that day.
    """
    parts = schedule.split()
    if len(parts) != 5:
        return False
    dow_f = parts[4]
    return not (
        _cron_field_matches(dow_f, 0, 0, 6)  # Sunday (0)
        or _cron_field_matches(dow_f, 7, 0, 7)  # Sunday (7)
        or _cron_field_matches(dow_f, 6, 0, 6)
    )  # Saturday


def _is_trading_day_cached(dt, _cache={}):
    """market_session.is_trading_day (weekend/NYSE-holiday aware), cached per date.

    Fails OPEN (True = day counts as scheduled) so a broken calendar degrades to the
    old pure-cron behavior instead of silencing staleness detection.
    """
    d = dt.date()
    if d not in _cache:
        try:
            from market_session import is_trading_day

            _cache[d] = bool(is_trading_day(dt))
        except Exception:
            _cache[d] = True
    return _cache[d]


def _prev_scheduled_fire(schedule, now_dt, lookback_days=14):
    """Most recent datetime <= now_dt at which `schedule` would have fired.

    `schedule` may be a single cron string or a list of cron strings (the latest
    fire across all is returned). Returns None if unparseable / no fire in window.

    Trading-calendar aware: weekday-only schedules (dow 1-5) are market-day jobs
    whose crons run under market_day_gate.sh — on NYSE holidays the gate skips them,
    so a holiday is NOT a scheduled fire for those schedules. Without this, the
    2026-07-03 (July-4th observed) skip read as "last fire Friday 16:57" all weekend
    and every gated weekday job paged STALE Sat+Sun despite last output being the
    last real trading day (Thursday). Schedules that can fire on weekends (dow */0/6)
    keep pure cron semantics. Weekday (trading-day) behavior is unchanged.
    """
    schedules = schedule if isinstance(schedule, (list, tuple)) else [schedule]
    schedules = [s for s in schedules if s and len(s.split()) == 5]
    if not schedules:
        return None
    weekday_only = {s: _weekday_only_schedule(s) for s in schedules}
    all_weekday_only = all(weekday_only.values())
    dt = now_dt.replace(second=0, microsecond=0)
    horizon = dt - timedelta(days=lookback_days)
    while dt >= horizon:
        # Fast path: if every schedule is market-day-only and this is not a trading
        # day (weekend/holiday), no fire is possible — skip to the previous day.
        if all_weekday_only and not _is_trading_day_cached(dt):
            dt = dt.replace(hour=23, minute=59) - timedelta(days=1)
            continue
        for s in schedules:
            if _cron_fires_at(s, dt) and (not weekday_only[s] or _is_trading_day_cached(dt)):
                return dt
        dt -= timedelta(minutes=1)
    return None


def _fmt_schedule(schedule):
    """Human-readable form of a schedule that may be a string or list of cron strings."""
    if isinstance(schedule, (list, tuple)):
        return " | ".join(schedule)
    return schedule


def _check_log_freshness(log_file, max_age_min, prev_fire=None, now=None, grace_min=15):
    """Check if log file has recent output.

    When `prev_fire` (the most recent scheduled run time) is supplied, staleness is
    judged against the schedule rather than a blind elapsed-time threshold: the job is
    STALE only if its last output predates the most recent scheduled run (after a grace
    period for that run to complete). This eliminates false positives on days/hours the
    job is not scheduled to run (e.g. weekday-only jobs flagged STALE on weekends).
    Falls back to the fixed `max_age_min` threshold when no schedule context is given.
    """
    log_path = _resolve_log(log_file)
    from lib.system_health_freshness import freshness_at

    state_root = Path(os.getenv("TRADEAI_STATE_ROOT") or str(PROJECT_ROOT.parent.parent / "persistent-state"))
    state_log = state_root / "logs" / log_file
    metadata = {
        "signal_kind": "LOG_ACTIVITY",
        "signal_path": str(log_path),
        "business_output_acceptance": "NOT_MEASURED",
        "signal_source": "governed_state" if log_path == state_log else "legacy_code_fallback",
        "source_drift": None if log_path == state_log else "governed_log_absent_legacy_fallback",
    }
    if not log_path.exists():
        return dict(metadata, status="MISSING", age_min=None, last_line=None, reason="log_missing")
    try:
        mtime = datetime.fromtimestamp(log_path.stat().st_mtime, tz=timezone.utc)
        last_line = ""
        with open(log_path, "rb") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - 500))
            last_line = f.read().decode("utf-8", errors="replace").strip().split("\n")[-1][:200]

        # Capture the default observation after the read, so a concurrent append
        # cannot acquire a timestamp a few milliseconds beyond our own clock.
        observed = now or datetime.now(timezone.utc)
        result = freshness_at(mtime, now=observed, max_age_min=max_age_min, prev_fire=prev_fire, grace_min=grace_min)
        if "success_at" in result:
            result["activity_at"] = result.pop("success_at")
        return dict(metadata, **result, last_line=last_line)
    except Exception as e:
        return dict(metadata, status="ERROR", age_min=None, last_line=type(e).__name__, reason="log_unreadable")


def _check_component_freshness(comp, *, now=None, prev_fire=None, grace_min=15):
    """Prefer a declared successful-run receipt; failures never fall back to logs."""
    lane_id = comp.get("receipt_lane_id")
    if not lane_id:
        return _check_log_freshness(
            comp.get("log_file", ""), comp.get("max_age_min", 60), prev_fire=prev_fire, now=now, grace_min=grace_min
        )
    from lib.lane_last_receipt import receipt_path
    from lib.system_health_freshness import lane_receipt_freshness

    path = receipt_path(lane_id)
    metadata = {
        "signal_kind": "LaneRunReceipt@v1",
        "signal_source": "governed_state",
        "signal_path": str(path),
        "business_output_acceptance": "NOT_MEASURED",
        "last_line": None,
    }
    try:
        doc = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return dict(metadata, status="MISSING", age_min=None, reason="lane_receipt_missing")
    except (OSError, ValueError):
        return dict(metadata, status="ERROR", age_min=None, reason="lane_receipt_unreadable")
    observed = now or datetime.now(timezone.utc)
    result = lane_receipt_freshness(
        doc,
        lane_id=lane_id,
        script=comp["receipt_script"],
        now=observed,
        max_age_min=comp.get("max_age_min", 60),
        prev_fire=prev_fire,
        grace_min=grace_min,
    )
    return dict(metadata, **result)


def _component_schedule_intent(comp):
    """Source intent is drift context, never proof of host scheduler installation."""
    from lib.system_health_freshness import schedule_intent

    try:
        registry = json.loads((PROJECT_ROOT / "config" / "lane_registry.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        registry = None
    return schedule_intent(comp, registry)


def check_youtube_transcript_freshness(
    conn=None, *, now=None, max_db_age_hours: float = 36.0, log_file: str = "youtube_ingest.log"
):
    """YouTube transcripts freshness: log mtime + optional DB latest ingest / daily count.

    Returns status CURRENT / STALE / MISSING with a clear reason. Pure enough for unit tests
    when conn/log path are mocked. Does not invent data.
    """
    now = now or datetime.now(timezone.utc)
    log_path = _resolve_log(log_file)
    result = {
        "component": "youtube_transcripts",
        "status": "MISSING",
        "reason": "",
        "latest_ingest_at": None,
        "daily_ingested_count": None,
        "log_age_hours": None,
        "db_age_hours": None,
    }

    log_mtime = None
    if log_path.exists():
        try:
            log_mtime = datetime.fromtimestamp(log_path.stat().st_mtime, tz=timezone.utc)
            result["log_age_hours"] = round((now - log_mtime).total_seconds() / 3600, 2)
        except Exception as e:
            result["reason"] = f"log_stat_error: {e}"
    else:
        result["reason"] = f"log_missing:{log_file}"

    latest = None
    daily_count = None
    if conn is not None:
        try:
            cur = conn.cursor()
            cur.execute("SELECT MAX(ingested_at) FROM youtube_transcripts")
            row = cur.fetchone()
            latest = row[0] if row else None
            cur.execute("SELECT COUNT(*) FROM youtube_transcripts WHERE ingested_at::date = CURRENT_DATE")
            crow = cur.fetchone()
            daily_count = int(crow[0] or 0) if crow else 0
        except Exception as e:
            # DB optional for log-only judgment
            if not result["reason"]:
                result["reason"] = f"db_query_error: {e}"

    if latest is not None:
        if getattr(latest, "tzinfo", None) is None:
            latest = latest.replace(tzinfo=timezone.utc)
        result["latest_ingest_at"] = latest.isoformat()
        result["db_age_hours"] = round((now - latest).total_seconds() / 3600, 2)
    result["daily_ingested_count"] = daily_count

    # Prefer DB age when available; else log age; else MISSING.
    if result["db_age_hours"] is not None:
        if result["db_age_hours"] <= max_db_age_hours:
            result["status"] = "CURRENT"
            result["reason"] = (
                f"latest_ingest {result['db_age_hours']}h ago; "
                f"today_count={daily_count if daily_count is not None else 'n/a'}"
            )
        else:
            result["status"] = "STALE"
            result["reason"] = (
                f"latest_ingest {result['db_age_hours']}h ago "
                f"(threshold {max_db_age_hours}h); today_count={daily_count}"
            )
    elif result["log_age_hours"] is not None:
        # Weekday ingest ~24h cadence; treat >36h log silence as STALE
        if result["log_age_hours"] <= max_db_age_hours:
            result["status"] = "CURRENT"
            result["reason"] = f"log fresh ({result['log_age_hours']}h); DB unavailable"
        else:
            result["status"] = "STALE"
            result["reason"] = f"log stale ({result['log_age_hours']}h); DB unavailable"
    else:
        result["status"] = "MISSING"
        if not result["reason"]:
            result["reason"] = "no youtube_ingest.log and no youtube_transcripts rows"

    return result


def _check_lock_contention(lock_file):
    """Check if a lock file exists and if the holding process is alive."""
    if not lock_file:
        return {"status": "NO_LOCK", "pid": None, "alive": None}
    pid_file = f"{lock_file}.pid"
    if not os.path.exists(pid_file):
        return {"status": "FREE", "pid": None, "alive": None}
    try:
        pid = int(open(pid_file).read().strip())
        alive = os.path.exists(f"/proc/{pid}")
        if alive:
            # Check how long it's been running
            try:
                stat = os.stat(f"/proc/{pid}")
                start_time = datetime.fromtimestamp(stat.st_ctime, tz=timezone.utc)
                runtime = (datetime.now(timezone.utc) - start_time).total_seconds()
                return {"status": "LOCKED", "pid": pid, "alive": True, "runtime_sec": round(runtime)}
            except Exception:
                return {"status": "LOCKED", "pid": pid, "alive": True}
        else:
            return {"status": "STALE_LOCK", "pid": pid, "alive": False}
    except Exception:
        return {"status": "UNKNOWN", "pid": None, "alive": None}


def _check_output_validity(component, log_file, error_signatures=None, success_signatures=None):
    """Check if the last run produced meaningful output (not just errors).

    error_signatures: component-declared substrings that mean the run FAILED even if it exited 0 with
    structurally-valid output (e.g. Schwab `invalid_grant` / `no Schwab login token` — a clean JSON
    failure the generic Traceback/ERROR heuristics miss). This closes the "log is fresh so it's OK"
    blind spot for API-dependent crons that can run-and-fail silently.
    success_signatures: markers of a good run; a failure signature is only honored when it is MORE RECENT
    than the last success marker, so a stale error earlier in the log window doesn't flag a run that has
    since recovered."""
    log_path = _resolve_log(log_file)
    if not log_path.exists():
        return {"valid": False, "reason": "log_missing"}
    try:
        with open(log_path, "rb") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - 4000))
            tail = f.read().decode("utf-8", errors="replace")
        # Component-declared failure signatures FIRST — catches semantic failures that exit 0 with
        # valid-looking output (no Traceback, low ERROR count). Recency-gated by success markers.
        _last_ok = max((tail.rfind(s) for s in (success_signatures or [])), default=-1)
        for sig in error_signatures or []:
            pos = tail.rfind(sig)
            if pos >= 0 and pos > _last_ok:
                return {"valid": False, "reason": f"error_signature:{sig[:40]}"}
        # Check for common failure patterns
        if "Usage:" in tail and "error:" in tail.lower():
            return {"valid": False, "reason": "usage_error_likely_misconfigured"}
        if "Traceback" in tail and "Error" in tail:
            return {"valid": False, "reason": "python_exception"}
        if tail.count("ERROR") > 5:
            return {"valid": False, "reason": "excessive_errors"}
        return {"valid": True, "reason": "ok"}
    except Exception:
        return {"valid": False, "reason": "read_error"}


_RETRY_DISARMED_LOGGED: set = set()


def _retry_armed() -> bool:
    return os.environ.get("TRADEAI_HEALTH_AGENT_RETRY", "0") == "1"


def _health_retry_history(path, now):
    """UNINITIALIZED: no reviewed complete host-history source is installed.

    Legacy PG events are deduplicated and cannot establish complete attempt history. Neither a file,
    environment flag nor a caller-supplied initialized boolean creates this missing provenance.
    """
    return None


def _attempt_retry(comp, conn, *, attempt_state=None):
    """Attempt a retry. True means process exit zero, never accepted business recovery."""
    if attempt_state is not None:
        attempt_state.update(attempted=False, budget_status="not_evaluated")
    cmd = comp.get("retry_cmd")
    if not cmd:
        return False
    component = comp["component"]
    # 2026-10-08: every retry_cmd began with .venv/bin/python, which the served tree does not have, so
    # every retry since the crons-to-CURRENT migration exited 127 (system_health_events RETRY rows:
    # "/bin/sh: 1: .venv/bin/python: not found"). The interpreter is the one this agent runs under.
    # Arming ~20 retry commands (several launch senders or daemons) is an operator decision, so the
    # path stays DISARMED unless TRADEAI_HEALTH_AGENT_RETRY=1.
    if cmd.startswith(".venv/bin/python"):
        cmd = sys.executable + cmd[len(".venv/bin/python") :]
    if not _retry_armed():
        if component not in _RETRY_DISARMED_LOGGED:
            _RETRY_DISARMED_LOGGED.add(component)
            log.info(f"[retry] {component} — RETRY_DISARMED (set TRADEAI_HEALTH_AGENT_RETRY=1 to arm): {cmd[:80]}")
        return False

    import hashlib
    import math
    import time
    from lib import recovery_attempt_budget as budget

    def hold(reason):
        if attempt_state is not None:
            attempt_state["budget_status"] = reason
        _log_event(conn, component, "RETRY_BUDGET_HELD", "WARN", reason, success=False)
        return False

    # Include contention and DB inspection in this attempt's absolute process deadline.
    timeout_s = comp.get("max_runtime_sec", 300)
    if (type(MAX_RETRIES) is not int or MAX_RETRIES < 0 or type(timeout_s) not in (int, float)
            or not math.isfinite(timeout_s) or timeout_s <= 0):
        return hold("unavailable")
    deadline = time.monotonic() + timeout_s
    retries_today = 0
    try:
        cur = conn.cursor()
        cur.execute(
            """SELECT COUNT(*) FROM system_health_events
            WHERE component=%s AND event_type IN ('RETRY', 'RETRY_TIMEOUT', 'RETRY_ERROR')
            AND created_at > NOW() - INTERVAL '24 hours'""",
            [component],
        )
        retries_today = cur.fetchone()[0]
        conn.commit()  # never retain an idle read transaction through a subprocess
        if type(retries_today) is not int or retries_today < 0:
            return hold("unavailable")
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        return hold("unavailable")

    state_root = Path(os.environ.get("TRADEAI_STATE_ROOT") or
                      (Path.home() / "trade-ai-releases" / "persistent-state"))
    journal = state_root / "data/runtime/health_retry_attempts.jsonl"
    reservation = {
        "schema": "HealthRetryAttempt@v1", "namespace": budget.HEALTH, "component": component,
        "ts": datetime.now(timezone.utc).isoformat(),
        "command_digest": hashlib.sha256(cmd.encode("utf-8")).hexdigest(),
    }
    allowed, status = budget.reserve(
        journal, reservation, datetime.now(timezone.utc), limit=MAX_RETRIES, window_s=86400,
        namespace=budget.HEALTH, live=True, history_source=_health_retry_history,
        deadline=deadline, observed_count=retries_today,
    )
    if not allowed:
        return hold("exhausted" if status == "known" else status)
    if attempt_state is not None:
        attempt_state.update(budget_status="known", attempt_id=reservation["attempt_id"])
    # Reservation is irrevocable, including a crash or deadline expiry before spawn.
    if time.monotonic() >= deadline:
        return hold("deadline_exhausted")

    # Clear stale lock ONLY when the PID is genuinely dead. (Do NOT pre-clear before running — that
    # defeated the lock and let every cycle spawn another heavy orchestrator: the 2026-06-25 pile-up
    # of 3+ concurrent trade_ai_orchestrator --run-label 0900 runs that starved the single-threaded
    # API server.)
    lock_file = comp.get("lock_file")
    if lock_file:
        lock_info = _check_lock_contention(lock_file)
        if lock_info["status"] == "STALE_LOCK":
            try:
                os.remove(f"{lock_file}.pid")
                _log_event(
                    conn,
                    component,
                    "LOCK_CLEARED",
                    "WARN",
                    f"Cleared stale lock {lock_file} (dead PID {lock_info['pid']})",
                    action="rm stale .pid",
                    success=True,
                )
            except Exception:
                pass

    # SINGLE-FLIGHT the retry through the SAME safe_flock.sh the cron uses, so a remediation can never
    # stack on the cron run or on a prior still-running remediation. If the lock is held, safe_flock
    # exits without running — exactly what we want (it's already running; don't pile on).
    run_cmd = cmd
    if lock_file:
        run_cmd = f"bash {PROJECT_ROOT}/scripts/safe_flock.sh {lock_file} {cmd}"

    log.info(f"[retry] {component} — attempt {retries_today + 1}/{MAX_RETRIES}")
    proc = None
    try:
        # new session so a timeout kills the WHOLE tree (heavy orchestrator child included), not just
        # the shell — the old subprocess.run(timeout) orphaned the python child to keep loading the host.
        if time.monotonic() >= deadline:
            return hold("deadline_exhausted")
        if attempt_state is not None:
            attempt_state["attempted"] = True
        proc = subprocess.Popen(
            run_cmd,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd=str(PROJECT_ROOT),
            start_new_session=True,
        )
        try:
            out, err = proc.communicate(timeout=max(0, deadline - time.monotonic()))
        except subprocess.TimeoutExpired:
            try:
                import signal as _sig

                pgid = os.getpgid(proc.pid)
                os.killpg(pgid, _sig.SIGTERM)
                try:
                    proc.communicate(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(pgid, _sig.SIGKILL)
                    proc.communicate(timeout=5)
            except Exception:
                pass
            _log_event(
                conn,
                component,
                "RETRY_TIMEOUT",
                "WARN",
                f"Retry timed out after {timeout_s}s — process group killed",
                action=cmd[:100],
                success=False,
            )
            return False
        success = proc.returncode == 0
        _log_event(
            conn,
            component,
            "RETRY",
            "INFO" if success else "WARN",
            f"exit={proc.returncode} stdout={(out or '')[-200:]}"
            if success
            else f"exit={proc.returncode} stderr={(err or '')[-200:]}",
            action=cmd[:100],
            success=success,
        )
        return success
    except Exception as e:
        _log_event(conn, component, "RETRY_ERROR", "WARN", str(e)[:200], action=cmd[:100], success=False)
        return False


def _retry_recovery_evidence(comp, since):
    """Read the latest host-ledger result for an existing explicit receipt-lane binding.

    Log freshness, v1 last-success files, stdout and monitor_lane_ids (schedule display) never establish
    useful-output recovery. No mapping is inferred and no receipt is manufactured for the legacy retry.
    """
    import sqlite3

    if str(PROJECT_ROOT) not in sys.path:
        sys.path.insert(0, str(PROJECT_ROOT))
    from scripts.lib import recovery_validator as RV

    lane = comp.get("receipt_lane_id")
    result = {"recovered": False, "validator": RV.SCHEMA, "reason": "recovery_lane_binding_unavailable"}
    if not isinstance(lane, str) or not lane:
        return result
    root = Path(os.environ.get("TRADEAI_STATE_ROOT") or (Path.home() / "trade-ai-releases" / "persistent-state"))
    path = Path(
        os.environ.get("TRADEAI_N8N_COORDINATION_LEDGER") or root / "data/governance/n8n_coordination_ledger.sqlite"
    )
    try:
        conn = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True, timeout=3)
        try:
            conn.row_factory = sqlite3.Row
            row = conn.execute(
                "SELECT * FROM runs WHERE lane_id=? AND finished_at IS NOT NULL ORDER BY finished_at DESC LIMIT 1",
                (lane,),
            ).fetchone()
        finally:
            conn.close()
    except (OSError, ValueError, sqlite3.Error) as exc:
        return dict(result, reason="recovery_ledger_unavailable:" + type(exc).__name__)
    row = dict(row) if row is not None else None
    ok, reason = RV.validate(row, mode="live", lane=lane, since=since, now=datetime.now(timezone.utc))
    return dict(
        result,
        recovered=ok,
        reason=reason,
        lane_id=lane,
        run_id=row.get("run_id") if row else None,
        attempt=row.get("attempt") if row else None,
    )


def _is_portfolio_market_hours(now_et) -> bool:
    """Weekday 9:30 AM – 4:00 PM ET — when intraday Finviz repricing must be live."""
    if now_et.weekday() >= 5:
        return False
    mins = now_et.hour * 60 + now_et.minute
    return 570 <= mins <= 960


def _parse_et_timestamp(ts_str: str):
    """Parse 'YYYY-MM-DD HH:MM:SS ET' (or ISO) to aware UTC datetime."""
    if not ts_str:
        return None
    s = str(ts_str).strip().replace(" ET", "").replace("ET", "").strip()
    # Preserve an explicit offset when the source supplies one.
    try:
        _iso = datetime.fromisoformat(s)
        if _iso.tzinfo is not None:
            return _iso.astimezone(timezone.utc)
    except ValueError:
        pass
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
        try:
            naive = datetime.strptime(s[:19], fmt)
            try:
                import pytz as _ptz_et

                return _ptz_et.timezone("US/Eastern").localize(naive).astimezone(timezone.utc)
            except ModuleNotFoundError:
                # Keep the pure health parser usable in minimal QA/bootstrap
                # environments while preserving ET daylight-saving semantics.
                from zoneinfo import ZoneInfo

                return naive.replace(tzinfo=ZoneInfo("America/New_York")).astimezone(timezone.utc)
        except ValueError:
            continue
    return None


def _portfolio_price_freshness_alerts(now_et, max_age_min: float = 25.0) -> list[str]:
    """Finviz cache + holdings repriced timestamps — authoritative portfolio quote layer."""
    if not _is_portfolio_market_hours(now_et):
        return []
    alerts = []
    state_dir = PROJECT_ROOT / "data" / "portfolios" / "state"
    now_utc = datetime.now(timezone.utc)

    # finviz_quote_cache.json _meta.last_fetched
    cache_path = state_dir / "finviz_quote_cache.json"
    if cache_path.exists():
        try:
            cache = json.loads(cache_path.read_text(encoding="utf-8"))
            meta = cache.get("_meta") or {}
            lf = _parse_et_timestamp(meta.get("last_fetched") or meta.get("last_updated") or "")
            if lf:
                age = (now_utc - lf).total_seconds() / 60.0
                if age > max_age_min:
                    alerts.append(
                        f"🚨 Finviz quote cache stale {age:.0f}m (>{max_age_min:.0f}m) — "
                        f"portfolio cards may show wrong P/L"
                    )
            else:
                alerts.append("⚠️ Finviz quote cache missing last_fetched timestamp")
        except Exception as e:
            alerts.append(f"⚠️ Finviz quote cache unreadable: {str(e)[:80]}")
    else:
        alerts.append("🚨 finviz_quote_cache.json missing")

    # holdings.json last_repriced (not file mtime — SnapTrade sync can mask staleness)
    holdings_path = state_dir / "holdings.json"
    if holdings_path.exists():
        try:
            hp = json.loads(holdings_path.read_text(encoding="utf-8"))
            lr = _parse_et_timestamp(hp.get("last_repriced") or "")
            if lr:
                age = (now_utc - lr).total_seconds() / 60.0
                if age > max_age_min:
                    alerts.append(
                        f"🚨 Portfolio last_repriced stale {age:.0f}m (>{max_age_min:.0f}m) — run portfolio_repricer.py"
                    )
            else:
                alerts.append("⚠️ holdings.json missing last_repriced")
        except Exception as e:
            alerts.append(f"⚠️ holdings.json repriced check failed: {str(e)[:80]}")

    return alerts


def evaluate_broker_snapshot(
    snapshot: dict,
    *,
    now: datetime | None = None,
    max_age_min: float = 15.0,
    share_tolerance: float = 1e-6,
    cash_tolerance: float = 0.01,
) -> dict:
    """Validate broker freshness semantically, independent of file mtime/log age.

    A successful repricer log is not evidence that broker positions are current.  This
    pure check is intentionally conservative: missing broker timestamps or a dry-run
    sync are blocked rather than interpreted as healthy.
    """
    now = now or datetime.now(timezone.utc)
    rows = snapshot.get("holdings") or []
    reasons: list[str] = []
    ages: list[float] = []
    reconciliation: list[dict] = []
    for row in rows:
        if row.get("is_cash") and not row.get("broker_position_as_of"):
            continue
        raw = row.get("broker_position_as_of") or row.get("broker_ingested_at")
        parsed = _parse_et_timestamp(raw) if raw else None
        if parsed is None:
            reasons.append(f"missing_broker_timestamp:{row.get('symbol') or 'unknown'}")
            continue
        ages.append(max(0.0, (now - parsed).total_seconds() / 60.0))

        # Broker sync deliberately stamps broker_actual_shares even when the
        # operational share count remains sticky pending operator review.  A
        # material difference must therefore be visible to health consumers and
        # must not be mistaken for a current, reconciled snapshot.
        broker_qty = row.get("broker_actual_shares")
        system_qty = row.get("shares")
        if broker_qty is not None and system_qty is not None:
            try:
                drift = float(broker_qty) - float(system_qty)
                if abs(drift) > share_tolerance:
                    reconciliation.append(
                        {
                            "symbol": row.get("symbol") or "unknown",
                            "account": row.get("account") or row.get("account_id"),
                            "field": "shares",
                            "broker": float(broker_qty),
                            "system": float(system_qty),
                            "difference": drift,
                        }
                    )
            except (TypeError, ValueError):
                reasons.append(f"invalid_share_reconciliation:{row.get('symbol') or 'unknown'}")

    # Optional account-level cash fields are emitted by applied broker snapshot
    # producers.  Do not infer cash from market value or rebalance notional.
    broker_cash = snapshot.get("broker_cash")
    system_cash = snapshot.get("cash_total")
    if broker_cash is not None and system_cash is not None:
        try:
            cash_drift = float(broker_cash) - float(system_cash)
            if abs(cash_drift) > cash_tolerance:
                reconciliation.append(
                    {
                        "field": "cash_total",
                        "broker": float(broker_cash),
                        "system": float(system_cash),
                        "difference": cash_drift,
                    }
                )
        except (TypeError, ValueError):
            reasons.append("invalid_cash_reconciliation")
    if reconciliation:
        reasons.append("broker_system_mismatch")
    sync_mode = str(snapshot.get("sync_mode") or "").upper()
    if sync_mode in {"DRY_RUN", "PREVIEW"}:
        reasons.append("sync_not_applied")
    if not rows:
        reasons.append("no_holdings")
    if ages and max(ages) > max_age_min:
        reasons.append(f"broker_positions_stale:{max(ages):.1f}m")
    status = "CURRENT" if not reasons else "STALE_PORTFOLIO"
    return {
        "status": status,
        "ok": status == "CURRENT",
        "max_age_min": max(ages, default=None),
        "reasons": reasons,
        "snapshot_id": snapshot.get("portfolio_snapshot_id"),
        "reconciliation": reconciliation,
        "data_quality": "CURRENT" if status == "CURRENT" else "DEGRADED",
    }


def _escalate(comp, check_result, conn):
    """Escalate a failure to operator via central alert router.

    Dedup windows (host Telegram flood control, 2026-10-13 diligence):
    - default: max 1 ESCALATION per component per 2 hours
    - retry_disarmed*: 12 hours — autoheal is grant-gated; 5-min STALE rechecks must not
      re-page Finviz/orchestrator/proposals every cycle while retry stays disarmed
    """
    component = comp["component"]
    severity = "CRITICAL" if comp.get("critical") else "WARN"
    action = str(check_result.get("action_taken") or "")
    # Disarmed autoheal is an operator decision, not a new failure each poll.
    dedupe_hours = 12 if action.startswith("retry_disarmed") else 2

    # Dedup: don't spam same escalation within the window
    try:
        cur = conn.cursor()
        cur.execute(
            """SELECT COUNT(*) FROM system_health_events
            WHERE component=%s AND event_type='ESCALATION'
            AND success IS TRUE
            AND created_at > NOW() - (%s || ' hours')::interval""",
            [component, str(dedupe_hours)],
        )
        if (cur.fetchone()[0] or 0) > 0:
            _log_event(
                conn,
                component,
                "ESCALATION_DEDUPED",
                severity,
                f"Suppressed duplicate escalation ({dedupe_hours}h window"
                + ("; retry_disarmed" if dedupe_hours == 12 else "")
                + ")",
                success=True,
            )
            return
    except Exception:
        pass

    msg_lines = [
        f"{'🚨' if severity == 'CRITICAL' else '⚠️'} SYSTEM HEALTH: {comp['display']} — {check_result['status']}",
        "",
        f"Component: {component}",
        f"Expected: {_fmt_schedule(comp.get('schedule', 'unknown'))}",
        f"Last observed output: {(check_result.get('freshness_evidence') or {}).get('success_at') or 'NOT_MEASURED'}",
        f"Status: {check_result['status']}",
    ]
    if check_result.get("last_error"):
        msg_lines.append(f"Error: {check_result['last_error'][:150]}")
    if comp.get("downstream"):
        msg_lines.append(f"Impact: {comp['downstream']}")
    if check_result.get("action_taken"):
        msg_lines.append(f"Action: {check_result['action_taken']}")
    # Add actionable fix instruction
    if comp.get("retry_cmd"):
        msg_lines.append(f"Fix: {comp['retry_cmd'][:100]}")
    else:
        msg_lines.append("Fix: Check logs and restart manually")

    msg = "\n".join(msg_lines)
    # Stable content supports bounded informational dedupe when the diagnostic DB
    # is unavailable. P1 keeps dedupe off; the producer ledger bounds accepted repeats.
    accepted = bool(_send_alert(msg, urgent=(severity == "CRITICAL"), dedupe_minutes=120))
    _log_event(
        conn,
        component,
        "ESCALATION" if accepted else "ESCALATION_REJECTED",
        severity,
        msg[:500],
        action="notification_intent",
        success=accepted,
    )


def run_health_check(dry_run=True, verbose=False):
    """Run all health checks. Returns full report."""
    conn = _get_conn()
    if not conn:
        log.error("No DB connection")
        return {"error": "no_db"}

    now = datetime.now(timezone.utc)
    report = {
        "timestamp": now.isoformat(),
        "mode": "dry_run" if dry_run else "active",
        "checks": [],
        "summary": {
            "ok": 0,
            "stale": 0,
            "missing": 0,
            "failed": 0,
            "locked": 0,
            "retried": 0,
            "retry_disarmed": 0,
            "escalated": 0,
        },
    }

    # Semantic broker freshness is separate from log/file freshness.  Missing local
    # state is reported as unavailable; it must not become a healthy empty state.
    try:
        _state_path = PROJECT_ROOT / "data" / "portfolios" / "state" / "holdings.json"
        if _state_path.exists():
            report["broker_snapshot_health"] = evaluate_broker_snapshot(
                json.loads(_state_path.read_text(encoding="utf-8")), now=now
            )
        else:
            report["broker_snapshot_health"] = {
                "status": "UNAVAILABLE",
                "ok": False,
                "reasons": ["holdings_snapshot_missing"],
                "snapshot_id": None,
            }
    except Exception as exc:
        report["broker_snapshot_health"] = {
            "status": "INVALID_SCHEMA",
            "ok": False,
            "reasons": [f"holdings_snapshot_unreadable:{type(exc).__name__}"],
            "snapshot_id": None,
        }

    # Determine if we're in market hours (ET)
    import pytz as _ptz

    _et = _ptz.timezone("US/Eastern")
    _now_et = now.astimezone(_et)
    _current_hour = _now_et.hour
    _is_weekday = _now_et.weekday() < 5

    for comp in MONITORED_COMPONENTS:
        if comp.get("retired"):
            continue  # a disabled lane is neither checked nor retried
        if conn is None or getattr(conn, "closed", 0):
            # db_adapter hands out one shared connection; another helper may have closed and
            # replaced it mid-run (2026-10-07: "Failed to log event: connection already closed"
            # from the aegis check onward, then the retry crashed). Re-fetch, never run blind.
            conn = _get_conn()
            if conn is None:
                log.error("DB connection lost mid-run and could not be re-established")
                report["error"] = "db_lost"
                break
        component = comp["component"]
        log_file = comp.get("log_file", "")

        # Schedule-aware staleness: judge freshness against the component's actual cron
        # schedule (day-of-week + hours), not a blind elapsed-time threshold. This is what
        # prevents weekday-only jobs (1-5) from being flagged STALE on weekends, and jobs
        # from being flagged before their first scheduled run of the day.
        _sched = comp.get("schedule", "")
        _prev_fire = None
        if _sched and _sched != "event-driven":
            _prev_fire = _prev_scheduled_fire(_sched, _now_et)
        _grace_min = max(comp.get("max_runtime_sec", 600) / 60.0, 5) + 10

        # 1. Check log freshness (schedule-aware when a scheduled fire time is known)
        freshness = _check_component_freshness(comp, prev_fire=_prev_fire, grace_min=_grace_min)

        # 2. Check lock contention
        lock_info = _check_lock_contention(comp.get("lock_file"))

        # 3. Check output validity
        output_check = (
            {"valid": freshness["status"] == "OK", "reason": freshness.get("reason", "")}
            if comp.get("receipt_lane_id")
            else _check_output_validity(
                component, log_file, comp.get("error_signatures"), comp.get("success_signatures")
            )
        )

        # Build check result
        check = {
            "component": component,
            "display": comp.get("display", component),
            "critical": comp.get("critical", False),
            "schedule": comp.get("schedule", ""),
            "status": freshness["status"],
            "age_min": freshness.get("age_min"),
            "last_line": (freshness.get("last_line") or "")[:100],
            "lock": lock_info["status"],
            "lock_pid": lock_info.get("pid"),
            "lock_runtime": lock_info.get("runtime_sec"),
            "output_valid": output_check.get("valid", True),
            "output_reason": output_check.get("reason", ""),
            "downstream": comp.get("downstream", ""),
            "action_taken": None,
            "last_error": None,
            "freshness_evidence": freshness,
            "recovery_reason": None,
            "schedule_evidence": _component_schedule_intent(comp),
        }

        # 4. Determine action
        needs_action = False
        if freshness["status"] in ("STALE", "MISSING"):
            needs_action = True
            report["summary"]["stale" if freshness["status"] == "STALE" else "missing"] += 1
        elif not output_check.get("valid", True):
            needs_action = True
            check["status"] = "OUTPUT_INVALID"
            check["last_error"] = output_check.get("reason", "unknown")
            report["summary"]["failed"] += 1
        elif freshness["status"] == "ERROR":
            needs_action = True
            check["last_error"] = freshness.get("reason", "freshness_error")
            report["summary"]["failed"] += 1
        elif lock_info["status"] == "STALE_LOCK":
            needs_action = True
            check["status"] = "STALE_LOCK"
            report["summary"]["locked"] += 1
        elif lock_info["status"] == "LOCKED" and lock_info.get("runtime_sec", 0) > comp.get("max_runtime_sec", 600):
            needs_action = True
            check["status"] = "LOCK_TIMEOUT"
            check["last_error"] = (
                f"Process {lock_info['pid']} running {lock_info['runtime_sec']}s (max {comp.get('max_runtime_sec')}s)"
            )
            report["summary"]["locked"] += 1
        else:
            report["summary"]["ok"] += 1

        # 5. Self-heal
        if needs_action and not dry_run:
            # Try retry first
            if comp.get("retry_cmd") and not _retry_armed():
                # 2026-10-09: a disarmed retry is not a retry. The summary said "5 retried" on every run
                # while _attempt_retry returned at RETRY_DISARMED without running anything.
                check["action_taken"] = "retry_disarmed"
                check["recovery_reason"] = "operator_retry_not_armed: TRADEAI_HEALTH_AGENT_RETRY requires explicit 1"
                report["summary"]["retry_disarmed"] += 1
                if comp.get("critical"):
                    _escalate(comp, check, conn)
                    check["action_taken"] = "retry_disarmed_escalated"
                    report["summary"]["escalated"] += 1
            elif comp.get("retry_cmd"):
                retry_started = datetime.now(timezone.utc)
                attempt_state = {}
                success = _attempt_retry(comp, conn, attempt_state=attempt_state)
                attempted = attempt_state.get("attempted") is True
                check["retry_admission"] = attempt_state
                check["action_taken"] = ("retry_success" if success else "retry_failed") if attempted else "retry_held"
                report["summary"]["retried"] += int(attempted)
                if not attempted:
                    report["summary"]["retry_held"] = report["summary"].get("retry_held", 0) + 1
                proof = (
                    _retry_recovery_evidence(comp, retry_started)
                    if success
                    else {"recovered": False, "reason": "retry_process_failed" if attempted
                          else "retry_budget_" + attempt_state.get("budget_status", "unavailable")}
                )
                check["recovery_evidence"] = proof
                check["recovery_reason"] = proof["reason"]
                if proof["recovered"]:
                    check["status"] = "RECOVERED"
                    _log_event(
                        conn,
                        component,
                        "RECOVERED",
                        "INFO",
                        "Fresh effective-live business output verified after retry started: "
                        + str(proof.get("run_id")),
                        action=comp["retry_cmd"][:100],
                        success=True,
                    )
                else:
                    if success:
                        check["action_taken"] = "retry_completed_unproven"
                    # Escalate
                    if comp.get("critical"):
                        _escalate(comp, check, conn)
                        check["action_taken"] = (
                            "retry_completed_unproven_escalated" if success else
                            "retry_failed_escalated" if attempted else "retry_held_escalated"
                        )
                        report["summary"]["escalated"] += 1
            elif comp.get("critical"):
                # No retry cmd but critical — escalate immediately
                _escalate(comp, check, conn)
                check["action_taken"] = "escalated_no_retry"
                report["summary"]["escalated"] += 1

        # 6. Persist check result
        try:
            cur = conn.cursor()
            cur.execute(
                """INSERT INTO system_health_checks
                (check_type, component, status, expected_schedule, last_success_at,
                 last_failure_at, last_run_duration_sec, expected_max_duration_sec,
                 failure_count, retry_count, last_error, last_action, downstream_impact, severity)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                [
                    "cron_health",
                    component,
                    check["status"],
                    _fmt_schedule(comp.get("schedule")),
                    now if check["status"] == "OK" else None,
                    now if check["status"] not in ("OK", "RECOVERED") else None,
                    None,
                    comp.get("max_runtime_sec"),
                    1 if check["status"] not in ("OK", "RECOVERED") else 0,
                    1 if (check.get("action_taken") or "").startswith("retry") else 0,
                    check.get("last_error"),
                    check.get("action_taken"),
                    comp.get("downstream"),
                    "CRITICAL" if comp.get("critical") and needs_action else "INFO",
                ],
            )
            conn.commit()
        except Exception as e:
            log.warning(f"Failed to persist check for {component}: {e}")

        if verbose:
            icon = "✅" if check["status"] == "OK" else "🔄" if check["status"] == "RECOVERED" else "❌"
            log.info(
                f"  {icon} {comp['display']:30s} status={check['status']:15s} age={check.get('age_min', '?')}min lock={check['lock']}"
            )

        report["checks"].append(check)

    # ── YouTube transcripts freshness (log + DB ingest age / daily count) ──
    try:
        yt_fresh = check_youtube_transcript_freshness(conn, now=now)
        report["youtube_transcripts_freshness"] = yt_fresh
        _yt_status = yt_fresh.get("status") or "MISSING"
        _mapped = {"CURRENT": "OK", "STALE": "STALE", "MISSING": "MISSING"}.get(_yt_status, _yt_status)
        report["checks"].append(
            {
                "component": "youtube_transcripts_freshness",
                "display": "YouTube Transcripts Freshness",
                "critical": False,
                "schedule": "0 19 * * 1-5",
                "status": _mapped,
                "age_min": (
                    round((yt_fresh.get("db_age_hours") or yt_fresh.get("log_age_hours") or 0) * 60, 1)
                    if (yt_fresh.get("db_age_hours") is not None or yt_fresh.get("log_age_hours") is not None)
                    else None
                ),
                "last_line": (yt_fresh.get("reason") or "")[:100],
                "downstream": "youtube_transcripts, CIO research queue",
                "daily_ingested_count": yt_fresh.get("daily_ingested_count"),
                "latest_ingest_at": yt_fresh.get("latest_ingest_at"),
            }
        )
        if _mapped == "OK":
            report["summary"]["ok"] += 1
        elif _mapped == "STALE":
            report["summary"]["stale"] += 1
        elif _mapped == "MISSING":
            report["summary"]["missing"] += 1
        log.info(f"  YouTube freshness: {_yt_status} — {yt_fresh.get('reason')}")
    except Exception as e:
        log.warning(f"YouTube transcripts freshness check failed: {e}")

    # ── safe_flock event analysis ──
    sf_summary = _analyze_safe_flock(conn, dry_run=dry_run, verbose=verbose)
    report["safe_flock"] = sf_summary

    # ── Agent staleness check ──
    AGENT_MAX_AGE_DAYS = {
        "maria": 1,
        "steph": 1,
        "risk_agent": 1,
        "aegis": 3,
        "alex": 3,
        "tax_agent": 7,
        "iris": 7,
        "maria_research": 7,
    }
    try:
        cur = conn.cursor()
        # Check watchlist_agent_results for most agents
        cur.execute("""SELECT agent, MAX(created_at) as latest
                       FROM watchlist_agent_results GROUP BY agent""")
        agent_latest = {r[0]: r[1] for r in cur.fetchall()}
        # Check agent-specific home tables
        for tbl, col, agent_name in [
            ("aegis_portfolio_briefs", "observed_at", "aegis"),
            ("cio_decisions", "created_at", "alex"),
            # iris is the taxonomy/curation agent — it never writes
            # ticker rows to watchlist_agent_results (its rows there
            # were legacy topic-lane artifacts), so measure it by its
            # actual run ledger (2026-07-19 fix).
            ("iris_run_log", "ran_at", "iris"),
        ]:
            try:
                cur.execute(f"SELECT MAX({col}) FROM {tbl}")
                r = cur.fetchone()
                if r and r[0] and (agent_name not in agent_latest or r[0] > agent_latest.get(agent_name, now)):
                    agent_latest[agent_name] = r[0]
            except Exception:
                pass
        stale_agents = []
        for agent, latest in agent_latest.items():
            max_days = AGENT_MAX_AGE_DAYS.get(agent, 7)
            if latest:
                age_days = (now - latest).total_seconds() / 86400
                if age_days > max_days:
                    stale_agents.append(f"{agent}: {age_days:.0f}d stale (max {max_days}d)")
                    if verbose:
                        log.warning(f"  ⚠️  Agent {agent} stale: last ran {age_days:.0f}d ago (max {max_days}d)")
        if stale_agents and not dry_run:
            # Dedup: only alert once per 4 hours per agent set
            _stale_key = ",".join(sorted(stale_agents))
            _dedup_ok = True
            try:
                cur.execute("""SELECT COUNT(*) FROM system_health_events
                    WHERE component='agent_staleness' AND event_type='STALENESS_ALERT'
                    AND created_at > NOW() - INTERVAL '4 hours'""")
                if (cur.fetchone()[0] or 0) > 0:
                    _dedup_ok = False
            except Exception:
                pass
            if _dedup_ok:
                try:
                    from telegram_alert import send_telegram

                    send_telegram(
                        "⚠️ AGENT STALENESS\n" + "\n".join(stale_agents), priority="P3", producer="system_health_agent"
                    )
                    _log_event(
                        conn, "agent_staleness", "STALENESS_ALERT", "WARN", "\n".join(stale_agents), success=True
                    )
                except Exception:
                    pass
            # Auto-remediate: queue jobs for stale agents that process via watchlist_agent_jobs
            _QUEUE_REMEDIATE = {"tax_agent", "iris", "maria_research"}
            for agent, latest in agent_latest.items():
                max_days = AGENT_MAX_AGE_DAYS.get(agent, 7)
                if latest and (now - latest).total_seconds() / 86400 > max_days and agent in _QUEUE_REMEDIATE:
                    try:
                        # Queue a refresh job if none pending
                        cur.execute(
                            """SELECT COUNT(*) FROM watchlist_agent_jobs
                            WHERE requested_agent=%s AND status IN ('queued','pending','processing')""",
                            [agent],
                        )
                        if (cur.fetchone()[0] or 0) == 0:
                            # Find a symbol to analyze (most recently analyzed per symbol).
                            # 'topic:*' rows are legacy topic-lane results, not tickers — queueing
                            # them dies at the processor's symbol gate, so remediation looped on
                            # the same two invalid jobs every cycle while iris stayed "stale"
                            # (368 failed jobs in 2 days, found 2026-07-19).
                            cur.execute(
                                """SELECT symbol, MAX(created_at) AS latest
                                FROM watchlist_agent_results
                                WHERE agent=%s AND symbol NOT LIKE 'topic:%%'
                                  AND symbol ~ '^[A-Z][A-Z0-9.\\-]{0,9}$'
                                GROUP BY symbol ORDER BY latest DESC LIMIT 2""",
                                [agent],
                            )
                            _syms = [r[0] for r in cur.fetchall()]
                            for _sym in _syms:
                                cur.execute(
                                    """INSERT INTO watchlist_agent_jobs
                                    (id, symbol, requested_agent, request_type, status, priority, submitted_from)
                                    VALUES (%s, %s, %s, 'full_analysis', 'queued', 1, 'health_agent_remediation')""",
                                    [str(uuid.uuid4()), _sym, agent],
                                )
                            conn.commit()
                            if _syms:
                                log.info(f"  🔧 Auto-queued {len(_syms)} jobs for stale {agent}")
                    except Exception as _qe:
                        try:
                            conn.rollback()
                        except Exception:
                            pass
                        log.warning(f"  Auto-queue for {agent} failed: {_qe}")
        report["stale_agents"] = stale_agents
    except Exception as e:
        log.warning(f"Agent staleness check failed: {e}")

    # ── Auto-expire stale queue jobs and proposals ──
    try:
        cur = conn.cursor()
        cur.execute("""UPDATE watchlist_agent_jobs SET status='expired', completed_at=NOW()
                       WHERE status IN ('queued','pending') AND created_at < NOW() - INTERVAL '7 days'""")
        expired_jobs = cur.rowcount
        cur.execute("""UPDATE watchlist_agent_jobs SET status='failed', completed_at=NOW()
                       WHERE status='processing' AND started_at < NOW() - INTERVAL '6 hours'""")
        stuck_jobs = cur.rowcount
        cur.execute("""UPDATE watchlist_proposals SET status='expired'
                       WHERE status IN ('proposed','pending') AND created_at < NOW() - INTERVAL '14 days'""")
        expired_proposals = cur.rowcount
        conn.commit()
        if expired_jobs or stuck_jobs or expired_proposals:
            log.info(
                f"  🧹 Queue cleanup: {expired_jobs} expired jobs, {stuck_jobs} stuck jobs, {expired_proposals} stale proposals"
            )
    except Exception as e:
        log.warning(f"Queue cleanup failed: {e}")

    # ── Proposal lifecycle: enrich-before-reject ──
    # Step 1: Find PENDING proposals that are unenriched for >30 min.
    #         Trigger enrichment instead of rejecting immediately.
    # Step 2: Only reject after enrichment has been attempted 3+ times and failed,
    #         OR after 6 hours regardless.
    try:
        cur = conn.cursor()
        import psycopg2.extras

        rcur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        # Step 1: Trigger enrichment for stuck proposals (>30 min, <3 attempts)
        rcur.execute("""SELECT id, symbol, enrichment_attempt_count, enrichment_status, packet_state
            FROM paper_trade_proposals
            WHERE status='PENDING'
              AND created_at < NOW() - INTERVAL '30 minutes'
              AND packet_state IN ('MISSING_DATA', 'NEW', 'ENRICHING')
              AND COALESCE(enrichment_attempt_count, 0) < 3
            ORDER BY created_at ASC LIMIT 10""")
        _needs_enrichment = [dict(r) for r in rcur.fetchall()]

        if _needs_enrichment:
            log.info(f"  🔧 Auto-enrichment: {len(_needs_enrichment)} stuck proposals need enrichment")
            try:
                import subprocess

                _enrich_result = subprocess.run(
                    [
                        sys.executable,
                        str(PROJECT_ROOT / "scripts" / "auto_enrichment_runner.py"),
                        "--force-all",
                        "--limit",
                        str(len(_needs_enrichment)),
                    ],
                    capture_output=True,
                    text=True,
                    timeout=300,
                    cwd=str(PROJECT_ROOT),
                )
                log.info(f"  🔧 Auto-enrichment triggered (rc={_enrich_result.returncode})")
                if _enrich_result.returncode != 0:
                    log.warning(f"  Auto-enrichment stderr: {_enrich_result.stderr[:200]}")

                # Increment attempt counter for proposals we tried
                for p in _needs_enrichment:
                    cur.execute(
                        """UPDATE paper_trade_proposals
                        SET enrichment_attempt_count = COALESCE(enrichment_attempt_count, 0) + 1,
                            enrichment_last_attempt_at = NOW(), updated_at = NOW()
                        WHERE id = %s""",
                        [p["id"]],
                    )
                conn.commit()
            except Exception as _ee:
                log.warning(f"  Auto-enrichment trigger failed: {_ee}")

        # Step 2: Reject proposals that have been enrichment-attempted 3+ times and still stuck
        cur.execute("""UPDATE paper_trade_proposals
            SET status='REJECTED', rejection_reason='auto_enrichment_failed_3x',
                rejected_at=NOW(), updated_at=NOW()
            WHERE status='PENDING' AND created_at < NOW() - INTERVAL '2 hours'
            AND (approval_allowed IS NULL OR approval_allowed = false)
            AND packet_state IN ('MISSING_DATA', 'NEW', 'ENRICHING')
            AND COALESCE(enrichment_attempt_count, 0) >= 3""")
        _stuck_proposals = cur.rowcount

        # Step 3: Hard reject after 6 hours regardless (safety net)
        cur.execute("""UPDATE paper_trade_proposals
            SET status='REJECTED', rejection_reason='auto_stale_6h',
                rejected_at=NOW(), updated_at=NOW()
            WHERE status='PENDING' AND created_at < NOW() - INTERVAL '6 hours'""")
        _stale_proposals = cur.rowcount
        conn.commit()
        if _stuck_proposals or _stale_proposals:
            log.info(f"  🧹 Proposal cleanup: {_stuck_proposals} enrichment-failed-3x, {_stale_proposals} stale >6h")
    except Exception as e:
        log.warning(f"Proposal lifecycle cleanup failed: {e}")

    # ── Pipeline output monitoring (detect running-but-broken components) ──
    pipeline_alerts = []
    try:
        cur = conn.cursor()
        import pytz as _ptz_pipe

        _et_pipe = _ptz_pipe.timezone("US/Eastern")
        _now_et_pipe = now.astimezone(_et_pipe)
        _h = _now_et_pipe.hour
        _is_market = 9 <= _h <= 16 and _now_et_pipe.weekday() < 5

        if _is_market and not dry_run:
            # 1. Log error content scanning — detect Python crashes in key logs
            _ERROR_PATTERNS = ["Traceback", "NameError", "RISK_GATE_ERROR", "CRITICAL", "FATAL"]
            _SCAN_LOGS = [
                "auto_proposal.log",
                "screener_pm.log",
                "incubator_promoter.log",
                "paper_execution.log",
                "unified_stop_supervisor.log",
            ]
            for _logname in _SCAN_LOGS:
                _logpath = PROJECT_ROOT / "logs" / _logname
                if _logpath.exists():
                    try:
                        _tail = _logpath.read_text()[-3000:]
                        _err_count = sum(_tail.count(p) for p in _ERROR_PATTERNS)
                        if _err_count >= 3:
                            pipeline_alerts.append(f"🔴 {_logname}: {_err_count} errors in recent output")
                    except Exception:
                        pass

            # 2. Proposal creation rate — 0 proposals during market hours for >2h
            cur.execute("""SELECT COUNT(*) FROM paper_trade_proposals
                WHERE created_at > NOW() - INTERVAL '3 hours' AND created_at::date = CURRENT_DATE""")
            _recent_proposals = cur.fetchone()[0] or 0
            if _recent_proposals == 0 and _h >= 10:
                pipeline_alerts.append("⚠️ 0 proposals created in last 3 hours (market open)")

            # 3. Signal generation — 0 signals today after 10 AM.
            # Include universe size so the cause is attributable: a thin universe points upstream
            # (screener/Finviz), NOT the orchestrator. Root cause (e.g. 429) is carried by check #9.
            cur.execute("SELECT COUNT(*) FROM strategy_signals WHERE fired_at::date = CURRENT_DATE")
            _today_signals = cur.fetchone()[0] or 0
            if _today_signals == 0 and _h >= 10:
                cur.execute("SELECT COUNT(DISTINCT symbol) FROM trade_ai_scans WHERE scanned_at::date = CURRENT_DATE")
                _uni_today = cur.fetchone()[0] or 0
                pipeline_alerts.append(
                    f"⚠️ 0 signals generated today (universe={_uni_today} symbols) — "
                    f"check Finviz 429/screener if universe is thin, else orchestrator scoring"
                )

            # 4. Trade execution rate — ATM active but 0 trades after 10 AM
            cur.execute("SELECT mode FROM atm_state WHERE id=1")
            _atm_row = cur.fetchone()
            _atm_mode = _atm_row[0] if _atm_row else "unknown"
            if _atm_mode == "active":
                cur.execute("""SELECT COUNT(*) FROM paper_trades
                    WHERE entry_time::date = CURRENT_DATE AND status != 'cancelled'""")
                _today_trades = cur.fetchone()[0] or 0
                if _today_trades == 0 and _h >= 11:
                    pipeline_alerts.append("⚠️ ATM=active but 0 trades today (check proposal pipeline)")

            # 5. Alpaca position sync — SCHEDULE-AWARE.
            # The syncing job (alpaca_paper_adapter --sync-only) runs hourly 10:00-16:00
            # Mon-Fri. A flat 4-hour threshold therefore fired every weekday before
            # 10:00 and all weekend: on 2026-07-20 it paged about an FCX position whose
            # DB row matched the broker EXACTLY (79 sh @ 62.031392), simply because the
            # last sync was Friday 16:00. Stale now means "older than the most recent
            # SCHEDULED sync + grace" (2026-07-20 fix, same class as monitor_freshness).
            _sync_cutoff = _last_scheduled_sync_fire()
            cur.execute(
                """SELECT COUNT(*) FROM paper_trades
                           WHERE status='open'
                             AND (last_synced_at IS NULL OR last_synced_at < %s)""",
                [_sync_cutoff],
            )
            _unsync = cur.fetchone()[0] or 0
            if _unsync > 0:
                pipeline_alerts.append(
                    f"📊 {_unsync} open trade(s) not synced since the last scheduled sync ({_sync_cutoff:%a %H:%M} ET)"
                )

            # 6. Screener data quality — SOURCE-AWARE.
            # Counting every source together blamed "the screener" for rows written
            # by premarket_social, a StockTwits watcher that carries no fundamentals
            # by design. On 2026-07-20 the screener itself was 6/6 clean while the
            # alert read "16/27 scans have zero float" (2026-07-20 fix).
            cur.execute("""SELECT COALESCE(source,'(none)') AS src,
                                  COUNT(*) AS total,
                                  COUNT(*) FILTER (WHERE float_m IS NULL OR float_m = 0) AS zero
                           FROM trade_ai_scans
                           WHERE scanned_at::date = CURRENT_DATE
                           GROUP BY 1""")
            _by_src = cur.fetchall() or []
            # Only sources that are SUPPOSED to carry float can fail this check.
            _float_bearing = ("screener",)
            for _src, _tot, _zero in _by_src:
                if not _tot or not str(_src).startswith(_float_bearing):
                    continue
                if _zero / _tot > 0.5:
                    pipeline_alerts.append(f"⚠️ Screener data quality: {_zero}/{_tot} '{_src}' scans have zero float")
            # Non-float-bearing sources are reported separately and only when a
            # backfill that should have run clearly did not.
            _social_zero = sum(z for s, t_, z in _by_src if not str(s).startswith(_float_bearing) and t_)
            _social_tot = sum(t_ for s, t_, z in _by_src if not str(s).startswith(_float_bearing) and t_)
            if _social_tot and _social_zero == _social_tot and _social_tot >= 5:
                pipeline_alerts.append(
                    f"ℹ️ {_social_zero}/{_social_tot} social-source scans lack float "
                    f"(float backfill from watchlist_items may not be running)"
                )

            # 7. Open trade agent coverage — detect trades with no recent agent analysis
            try:
                cur.execute("""SELECT pt.symbol FROM paper_trades pt
                    WHERE pt.status = 'open'
                    AND NOT EXISTS (
                        SELECT 1 FROM watchlist_agent_results war
                        WHERE war.symbol = pt.symbol
                        AND war.created_at > NOW() - INTERVAL '3 days'
                    )""")
                _uncovered = [r[0] for r in cur.fetchall()]
                if _uncovered:
                    pipeline_alerts.append(
                        f"⚠️ {len(_uncovered)} open trade(s) with no agent analysis in 3 days: {', '.join(_uncovered[:5])}"
                    )
            except Exception:
                pass

            # 8. Pre-promotion gate blocking — detect if ALL proposals are being blocked
            try:
                import pathlib as _pl

                _olog = _pl.Path(PROJECT_ROOT / "logs" / "screener_pm.log")
                if _olog.exists():
                    _tail = _olog.read_text()[-5000:]
                    _blocked = _tail.count("BLOCKED by pre-promotion gate")
                    _created = _tail.count("CREATED proposal")
                    if _blocked > 0 and _created > 0 and _blocked >= _created:
                        # Check for floating point R:R false blocks
                        _rr_blocks = _tail.count("rr_below_minimum")
                        if _rr_blocks > 0:
                            pipeline_alerts.append(
                                f"⚠️ Pre-promotion gate blocking {_blocked}/{_created} proposals "
                                f"({_rr_blocks} R:R blocks — check floating point tolerance)"
                            )
                        else:
                            pipeline_alerts.append(f"⚠️ Pre-promotion gate blocking {_blocked}/{_created} proposals")
            except Exception:
                pass

            # 9. Finviz rate-limiting — ROOT CAUSE of a starved universe → 0 GO/A+ → 0 signals
            # (added 2026-06-22 after a 429 storm collapsed the universe to ~40-70 symbols and
            # produced 0 signals for every strategy, which earlier looked like a fib-specific bug).
            # Detects the cause directly so the alert is actionable instead of "orchestrator broken".
            try:
                _fv_log = PROJECT_ROOT / "logs" / "finviz_screener.log"
                _fv_429_thresh = int(os.getenv("HEALTH_FINVIZ_429_THRESHOLD", "100"))
                if _fv_log.exists():
                    _fv_tail = _fv_log.read_text()[-40000:]
                    _fv_429 = _fv_tail.count("Too Many Requests")
                    if _fv_429 >= _fv_429_thresh:
                        pipeline_alerts.append(
                            f"🔴 Finviz rate-limited (HTTP 429 ×{_fv_429} in recent log) — screener "
                            f"universe starved; signal generation will be thin/zero until it clears"
                        )
            except Exception:
                pass

        if pipeline_alerts:
            report["pipeline_alerts"] = pipeline_alerts
            log.info(f"  Pipeline issues: {len(pipeline_alerts)}")
            for _pa in pipeline_alerts:
                log.info(f"    {_pa}")
            # Alert (dedup: max 1 per 2 hours)
            _pipe_dedup_ok = True
            try:
                cur.execute("""SELECT COUNT(*) FROM system_health_events
                    WHERE component='pipeline_output' AND event_type='PIPELINE_ALERT'
                    AND created_at > NOW() - INTERVAL '2 hours'""")
                if (cur.fetchone()[0] or 0) > 0:
                    _pipe_dedup_ok = False
            except Exception:
                pass
            if _pipe_dedup_ok:
                try:
                    from telegram_alert import send_telegram

                    send_telegram(
                        "🔴 PIPELINE HEALTH\n" + "\n".join(pipeline_alerts),
                        priority="P3",
                        producer="system_health_agent",
                    )
                    _log_event(
                        conn, "pipeline_output", "PIPELINE_ALERT", "WARN", "\n".join(pipeline_alerts), success=True
                    )
                except Exception:
                    pass
    except Exception as e:
        log.warning(f"Pipeline output monitoring failed: {e}")

    # ── Portfolio risk checks (5 conditions from Command Center) ──
    portfolio_alerts = []
    try:
        _state_dir = PROJECT_ROOT / "data" / "portfolios" / "state"
        _rm = {}
        _rm_path = _state_dir / "risk_management.json"
        if _rm_path.exists():
            import json as _json_rm

            _rm = _json_rm.loads(_rm_path.read_text())

        # 1. Triggered stops
        _STOP_EXEMPT = {"fidelity_401k", "schwab_rollover_ira", "schwab_roth_ira", "schwab_roth", "schwab_taxable"}
        _triggered = [
            p
            for p in _rm.get("positions", [])
            if p.get("status") == "TRIGGERED" and (p.get("account", "") or "").lower() not in _STOP_EXEMPT
        ]
        if _triggered:
            _syms = ", ".join(p.get("symbol", "?") for p in _triggered[:5])
            portfolio_alerts.append(f"🚨 {len(_triggered)} stop(s) triggered: {_syms}")

        # 2. Portfolio heat
        _heat = _rm.get("portfolio_heat_pct", 0)
        if _heat > 5:
            portfolio_alerts.append(f"⚠️ Portfolio heat {_heat:.1f}% — above 5% threshold")

        # 3. No-stop positions
        _no_stop = sum(
            1
            for p in _rm.get("positions", [])
            if p.get("status") == "NO STOP" and (p.get("account", "") or "").lower() not in _STOP_EXEMPT
        )
        if _no_stop > 5:
            portfolio_alerts.append(f"⚠️ {_no_stop} positions without stops")

        # 4. CIO critical decisions
        _cio = (
            _db_query(
                """SELECT COUNT(*) as cnt FROM cio_decisions
            WHERE priority IN ('critical','high')
            AND status NOT IN ('completed','dismissed')
            AND created_at > NOW() - INTERVAL '7 days'""",
                fetch="one",
            )
            if not dry_run
            else {}
        )
        _cio_cnt = (_cio or {}).get("cnt", 0)
        if _cio_cnt > 0:
            portfolio_alerts.append(f"⚡ {_cio_cnt} CIO critical/high decisions pending")

        # 5. Paper trade drift (open trades with no recent price sync)
        # SCHEDULE-AWARE: this is the same check as the pipeline-side one and had
        # the same flat-4h defect — it fired every weekday before the 10:00 sync
        # and all weekend. Fixing only one copy left this one still paging
        # (2026-07-20; duplicate found during the schedule-blind sweep).
        _sync_cut = _last_scheduled_sync_fire()
        _stale_trades = (
            _db_query(
                """SELECT COUNT(*) as cnt FROM paper_trades
            WHERE status='open' AND (last_synced_at IS NULL OR last_synced_at < %s)""",
                (_sync_cut,),
                fetch="one",
            )
            if not dry_run
            else {}
        )
        _stale_trade_cnt = (_stale_trades or {}).get("cnt", 0)
        if _stale_trade_cnt > 0:
            portfolio_alerts.append(
                f"📊 {_stale_trade_cnt} paper trade(s) not synced since the last "
                f"scheduled sync ({_sync_cut:%a %H:%M} ET)"
            )

        # 6. Portfolio live prices (Finviz repricer — not SnapTrade, not holdings file mtime)
        portfolio_alerts.extend(_portfolio_price_freshness_alerts(_now_et))

        if portfolio_alerts:
            report["portfolio_alerts"] = portfolio_alerts
            log.info(f"  Portfolio risks: {len(portfolio_alerts)}")
            for _pa in portfolio_alerts:
                log.info(f"    {_pa}")
    except Exception as e:
        log.warning(f"Portfolio risk check failed: {e}")

    # ── Stop monitoring health (lifecycle orphans, naked, stale advisories) ──
    stop_monitoring_alerts = []
    try:
        from lib.stop_monitoring_health import run_stop_monitoring_health

        _sm = run_stop_monitoring_health(conn, apply=not dry_run)
        report["stop_monitoring"] = _sm
        stop_monitoring_alerts = _sm.get("alerts") or []
        _sm_issues = (_sm.get("diagnosis") or {}).get("issues") or []
        if _sm_issues:
            log.info(f"  Stop monitoring: {len(_sm_issues)} issue(s)")
            for _sa in stop_monitoring_alerts[:8]:
                log.info(f"    {_sa}")
        if stop_monitoring_alerts:
            portfolio_alerts.extend(stop_monitoring_alerts)
            report["portfolio_alerts"] = portfolio_alerts
    except Exception as e:
        log.warning(f"Stop monitoring health failed: {e}")

    # ── Claude Code escalation queue ──
    # Write unresolved problems to escalation file for Claude Code to pick up
    _escalation_items = []
    # Collect failed retries
    for check in report.get("checks", []):
        if check.get("action_taken") in (
            "retry_failed_escalated",
            "retry_held_escalated",
            "retry_completed_unproven_escalated",
            "escalated_no_retry",
        ):
            _escalation_items.append(
                {
                    "component": check.get("component"),
                    "status": check.get("status"),
                    "age_min": check.get("age_min"),
                    "last_error": check.get("last_error"),
                    "retry_cmd": check.get("retry_cmd"),
                }
            )
    # Add stale agents that auto-remediation couldn't fix
    for sa in report.get("stale_agents", []):
        _escalation_items.append({"component": "agent_staleness", "detail": sa})
    # Add portfolio alerts (informational)
    for pa in portfolio_alerts:
        _escalation_items.append({"component": "portfolio_risk", "detail": pa})
    # Add pipeline alerts — these ARE fixable by Claude Code (log errors, broken scripts)
    for pa in pipeline_alerts:
        _escalation_items.append({"component": "pipeline_output", "detail": pa, "fixable": True})
    # Add enrichment-failed proposals that exhausted auto-remediation attempts
    try:
        _ecur = conn.cursor()
        _ecur.execute("""SELECT id, symbol, enrichment_attempt_count, created_at
            FROM paper_trade_proposals
            WHERE status='PENDING' AND packet_state IN ('NEW', 'MISSING_DATA', 'ENRICHING')
            AND COALESCE(enrichment_attempt_count, 0) >= 2
            AND created_at < NOW() - INTERVAL '1 hour'""")
        for _er in _ecur.fetchall():
            _escalation_items.append(
                {
                    "component": "proposal_enrichment_stuck",
                    "detail": f"Proposal #{_er[0]} {_er[1]} stuck after {_er[2]} enrichment attempts (created {_er[3]})",
                    "fixable": True,
                    "retry_cmd": ".venv/bin/python scripts/auto_enrichment_runner.py --force-all --limit 5",
                }
            )
    except Exception:
        pass

    if _escalation_items and not dry_run:
        try:
            import json as _esc_json

            _esc_file = PROJECT_ROOT / "logs" / "claude_escalation_queue.json"
            _existing = []
            if _esc_file.exists():
                try:
                    _existing = _esc_json.loads(_esc_file.read_text())
                except Exception:
                    _existing = []
            # Append new items with timestamp
            for item in _escalation_items:
                item["escalated_at"] = now.isoformat()
                item["source"] = "system_health_agent"
            _existing.extend(_escalation_items)
            # Keep only last 50 items
            _existing = _existing[-50:]
            _esc_file.write_text(_esc_json.dumps(_existing, indent=2, default=str))
            log.info(f"  📋 {len(_escalation_items)} items written to claude_escalation_queue.json")
        except Exception as e:
            log.warning(f"Claude escalation queue write failed: {e}")

    report["portfolio_alerts"] = portfolio_alerts
    conn.close()
    return report


# Helper for portfolio risk DB queries
def _db_query(sql, params=None, fetch="all"):
    try:
        from db_adapter import _get_conn as _gq_conn

        _c = _gq_conn()
        _cur = _c.cursor()
        _cur.execute(sql, params)
        if fetch == "one":
            _cols = [d[0] for d in _cur.description]
            _row = _cur.fetchone()
            _c.close()
            return dict(zip(_cols, _row)) if _row else {}
        _cols = [d[0] for d in _cur.description]
        _rows = [dict(zip(_cols, r)) for r in _cur.fetchall()]
        _c.close()
        return _rows
    except Exception:
        return {} if fetch == "one" else []


def main():
    p = argparse.ArgumentParser(description="System Health Execution Integrity Agent")
    p.add_argument("--dry-run", action="store_true", default=True)
    p.add_argument("--apply", action="store_true")
    p.add_argument("--verbose", action="store_true")
    p.add_argument("--output-json", type=str)
    args = p.parse_args()
    if args.apply:
        args.dry_run = False

    report = run_health_check(dry_run=args.dry_run, verbose=args.verbose)

    s = report.get("summary", {})
    mode = "DRY RUN" if args.dry_run else "ACTIVE"
    # Components checked (actions are counted separately, not as extra components).
    total = sum(s.get(k, 0) for k in ("ok", "stale", "missing", "failed", "locked"))
    log.info(
        f"[{mode}] Health check complete: {s['ok']}/{total} OK, "
        f"{s['stale']} stale, {s['missing']} missing, {s['failed']} failed, "
        f"{s['locked']} locked, {s['retried']} retried, {s.get('retry_disarmed', 0)} retry disarmed, "
        f"{s['escalated']} escalated"
    )

    if args.output_json:
        Path(args.output_json).parent.mkdir(parents=True, exist_ok=True)
        Path(args.output_json).write_text(json.dumps(report, indent=2, default=str))

    # Exit EXIT_FINDING (3) if any critical component is down. Not 1: 1 is what an
    # uncaught exception exits with, and health_tick.py must tell a crash of this
    # agent from a finding (n8n maturity B3.1, 2026-10-09; scripts/lib/monitor_exit_codes.py).
    critical_down = [
        c for c in report.get("checks", []) if c.get("critical") and c.get("status") not in ("OK", "RECOVERED")
    ]
    if critical_down and not args.dry_run:
        from lib.monitor_exit_codes import EXIT_FINDING

        sys.exit(EXIT_FINDING)


if __name__ == "__main__":
    main()
