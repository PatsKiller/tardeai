from pathlib import Path
r=Path('/home/johnclaw/tradeai-wt-n8n-health-retry-budget-20261019')
p=r/'tests/test_system_health_agent_conn_and_retired_20261007.py';s=p.read_text();s=s.replace('''    assert (
        agent._attempt_retry(comp, _DeadConn()) is True
    )  # The controlled child exits 0; the dead count query is not fatal.
    assert calls == ["true"] and not unexpected
    assert events == [("unit-test", "RETRY", "INFO", "true", True)]''','''    # Unknown accounting now holds safely; the original no-UnboundLocalError guarantee remains.
    assert agent._attempt_retry(comp, _DeadConn()) is False
    assert calls == [] and not unexpected
    assert events == [("unit-test", "RETRY_BUDGET_HELD", "WARN", None, False)]''');p.write_text(s)
p=r/'tests/test_health_agent_retry_disarmed_20261008.py';s=p.read_text();s=s.replace('assert timeout == 300','assert 0 < timeout <= 300')
s=s.replace('''    assert agent._attempt_retry(comp, _NoConn()) is True
    assert marker.read_text() == "x"  # controlled completion artifact
    assert retry_process["calls"] == [expected]
    assert retry_process["events"] == [("arm-test", "RETRY", "INFO", expected[:100], True)]''','''    # Arming does not create a known budget when DB history is unavailable.
    assert agent._attempt_retry(comp, _NoConn()) is False
    assert not marker.exists() and retry_process["calls"] == []
    assert retry_process["events"] == [("arm-test", "RETRY_BUDGET_HELD", "WARN", None, False)]


def test_known_fixture_budget_preserves_the_running_interpreter(monkeypatch, tmp_path, retry_process):
    import system_health_agent as agent

    class KnownConn:
        def cursor(self):
            return self

        def execute(self, *args):
            pass

        def fetchone(self):
            return (0,)

        def commit(self):
            pass

    state = tmp_path / "fixture-state"
    (state / "data/runtime").mkdir(parents=True)
    (state / "data/runtime/health_retry_attempts.jsonl").write_text("")
    monkeypatch.setenv("TRADEAI_STATE_ROOT", str(state))
    monkeypatch.setattr(agent, "_health_retry_history", lambda path, now: path.read_text())
    monkeypatch.setenv("TRADEAI_HEALTH_AGENT_RETRY", "1")
    marker = tmp_path / "known-ran.txt"
    cmd = f".venv/bin/python -c \\"open('{marker}','w').write('x')\\""
    expected = cmd.replace(".venv/bin/python", sys.executable, 1)
    retry_process.update(expected=expected, marker=marker)
    assert agent._attempt_retry({"component": "known-arm-test", "retry_cmd": cmd}, KnownConn()) is True
    assert marker.read_text() == "x"  # fake completion; never business-output proof
    assert retry_process["calls"] == [expected]
    assert retry_process["events"] == [("known-arm-test", "RETRY", "INFO", expected[:100], True)]''')
# Correct generated quoting using a repr-safe single-quoted f-string.
s=s.replace('cmd = f".venv/bin/python -c \\"open(\'{marker}\',\'w\').write(\'x\')\\""', 'cmd = f\'.venv/bin/python -c "open({str(marker)!r},"w").write("x")"\'')
p.write_text(s)
p=r/'tests/test_system_health_retry_recovery_truth_20261019.py';s=p.read_text();s=s.replace('''        "nonzero",
''','''        "nonzero",
        "uninitialized",
''',1)
s=s.replace('''    monkeypatch.setattr(agent, "_get_conn", lambda: Conn())''','''    monkeypatch.setattr(agent, "_get_conn", lambda: Conn())
    # Fake authoritative complete history qualifies admission mechanics only, never production readiness.
    journal = tmp_path / "state/data/runtime/health_retry_attempts.jsonl"
    journal.parent.mkdir(parents=True)
    journal.write_text("")
    monkeypatch.setenv("TRADEAI_STATE_ROOT", str(tmp_path / "state"))
    if case != "uninitialized":
        monkeypatch.setattr(agent, "_health_retry_history", lambda path, now: path.read_text())''',1)
s=s.replace('''assert len(calls) == (0 if case == "disarmed" else 1)''','''assert len(calls) == (0 if case in ("disarmed", "uninitialized") else 1)
    if case == "uninitialized":
        assert report["summary"]["retried"] == 0 and report["summary"]["retry_held"] == 1
        assert check["action_taken"] == "retry_held_escalated"
        assert check["recovery_reason"] == "retry_budget_uninitialized"
        assert journal.read_text() == ""''',1);p.write_text(s)
p=r/'scripts/lib/recovery_attempt_budget.py';s=p.read_text();s=s.replace('''row["attempt_id"] = uuid.uuid4().hex
                    record''','''row["attempt_id"] = uuid.uuid4().hex
                    if any(json.loads(line).get("attempt_id") == row["attempt_id"]
                           for line in text.splitlines() if line.strip()):
                        raise ValueError("duplicate_reservation_identity")
                    record''',1)
s=s.replace('''text=json.dumps(record))
                append(path, record)
                row.update(record)''','''text=text + "\\n" + json.dumps(record))
                append(path, record)
                row.update(record)''',1);p.write_text(s)
