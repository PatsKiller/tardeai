# Staged incident-notifier state reader

Status: DRAFT
as_of: 2026-10-18T23:17:38.131956+00:00
Measured at: tested integration 6eead361ef8b44ab220148d1bf4854060cc57247; production a2aef7b4d2de17e737526337a2ffc37848deda4f

This change keeps the v1 writer as the default. It reads existing v1 and v2
state without discarding delivery identities, counters, recording evidence or
opaque extensions. Malformed, duplicate-field, nonfinite and unsupported state
refuses rather than resetting delivery deduplication.

The original candidate preserved v2 bytes but still ran v1 generation and
recovery semantics. Independent tests proved generation suppression and a false
SYSTEM RECOVERED message. The follow-up refuses every persisted v2 state before
legacy worker effects or state writes. Pure inspection and lossless save remain
available. Original rejected evidence is retained.

This reader provides a safe hold on rollback; it does not execute v2 semantics.
A rollback with v2 state pauses notification processing, so independent P1
continuity under that rollback is still unproven. The v2 writer release and full
rollback acceptance remain held. The known a2/3af artifact remains incompatible
until this reader has actually been merged, deployed and verified. No runtime
state, provider, scheduler, workflow or authority mutation is included.

The identical state-preservation test fails on the actual 7af baseline and passes
on the candidate with the fixed 675 v2 producer. The unchanged independent
semantic cases fail on the first candidate and pass on the follow-up. Exact
author validation passed 91 tests; nonauthor validation passed 30 tests. Native
acceptance, final integration review and exact-head hosted checks remain separate
requirements.
