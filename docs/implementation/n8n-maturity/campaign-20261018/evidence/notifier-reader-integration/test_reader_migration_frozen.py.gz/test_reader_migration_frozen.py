"""Frozen actual producer/reader pair. Root selection is explicit; no provider effects."""
import importlib.util
import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

PRODUCER_ROOT = Path('/home/johnclaw/tradeai-wt-n8n-recovery-truth-integration-20261018')
V1_PRODUCER_ROOT = Path('/home/johnclaw/tradeai-wt-n8n-repair-baseline-20261018')
READER_ROOT = Path(os.environ['NOTIFIER_COMPAT_READER_ROOT'])


def module(name, root):
    spec = importlib.util.spec_from_file_location(name, root / 'scripts/incident_notifier.py')
    out = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(out)
    return out


V2 = module('frozen_notifier_producer_675', PRODUCER_ROOT)
V1 = module('frozen_notifier_producer_3af', V1_PRODUCER_ROOT)
READER = module('explicit_notifier_reader', READER_ROOT)
NOW = datetime(2026, 10, 18, 21, tzinfo=timezone.utc)
KEY = 'inc-fixture-migration'


@pytest.mark.parametrize('producer', [V1, V2], ids=['actual-v1-producer', 'actual-v2-producer'])
def test_actual_producer_state_keeps_delivered_notice_after_reader_save(tmp_path, producer):
    incident = {'key': KEY, 'source': 'fixture', 'item': 'notice', 'severity': 'P1', 'detail': 'fixture',
                'generation': 2, 'detected_at': NOW.isoformat(), 'intent_ids': ['intent-current']}
    state = producer.load_state(tmp_path / 'absent-state.json')
    initial, _ = producer.plan_messages({KEY: incident}, state, NOW, producer.config_from_env({}),
                                       {'as_of': NOW.isoformat(), 'by_severity': {'P1': 1}})
    assert len(initial) == 1
    if producer is V2:
        producer.apply_result(state, initial[0], NOW, {'message_id': 841})
    else:
        producer.apply_result(state, initial[0], NOW)
    path = tmp_path / 'state.json'
    producer.atomic_write_json(path, state)
    loaded = READER.load_state(path)
    messages, _ = READER.plan_messages({KEY: incident}, loaded, NOW + timedelta(seconds=60), READER.config_from_env({}),
                                      {'as_of': NOW.isoformat(), 'by_severity': {'P1': 1}})
    assert loaded['notified'].get(KEY) == state['notified'][KEY], 'reader discarded durable delivered-notice state'
    assert loaded['schema'] == state['schema'], 'reader changed the producer state version meaning'
    assert not messages, 'reader replanned an already-settled notice'
    READER.atomic_write_json(path, loaded)
    assert READER.load_state(path) == state, 'reader save discarded producer state'
