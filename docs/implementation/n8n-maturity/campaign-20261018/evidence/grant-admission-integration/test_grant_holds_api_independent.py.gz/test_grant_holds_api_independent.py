"""Independent authority hold checks; imports exact candidate via explicit PYTHONPATH."""
import pytest
from scripts.lib import fabric_grant as F

ACTIONS=("hermes-tune.c2","hermes-tune.c3","hermes-tune.rollback","hermes-feedback.c3","hermes-feedback.rollback")

@pytest.mark.parametrize('action',ACTIONS)
@pytest.mark.parametrize('consume',[False,True])
def test_direct_check_and_consume_cannot_bypass_hold(monkeypatch,action,consume):
    def forbidden():
        pytest.fail('held action reached canonical grant ledger')
    monkeypatch.setattr(F,'_guard_ledger',forbidden)
    result=F.authorize(action,consume=consume,environ={'TRADEAI_FABRIC_GRANT':'a'*32})
    assert result=={'schema':'FabricPacketGrantCheck@v1','ok':False,'action':action,'consumed':False,'state':'held','reason':'reviewed_common_controller_required'}
