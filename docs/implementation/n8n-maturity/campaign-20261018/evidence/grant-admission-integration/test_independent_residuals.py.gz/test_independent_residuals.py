"""Read-only campaign review; all mutation targets are pytest temporary paths."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from datetime import datetime, timezone

ROOT = Path(os.environ["REVIEW_ROOT"])
PY = sys.executable
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))


def load(name, rel):
    spec = importlib.util.spec_from_file_location(name, ROOT / rel)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def test_tune_c2_requires_grant_before_crontab_write(tmp_path):
    before = "# unrelated line\n0 17 * * * cd $PROJ && bash scripts/pipelines/run_hermes_pipeline.sh --stage tune --apply\n"
    cron_state = tmp_path / "crontab.txt"
    cron_state.write_text(before)
    cron_bin = tmp_path / "crontab"
    cron_bin.write_text("#!" + PY + "\nimport os,sys\nfrom pathlib import Path\np=Path(os.environ['FAKE_CRONTAB'])\nif sys.argv[1:] == ['-l']: sys.stdout.write(p.read_text())\nelse: p.write_text(sys.stdin.read())\n")
    cron_bin.chmod(0o700)
    env = {**os.environ, "PY": PY, "SERVED": str(ROOT), "CRONTAB_BIN": str(cron_bin),
           "FAKE_CRONTAB": str(cron_state), "BACKUPS": str(tmp_path / "backups"),
           "NOW_HM": "1400", "HOME": str(tmp_path), "TMPDIR": str(tmp_path),
           "GUARD_APPROVALS_DIR": str(tmp_path / "no-grants"), "TRADEAI_FABRIC_GRANT": ""}
    p = subprocess.run(["bash", str(ROOT / "docs/ops/packets/hermes-tune-cutover-20261017/cutover.sh"), "c2", "--apply"],
                       env=env, text=True, capture_output=True, timeout=10)
    assert p.returncode != 0 and cron_state.read_text() == before, (
        f"unguarded scheduler mutation rc={p.returncode}; after={cron_state.read_text()!r}; output={p.stdout}")


def test_fabric_verifier_refuses_canonical_corrupt_ledger(tmp_path, monkeypatch):
    fg = load("review_fabric_grant", "scripts/lib/fabric_grant.py")
    gl = load("review_guard_ledger", ".cursor/hooks/guard_ledger.py")
    gid = "0123456789abcdef0123456789abcdef"
    (tmp_path / "grants.json").write_text(json.dumps({"config-write": {
        "grant_id": gid, "expires": int(time.time()) + 3600, "uses": -2, "reason": "unrelated task"}}))
    monkeypatch.setenv("GUARD_APPROVALS_DIR", str(tmp_path))
    assert gl.classify_ledger(tmp_path / "grants.json") == gl.MALFORMED
    assert fg.verify(gid, ["config-write"]) is None, "canonical MALFORMED ledger accepted as active"


def test_fabric_verifier_refuses_symlink_ledger(tmp_path, monkeypatch):
    fg = load("review_fabric_grant", "scripts/lib/fabric_grant.py")
    gl = load("review_guard_ledger", ".cursor/hooks/guard_ledger.py")
    gid = "0123456789abcdef0123456789abcdef"
    target = tmp_path / "fixture.json"
    target.write_text(json.dumps({"config-write": {
        "grant_id": gid, "expires": int(time.time()) + 3600, "uses": 1, "reason": "unrelated task"}}))
    (tmp_path / "grants.json").symlink_to(target)
    monkeypatch.setenv("GUARD_APPROVALS_DIR", str(tmp_path))
    assert gl.classify_ledger(tmp_path / "grants.json") == gl.UNREADABLE
    assert fg.verify(gid, ["config-write"]) is None, "canonical UNREADABLE ledger accepted as active"


def test_repair_requires_nonempty_named_check_policy():
    from scripts.lib import self_heal_fix_evaluator as ev
    sha = "a" * 40
    pr = {"headRefOid": sha, "statusCheckRollup": [{"name": "unrelated", "status": "COMPLETED", "conclusion": "SUCCESS"}]}
    assert ev.pr_head_verdict(pr, expected_head=sha)["verdict"] != "pass", "empty required policy accepted"


def test_repair_mandatory_check_cannot_be_skipped_or_neutral():
    from scripts.lib import self_heal_fix_evaluator as ev
    sha = "a" * 40
    for conclusion in ("SKIPPED", "NEUTRAL"):
        pr = {"headRefOid": sha, "statusCheckRollup": [{"name": "mandatory", "status": "COMPLETED", "conclusion": conclusion}]}
        assert ev.pr_head_verdict(pr, expected_head=sha, required=["mandatory"])["verdict"] != "pass", conclusion


def test_unknown_repair_cost_is_not_zero():
    from scripts.lib import self_heal_fixer as core
    for stdout in ('not-json', '{"result":"complete"}'):
        result = core.parse_claude_result(stdout)
        assert result["cost_usd"] is None, f"unknown cost became {result['cost_usd']!r}"


def test_rejected_repair_cannot_advance_on_ancestor_release(tmp_path, monkeypatch):
    from scripts import self_heal_fixer as worker
    sha, merge = "a" * 40, "b" * 40
    release = tmp_path / "release-sha"
    release.write_text("c" * 40)
    job = {"state": worker.F.FIX_PR_OPENED, "lane": "safe-canary", "pr_number": 9999,
           "head_sha": sha, "history": [], "iterations": [{"passed": True,
           "acceptance": {"accepted": True, "commit_sha": sha}}]}
    doc = {"state": "MERGED", "mergeCommit": {"oid": merge}, "headRefOid": sha,
           "mergedAt": "2026-10-18T12:00:00Z", "statusCheckRollup": [
           {"name": "mandatory", "status": "COMPLETED", "conclusion": "FAILURE"}]}
    monkeypatch.setattr(worker, "git", lambda *a, **k: {"rc": 0, "out": "", "err": ""})
    outcome = worker.advance(job, cfg={"lifecycle": {"release_current_sha_file": str(release)}},
                             now=datetime.now(timezone.utc), diag_state={}, root=tmp_path, repo=tmp_path,
                             gh=lambda *a: {"rc": 0, "out": json.dumps(doc), "err": ""})
    assert job["acceptance"]["accepted"] is False
    assert outcome != worker.F.FIX_DEPLOYED and job["state"] == worker.F.FIX_PR_OPENED, (
        f"rejected CI advanced to {job['state']} via release ancestry")
