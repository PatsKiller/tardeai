"""Independent legacy packet race expectation; fake crontab and fake guard ledger only."""
import shlex

from tests.test_hermes_tune_cutover_20261017 import _fake_crontab, _packet, OLD_LINE, LEARN_LINE


def test_tune_c2_preserves_operator_edit_between_read_and_install(tmp_path):
    exe = _fake_crontab(tmp_path, f"# header\n{LEARN_LINE}\n{OLD_LINE}\n")
    tab = tmp_path / "crontab.txt"
    q = shlex.quote(str(tab))
    exe.write_text(
        '#!/bin/bash\n'
        f'if [ "$1" = "-l" ]; then cat {q}; '
        f'elif [ "$1" = "-" ]; then printf "# concurrent-operator-edit\\n" >> {q}; cat > {q}; '
        'else exit 9; fi\n'
    )
    result = _packet(tmp_path, "c2", "--apply")
    assert result.returncode != 0 or "# concurrent-operator-edit" in tab.read_text(), result.stdout + result.stderr
