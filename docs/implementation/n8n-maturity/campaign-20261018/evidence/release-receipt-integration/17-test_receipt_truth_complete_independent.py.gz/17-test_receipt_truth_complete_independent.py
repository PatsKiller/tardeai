"""Actual fixed993 producer and explicit actual reader; no runtime release effects."""
import importlib.util
import json
import os
from pathlib import Path
import pytest

FROZEN = Path('/tmp/n8n-campaign-20261018/cross-review/receipt993-source')
READER_ROOT = Path(os.environ['RECEIPT_GOVERNANCE_SOURCE_ROOT'])


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    out = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(out)
    return out


P = module('actual_receipt_producer993', FROZEN/'scripts/lib/exact_release_receipt.py')
R = module('explicit_governance_reader', READER_ROOT/'scripts/report_lane_governance_packet.py')
SHA = 'a' * 40


def actual_receipt(tmp_path):
    releases = tmp_path/'releases'
    artifact = releases/'observed'
    artifact.mkdir(parents=True)
    for field in ['BUILD_SHA', 'GIT_SHA', 'SOURCE_COMMIT']:
        (artifact/field).write_text(SHA+'\n')
    (releases/'CURRENT').symlink_to(artifact)
    result, valid = P.build_receipt(releases_base=releases, ok=True, mode='promote', health='ok',
        rolled_back=False, attempted_dir=str(artifact), attempted_sha=SHA)
    assert valid and result['deployed_availability'] == 'AVAILABLE'
    return result


def read(tmp_path, receipt):
    (tmp_path/'deploy_receipt.json').write_text(json.dumps(receipt))
    (tmp_path/'post_merge_ci.json').write_text(json.dumps({'candidate_sha': SHA, 'ok': True}))
    return R.releases_section(tmp_path, tmp_path)


@pytest.mark.parametrize('availability', ['UNAVAILABLE', None])
def test_unavailable_v2_identity_cannot_claim_deployed_ci(tmp_path, availability):
    dep = actual_receipt(tmp_path)
    dep.update(deployed_availability=availability, deployed_unavailable_reason='current_missing_or_changed', ok=False)
    result = read(tmp_path, dep)
    assert result['post_merge_ci_ok'] is None, 'UNAVAILABLE v2 deployment identity must not bind a green deployed CI'
    assert result['post_merge_ci_status'] == 'UNAVAILABLE'


def test_actual_complete_v2_producer_preserves_exact_ci_positive_control(tmp_path):
    result = read(tmp_path, actual_receipt(tmp_path))
    assert result['post_merge_ci_ok'] is True and result['post_merge_ci_status'] == 'AVAILABLE'
