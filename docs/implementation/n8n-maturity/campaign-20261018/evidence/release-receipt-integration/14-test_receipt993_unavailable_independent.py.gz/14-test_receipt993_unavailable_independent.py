"""Actual governance reader must not turn unavailable v2 identity into deployed CI proof."""
import json
import pytest
from scripts import report_lane_governance_packet as R

SHA = 'a' * 40


@pytest.mark.parametrize('availability', ['UNAVAILABLE', None])
def test_unavailable_v2_identity_cannot_claim_deployed_ci(tmp_path, availability):
    dep = {'schema': 'CioExactMainDeployReceipt@v2', 'deployed_sha': SHA, 'content_sha': SHA,
           'release_dir': '/fixture/stale', 'deployed_availability': availability,
           'deployed_unavailable_reason': 'current_missing_or_changed', 'ok': False}
    (tmp_path/'deploy_receipt.json').write_text(json.dumps(dep))
    (tmp_path/'post_merge_ci.json').write_text(json.dumps({'candidate_sha': SHA, 'ok': True}))
    result = R.releases_section(tmp_path, tmp_path)
    assert result['post_merge_ci_ok'] is None, 'UNAVAILABLE v2 deployment identity must not bind a green deployed CI'
    assert result['post_merge_ci_status'] == 'UNAVAILABLE'


def test_available_v2_identity_preserves_exact_sha_ci_control(tmp_path):
    (tmp_path/'deploy_receipt.json').write_text(json.dumps({'schema': 'CioExactMainDeployReceipt@v2',
        'deployed_sha': SHA, 'deployed_availability': 'AVAILABLE', 'ok': True}))
    (tmp_path/'post_merge_ci.json').write_text(json.dumps({'candidate_sha': SHA, 'ok': True}))
    assert R.releases_section(tmp_path,tmp_path)['post_merge_ci_ok'] is True
