"""Independent complete producer identity/control separation; temporary artifacts only."""
import importlib.util
from pathlib import Path

path = Path('/tmp/n8n-campaign-20261018/cross-review/test_receipt_truth_complete_independent.py')
spec = importlib.util.spec_from_file_location('complete_receipt_review_fixture', path)
M = importlib.util.module_from_spec(spec)
spec.loader.exec_module(M)


def test_failed_attempt_does_not_erase_known_current_exact_ci(tmp_path):
    M.actual_receipt(tmp_path)
    releases = tmp_path/'releases'
    artifact = releases/'observed'
    dep, valid = M.P.build_receipt(releases_base=releases, ok=False, mode='promote', health='fail',
        rolled_back=False, attempted_dir=str(artifact), attempted_sha='b'*40)
    assert valid and dep['ok'] is False
    assert dep['attempted_target']['identity_matches'] is False
    assert dep['deployed_sha'] == M.SHA and dep['deployed_availability'] == 'AVAILABLE'
    result = M.read(tmp_path, dep)
    assert result['ok'] is False and result['post_merge_ci_ok'] is True


def test_prepare_without_current_cannot_bind_attempted_artifact_ci_as_deployed(tmp_path):
    M.actual_receipt(tmp_path)
    releases = tmp_path/'releases'
    (releases/'CURRENT').unlink()
    dep, valid = M.P.build_receipt(releases_base=releases, ok=True, mode='prepare', health='skipped',
        rolled_back=False, attempted_dir=str(releases/'observed'), attempted_sha=M.SHA)
    assert valid and dep['prepared_ok'] is True and dep['deployed_sha'] is None
    result = M.read(tmp_path, dep)
    assert result['post_merge_ci_ok'] is None and result['post_merge_ci_status'] == 'UNAVAILABLE'
