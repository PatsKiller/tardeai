"""Independent exact-head review: pure recovery interface and SIEM plan, no effects."""
import copy,json
from datetime import datetime,timezone
import pytest
from scripts.lib import n8n_siem_bridge as B
from scripts.lib import recovery_validator as RV
NOW=datetime(2026,10,18,15,tzinfo=timezone.utc)
OPEN='2026-10-18T12:00:00+00:00'

def row(lane='fixture-output'):
 rid=f'd:{lane}:live:20261018T1300'
 receipt={'lane_id':lane,'run_id':rid,'attempt':1,'mode':'live','state':'RUN_DONE','exit_code':0,
          'finished_at':'2026-10-18T13:00:00+00:00','output_verdict':{'verdict':'produced','contract_id':lane}}
 return {'lane_id':lane,'run_id':rid,'attempt':1,'mode':'live','state':'RUN_DONE','exit_code':0,
         'finished_at':receipt['finished_at'],'receipt':receipt}

@pytest.mark.parametrize('lane',['fixture-output',B.FANIN_LANE])
@pytest.mark.parametrize('kind',sorted(B.LEDGER_KINDS))
@pytest.mark.parametrize('case',['good','dry','old','wrong_contract','unknown_exit'])
def test_each_ledger_kind_including_fanin_requires_real_proof(lane,kind,case):
 r=row(lane)
 if case=='dry':r['receipt']['mode']='dry_run'
 if case=='old':r['finished_at']=r['receipt']['finished_at']='2026-10-18T11:59:00+00:00'
 if case=='wrong_contract':r['receipt']['output_verdict']['contract_id']='different-output'
 if case=='unknown_exit':r['exit_code']=r['receipt']['exit_code']=None
 incident={'id':1,'component':'n8n:'+lane,'event_type':kind,'severity':'CRITICAL','created_at':OPEN}
 # Pass candidate direct: plan MUST recheck instead of trusting admission producer.
 p=B.plan({},[incident],env='review',good_lanes={lane:r},ledger_ok=True,fanin_ok=True)
 assert bool(p['resolve']) == (case=='good')
 assert bool(p['hold']) != (case=='good')

@pytest.mark.parametrize('field',['lane_id','run_id','attempt','state','exit_code','finished_at'])
def test_outer_inner_conflict_cannot_pass_with_same_mode_and_useful_output(field):
 r=row();r['receipt'][field]={'lane_id':'other','run_id':'another-run','attempt':2,'state':'RUN_FAILED','exit_code':1,'finished_at':'2026-10-18T13:01:00+00:00'}[field]
 ok,reason=RV.validate(r,mode='live',lane=r['lane_id'],since=datetime.fromisoformat(OPEN).timestamp(),now=NOW)
 assert not ok and reason.startswith('receipt_identity_mismatch:')

@pytest.mark.parametrize('clock',[float('nan'),float('inf'),True,'2026-10-18T13:00:00','2099-01-01T00:00:00+00:00',10**1000])
def test_finished_clock_invalid_or_future_at_either_level_refused(clock):
 for level in ['outer','inner','both']:
  r=row()
  if level in ('outer','both'):r['finished_at']=clock
  if level in ('inner','both'):r['receipt']['finished_at']=clock
  assert not RV.validate(r,mode='live',lane=r['lane_id'],now=NOW)[0]

@pytest.mark.parametrize('bound',[float('nan'),float('inf'),True,'2026-10-18T12:00:00'])
def test_invalid_lower_bound_never_dropped_by_wrapper(bound):
 r=row();assert RV.output_recovered(r['lane_id'],bound,runs=[r]) is None


def test_equivalent_offset_clocks_are_same_actual_finish_and_valid_empty_passes():
 r=row();r['receipt']['finished_at']='2026-10-18T09:00:00-04:00';r['receipt']['output_verdict']['verdict']='empty_allowed'
 assert RV.validate(r,mode='live',lane=r['lane_id'],now=NOW)==(True,'ok')


def test_source_failure_and_legacy_good_names_cannot_resolve_any_ledger_kind():
 r=row()
 for good,ledger_ok in [({r['lane_id']:r},False),({r['lane_id']},True)]:
  incidents=[{'id':i+1,'component':'n8n:'+r['lane_id'],'event_type':kind,'severity':'CRITICAL','created_at':OPEN} for i,kind in enumerate(sorted(B.LEDGER_KINDS))]
  p=B.plan({},incidents,env='review',good_lanes=good,ledger_ok=ledger_ok,fanin_ok=True)
  assert not p['resolve'] and len(p['hold'])==len(incidents)
