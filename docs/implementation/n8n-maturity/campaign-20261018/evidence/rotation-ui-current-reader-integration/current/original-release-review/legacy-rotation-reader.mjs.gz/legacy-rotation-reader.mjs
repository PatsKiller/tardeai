import assert from 'node:assert/strict'
import { readFileSync,writeFileSync } from 'node:fs'
import {createRequire} from 'node:module'
import {pathToFileURL} from 'node:url'
const root='/home/johnclaw/tradeai-wt-n8n-release-baeda-20261019'
const require=createRequire('/home/johnclaw/trade-ai-v12-rebuild/trade-ai-v12-rebuild/apps/command-center-v3/package.json')
const ts=require('typescript'),React=require('react'),{renderToStaticMarkup}=require('react-dom/server')
const file=root+'/apps/command-center-v3/src/components/intelligence/IntelligenceRotationTab.tsx'
const source=readFileSync(file,'utf8').replace(/import \{ useApi \} from ['"][^'"]+['"]/, 'const useApi = (..._args: any[]): any => (globalThis as any).__fixture')
let js=ts.transpileModule(source,{compilerOptions:{jsx:ts.JsxEmit.ReactJSX,target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText
js=js.replace(/from ["']([^"']+)["']/g,(_,spec)=>`from ${JSON.stringify(pathToFileURL(require.resolve(spec)).href)}`)
const {default:View}=await import('data:text/javascript;base64,'+Buffer.from(js).toString('base64'))
const unavailable=JSON.parse(readFileSync('/tmp/n8n-campaign-20261018/cross-review/release-baeda/actual-unavailable-payload.json','utf8'))
const results=[]
for(const [name,data,check] of [
 ['ready existing control',{ok:true,summary:{rotation_ideas:3},top_rotation_ideas:[{from_symbol:'FIXTURE_A',to_symbol:'FIXTURE_B'}]},html=>assert.match(html,/FIXTURE_A/)],
 ['actual unavailable projection must be visibly unavailable',unavailable,html=>assert.match(html,/UNAVAILABLE|unavailable|Failed to load/)]
]){globalThis.__fixture={data,error:null,loading:false};let html=renderToStaticMarkup(React.createElement(View,{onDrill(){}}));try{check(html);results.push({name,passed:true})}catch(e){results.push({name,passed:false,exception:e.name,assertion:e.message,rendered_html:html})}}
writeFileSync('/tmp/n8n-campaign-20261018/cross-review/release-baeda/legacy-rotation-reader-results.json',JSON.stringify({root,results},null,2)+'\n')
console.log(JSON.stringify(results.map(({rendered_html,...r})=>r),null,2));process.exitCode=results.some(r=>!r.passed)?1:0
