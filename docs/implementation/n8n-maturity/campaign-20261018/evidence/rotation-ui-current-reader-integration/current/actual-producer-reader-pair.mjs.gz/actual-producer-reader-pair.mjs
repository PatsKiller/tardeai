import assert from 'node:assert/strict'
import {readFileSync,writeFileSync,existsSync} from 'node:fs'
import {createRequire} from 'node:module'
import {dirname,join,resolve} from 'node:path'
import {pathToFileURL} from 'node:url'
const root=process.env.SOURCE_ROOT, resultPath=process.env.RESULT_PATH
assert(root && resultPath,'explicit reader source and result path required')
assert(!existsSync(resultPath),'immutable result path already exists')
const require=createRequire('/home/johnclaw/trade-ai-v12-rebuild/trade-ai-v12-rebuild/apps/command-center-v3/package.json')
const ts=require('typescript'),React=require('react'),{renderToStaticMarkup}=require('react-dom/server'),memo=new Map()
function compile(path){
 if(memo.has(path))return memo.get(path)
 const source=readFileSync(path,'utf8').replace(/import \{ useApi \} from ['"][^'"]+['"]/,'const useApi = (..._args: any[]): any => (globalThis as any).__fixture')
 let js=ts.transpileModule(source,{compilerOptions:{jsx:ts.JsxEmit.ReactJSX,target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText
 js=js.replace(/from ["']([^"']+)["']/g,(_,spec)=>{
  if(!spec.startsWith('.'))return `from ${JSON.stringify(pathToFileURL(require.resolve(spec)).href)}`
  let target=resolve(dirname(path),spec)
  if(!existsSync(target))target=['.ts','.tsx','.js'].map(s=>target+s).find(existsSync)
  assert(target,`missing actual source dependency ${spec}`)
  return `from ${JSON.stringify(compile(target))}`
 })
 const url='data:text/javascript;base64,'+Buffer.from(js).toString('base64');memo.set(path,url);return url
}
const pair=JSON.parse(readFileSync('/tmp/n8n-campaign-20261018/rotation-ui-current-reader-integration/actual-producer-pair.json','utf8'))
Date.now=()=>Date.parse(pair.ready.publication.checked_at)
const {default:View}=await import(compile(join(root,'apps/command-center-v3/src/components/intelligence/IntelligenceRotationTab.tsx')))
const results=[]
for(const [name,data,check] of [
 ['actual producer READY control',pair.ready,html=>assert.match(html,/SCHG/)],
 ['actual unavailable projection must be visibly unavailable',pair.unavailable,html=>assert.match(html,/UNAVAILABLE|unavailable|Failed to load/)]
]){
 globalThis.__fixture={data,error:null,loading:false}
 const html=renderToStaticMarkup(React.createElement(View,{onDrill(){}}))
 try{check(html);results.push({name,passed:true,rendered_html:html})}catch(e){results.push({name,passed:false,exception:e.name,assertion:e.message,rendered_html:html})}
}
writeFileSync(resultPath,JSON.stringify({root,clock:pair.ready.publication.checked_at,producer_source:pair.source_sha,results},null,2)+'\n')
console.log(JSON.stringify(results.map(({rendered_html,...r})=>r),null,2));process.exitCode=results.some(r=>!r.passed)?1:0
