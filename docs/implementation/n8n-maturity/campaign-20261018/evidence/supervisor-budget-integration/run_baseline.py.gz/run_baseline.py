import importlib.util
import os
from pathlib import Path
import sys
root=Path("/home/johnclaw/tradeai-wt-n8n-supervisor-incident-budget-20261018")
sys.path[:0]=[str(root),str(root/"scripts")]
import scripts
for name in ("supervisor_breach_detector", "n8n_failure_diagnosis"):
    spec=importlib.util.spec_from_file_location("scripts."+name, Path(__file__).parent/("baseline-"+name+".py"))
    module=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=module
    spec.loader.exec_module(module)
    setattr(scripts,name,module)
import pytest
raise SystemExit(pytest.main(["-q","-p","no:cacheprovider",str(root/"tests/test_n8n_supervisor_budget_20261018.py"),"-k","prior_restart or concurrent_evaluators or failed_restart or missing_or_unreadable or distinct_critical or daily_ai_caps"]))
