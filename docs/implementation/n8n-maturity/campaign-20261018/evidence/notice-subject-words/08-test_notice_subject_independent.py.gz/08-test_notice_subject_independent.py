from datetime import datetime, timezone
import pytest
from scripts.lib import comms_editor as ce

@pytest.mark.parametrize('symbol',['LAST','DOWN','CC','DATA'])
def test_explicit_lowercase_dollar_security_stays_a_security(tmp_path,symbol):
    guid='known-fixture-guid-'+symbol
    decision=ce.edit('$'+symbol.lower()+' earnings update',chat_id='fixture',now=datetime(2026,10,19,14,tzinfo=timezone.utc),ledger=ce.DuplicateLedger(tmp_path/'ledger.json'),resolve=lambda _: [{'symbol':symbol,'guid':guid}],db_query=lambda *a,**kw:[],editor_mode='live')
    assert decision.subjects==[{'symbol':symbol,'guid':guid}], 'An explicit dollar security marker must not be treated as operational prose'

@pytest.mark.parametrize('symbol',['LAST','DOWN','CC','DATA'])
def test_explicit_scope_preserves_exact_registry_identity_without_body_bleed(tmp_path,symbol):
    row={'symbol':symbol,'guid':'known-fixture-guid-'+symbol}
    decision=ce.edit('Research update for '+symbol+' and ambient MSFT',chat_id='fixture',now=datetime(2026,10,19,14,tzinfo=timezone.utc),ledger=ce.DuplicateLedger(tmp_path/'ledger.json'),resolve=lambda _: [row,{'symbol':'MSFT','guid':'ambient-guid'}],db_query=lambda *a,**kw:[],editor_mode='live',primary_symbols=[symbol])
    assert decision.subjects==[row]
    assert 'ambient-guid' not in decision.text
