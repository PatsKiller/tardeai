"""Frozen independent guard review; pure functions, no external effects."""
import importlib.util
from pathlib import Path
import copy
import os
import pytest

ROOT = Path(os.environ.get('DQ_LABEL_SOURCE_ROOT', '/home/johnclaw/tradeai-wt-n8n-data-quality-safe-20261018'))
spec = importlib.util.spec_from_file_location('reviewed_guard', ROOT / 'scripts/lib/analyst_recom_guard.py')
guard = importlib.util.module_from_spec(spec)
spec.loader.exec_module(guard)


@pytest.mark.parametrize('raw', ['Strong Buy', '4.8'])
def test_contradictory_supported_label_cannot_remain_publishable(raw):
    record = {'recom': raw, 'recom_score': 4.8, 'analyst_rating': 'Strong Buy', 'cached_at': 'fixture-time'}
    original = copy.deepcopy(record)
    reason = guard.sanitize_enrichment_record(record)
    assert reason is not None, 'supported rating label must agree with the shared numeric classifier'
    assert record['recom_score'] is None and record['analyst_rating'] is None
    assert record['recom'] == original['recom'] and record['cached_at'] == original['cached_at']


@pytest.mark.parametrize('raw', ['Buy', '2.0'])
def test_consistent_supported_legacy_and_numeric_controls_remain_unchanged(raw):
    record = {'recom': raw, 'recom_score': 2.0, 'analyst_rating': 'Buy', 'cached_at': 'fixture-time'}
    original = copy.deepcopy(record)
    assert guard.sanitize_enrichment_record(record) is None
    assert record == original
