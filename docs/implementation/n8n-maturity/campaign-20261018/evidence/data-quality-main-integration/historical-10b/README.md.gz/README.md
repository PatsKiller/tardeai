# Refuse invalid analyst recommendations in historical cache and replay

Status: DRAFT
as_of: 2026-10-19T01:25:00+00:00
Measured at: source 6fbdad88f37f02b024b0556ba6370add3a886f1e; baseline b52a1f2fa2f929e9b72d9133b98cf2610ffb9264; observed production a2aef7b4d2de17e737526337a2ffc37848deda4f

The fresh Finviz recommendation parser already refuses percentages and values
outside its declared scale. Historical cache reads and database replay did not
apply that validator. They could publish or persist invalid derived ratings.
The shared guard now enforces the existing classifier at those boundaries,
preserving raw values and provenance while withholding invalid derived fields.
The classifier thresholds and financial calculations are unchanged.

Independent review also reproduced a valid numeric score paired with a
contradictory supported label. The corrected guard refuses both raw-label and
derived-label contradictions. It does not remap the label. Valid legacy labels
require matching numeric evidence. Unknown cache fields and cache file bytes
remain intact. An independently present target retains its original value.

The row builder records prepared rows separately from committed rows. Only a
successful database commit establishes the latter; unavailable or ambiguous
outcomes retain an unknown committed count. Tests use fake database effects.

The original audit found three assertion failures and two valid controls.
Only cache and replay are implemented here: the identical scoped four cases
show two baseline assertion failures and two controls, then four passing on the
candidate. The API empty-vote failure remains an explicit separate gap.
The unchanged independent label suite shows two expected assertion failures
on 6de2c736f01bc99cfc357648abd925e1956f710a plus two valid controls, followed
by all four passing on the corrected source. Independent candidate regressions
pass 72 tests. Four attempted live database connections in existing regression
fixtures were refused before libpq; no live database coverage is claimed.

The canonical gate adds the new behavioral suite. Existing parser tests retain
their original registration. The adjacent default-universe regression was run
locally and is not claimed as registered by this change. The large formatting
diff is isolated in its own commit; full-module AST equivalence is verified,
and the original classifier AST is unchanged. Failed observations and earlier
author packets are preserved alongside the correction and independent review.

Historical stored SQL rows and their direct consumers, API empty-vote handling,
source freshness, research provenance and production useful-output proof remain
open. This change does not clean old data, authorize financial changes, or
qualify the whole mixed-scope PR1853. Native acceptance, hosted CI, merge,
deployment and operational proof are separate pending stages for this packet.

The manifest records stored and original digests and lengths for losslessly
compressed evidence. No historical failure receipt is replaced.
