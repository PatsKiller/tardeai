import importlib.util,sys
from pathlib import Path
root=Path("/home/johnclaw/tradeai-wt-n8n-spawn-fence-integration-20261018")
sys.path[:0]=[str(root),str(root/"scripts")]
import scripts
spec=importlib.util.spec_from_file_location("scripts.n8n_run_executor",Path(__file__).parent/"baseline-executor.py")
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
scripts.n8n_run_executor=module
import pytest
raise SystemExit(pytest.main(["-q","--junitxml=/tmp/n8n-campaign-20261018/spawn-integration/baseline.xml","-p","no:cacheprovider",str(root/"tests/test_n8n_cutover_transaction_20261018.py"),"-k","owner_change_cannot_land"]))
