"""Read actual apply definitions; every external effect is fake, all JSON is scratch."""
import ast
import datetime as dt
import json
import os
from pathlib import Path
from typing import Any, Mapping, Optional

import pytest

ROOT = Path(os.environ.get("DISK_REVIEW_ROOT", "/home/johnclaw/trade-ai-v12-rebuild/trade-ai-v12-rebuild"))
UNSUPPORTED = "destructive_apply_unsupported_by_active_policy"
NOW = dt.datetime(2026, 10, 20, 12, 0, tzinfo=dt.timezone.utc)


def actual_apply(kind, effects):
    path = ROOT / "scripts" / ("disk_hygiene.py" if kind == "disk" else "tmp_hygiene.py")
    tree = ast.parse(path.read_text())
    matches = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "apply"]
    assert len(matches) == 1
    schema = "DiskHygieneManifest@v1"

    class DiskConstants:
        MANIFEST_SCHEMA = schema
        APPLY_SCHEMA = "DiskHygieneApplyReport@v1"
        GRANT_ENV = "TRADEAI_DISK_HYGIENE_GRANT"

        @staticmethod
        def _gb(value):
            return value / (1024 ** 3)

    def remove(item):
        effects.append(("remove", item["path"]))
        return True, "FAKE_EFFECT_NO_DELETION"

    namespace = dict(Path=Path, Mapping=Mapping, Any=Any, Optional=Optional,
                     datetime=dt.datetime, timezone=dt.timezone, json=json,
                     APPLY_SCHEMA=DiskConstants.APPLY_SCHEMA, MANIFEST_SCHEMA=schema,
                     GRANT_ENV=DiskConstants.GRANT_ENV, SCOPE="tmp", DH=DiskConstants,
                     build_context=lambda *a: {}, remove_item=remove,
                     revalidate=(lambda *a: (True, "", a[0])) if kind == "tmp" else (lambda *a: (True, "")),
                     _gb=DiskConstants._gb)
    exec(compile(ast.Module(body=matches, type_ignores=[]), str(path), "exec"), namespace)
    return namespace["apply"]


@pytest.mark.parametrize("kind", ["disk", "tmp"])
def test_invented_nonempty_token_never_authorizes_public_apply(kind, tmp_path):
    effects = []
    apply = actual_apply(kind, effects)
    manifest = tmp_path / "manifest.json"
    target = tmp_path / "retained.txt"
    target.write_text("must remain")
    manifest.write_text(json.dumps({"schema": "DiskHygieneManifest@v1", "scope": "tmp",
                                   "generated_at": NOW.isoformat(), "home": str(tmp_path),
                                   "tmp_root": str(tmp_path),
                                   "items": [{"path": str(target), "kind": "fixture", "size_bytes": 1, "file_count": 1}]}))
    caps = {"manifest_max_age_hours": 24, "max_items_per_run": 10,
            "max_bytes_per_run": 100, "max_files_per_run": 100}
    rules = {"_home": tmp_path, "apply": caps}
    extra = [{"_root": tmp_path, "apply": caps}] if kind == "tmp" else []
    result = apply(manifest, rules, *extra, NOW, grant="not-an-authentic-grant", run_id=None)
    assert result["refused"] == UNSUPPORTED, f"Unverified token reached public apply: {result}; fake effects={effects}"
    assert effects == [] and target.read_text() == "must remain"


def test_existing_executor_refusal_is_a_no_effect_control(tmp_path):
    for kind in ["disk", "tmp"]:
        effects = []
        apply = actual_apply(kind, effects)
        extra = [{}] if kind == "tmp" else []
        result = apply(tmp_path / "never-created.json", {}, *extra, NOW,
                       grant="not-an-authentic-grant", run_id="d:fixture:live:slot")
        assert result["refused"] and effects == []
        assert not (tmp_path / "never-created.json").exists()
